import json
import os
import boto3
import ast
import csv
import glob
import logging
import os
logger = logging.getLogger()
logger.setLevel(logging.INFO)
from datetime import datetime

SFN_CLIENT = boto3.client('stepfunctions')
s3_client = boto3.resource('s3')
service_role = "arn:aws:iam::083760424738:role/odp-fin-nprod-ctb-service-role"
bucket = "odp-fin-nprod-ctb"

def lambda_handler(event, context):
    logger.info("Event: %s",event)
    logger.info("context: %s",context)
    JsonTemplateModel={}
    JsonTempObject=['informatica_sfn_json_temp']
    for AssignDictObject in JsonTempObject:
        key1 = "orchestration/Informatica-auto-sfn-manifest-file/Json-template/"+AssignDictObject+".json"
        S3JsonObject = s3_client.Object(bucket, key1)
        JsonTemplateModel[AssignDictObject] = S3JsonObject.get()['Body'].read().decode('utf-8')
    
    MenifestObjectList = []
    sfnName = []
    BucketObject = s3_client.Bucket('odp-fin-nprod-ctb')
    for MenifestCountObject in BucketObject.objects.filter(Prefix="orchestration/Informatica-auto-sfn-manifest-file/Manifest-file/"):
        MenifestObjectList.append(MenifestCountObject.key)
    for MenifestRawData in MenifestObjectList[1:]:
        S3Object = s3_client.Object(bucket, MenifestRawData)
        S3PackageObject = S3Object.get()['Body'].read().decode('utf-8').splitlines()
        MenifestLineObjects = csv.reader(S3PackageObject)
        header = next(MenifestLineObjects)
        for SplitFileObject in MenifestLineObjects:
            #logger.info("SplitFileObject: %s",SplitFileObject)
            ChangedStateName = JsonTemplateModel.get("informatica_sfn_json_temp").replace("<<<workflow_name>>>",SplitFileObject[1]).replace("<<<folder_name>>>",SplitFileObject[2])
            #logger.info("ChangedStateName: %s",ChangedStateName)
            GetCreatedSfnAWSConsole = SFN_CLIENT.create_state_machine(name=SplitFileObject[0] , definition=ChangedStateName, roleArn=service_role)
            #print(json.dumps(GetCreatedSfnAWSConsole, indent=4, default=str))
            #logger.info("GetCreatedSfnAWSConsole: %s",GetCreatedSfnAWSConsole)
            print({'Step Function Created !!! :: stateMachineArn': GetCreatedSfnAWSConsole['stateMachineArn']})
            