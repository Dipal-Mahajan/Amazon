import json
import boto3
import time
import logging
from config_interfaces import get_config_object, get_config_value

from datetime import datetime


logger = logging.getLogger()
logger.setLevel(logging.INFO)

sfn_client = boto3.client('stepfunctions')
ssm_client = boto3.client('ssm')
config = get_config_object()


def lambda_handler(event, context):

    try:

        logger.info(f'printing event -- {event}')
        logger.info(f'printing token -- {event["token"]}')
        logger.info(f'printing script type -- {event["type"]}')
        logger.info(f'printing script name -- {event["script"]}')
        
        
        script_name = event["script"]
        workflow_id = event["workflow_id"]
        script_type = event["type"]
        token = event["token"]

        if("args" in event.keys()):
            args = event["args"]
        else:
            args = None

        logger.info(f'running script')
        
        command_id = run_script(script_name,script_type,token,args)

        return {
            'statusCode': 200,
            'body': json.dumps('Shell Script Triggered'),
            'ssm_command_id':json.dumps(command_id)
            
        }
    except Exception as ex:
        logger.error(str(ex))
        raise


def run_script(script_name,script_type,token,args) -> str :
    
    current_time = datetime.utcnow().strftime("%m-%d-%y-%H:%M")
    log_file_name = script_name+"_"+current_time+".log"
    instance_id = get_config_value(config, "EC2", "ec2_instance_id")

    # checking if there are any arguments to be passed
    if(args):
        if( '|' in args ):
            script_args = " ".join(args.split('|'))
        else:
            script_args = args
    else:
        script_args = ""

    # if script type is rsql
    if(script_type == "rsql"):
        secret_id = get_config_value(config, "SECRET", "redshift_secret_id")
        rsql_script_path = get_config_value(config, "EC2", "rsql_script_path")
        rsql_log_path = get_config_value(config, "EC2", "rsql_log_path")

        cmd = "sh +x "+rsql_script_path+script_name+ " '" + token + "' " + " " + script_name + " " + secret_id + " " + rsql_log_path+log_file_name + " " + script_args + " > " + rsql_log_path+log_file_name + " 2>&1 " 

    # if script type is shell
    elif(script_type == 'shell'):
        shell_script_path = get_config_value(config, "EC2", "shell_script_path")
        shell_log_path = get_config_value(config, "EC2", "shell_log_path")
        shell_script_wrapper = get_config_value(config, "EC2", "shell_script_wrapper")

        cmd = "sh +x "+shell_script_wrapper+ " '" + token + "' '" + shell_script_path+script_name + "' '" + shell_log_path+log_file_name + "' " + script_args + " > " + shell_log_path+log_file_name + " 2>&1 "
        
    else:
        logger.error(script_type + 'Not Supported Script Type')
        raise Exception('Not supported Script Type')

    logger.info(f'command to be triggered is {cmd}')

    ssm_response = ssm_client.send_command(
            InstanceIds=[instance_id],
            DocumentName='AWS-RunShellScript',
            CloudWatchOutputConfig={
            'CloudWatchLogGroupName': '/aws/ssm/AWS-RunShellScript',
            'CloudWatchOutputEnabled': True
            },
            Parameters={
                'commands': [
                    cmd
                ]
            }
        )
    ssm_command_id = ssm_response['Command']['CommandId']
        
    logger.info(f'response is {ssm_response}')
    logger.info(f'command is {ssm_command_id}')

    return ssm_command_id

