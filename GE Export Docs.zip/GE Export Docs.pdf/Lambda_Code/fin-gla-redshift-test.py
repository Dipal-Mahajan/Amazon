import time
import boto3
import json
import io
import sys
import urllib.parse
import botocore.session as bc
client_redshift = boto3.client('redshift-data')
client = boto3.client("redshift-data", region_name='us-east-1')
#from pgdb import connect

def get_redshift_credentials():
    """
    To get username and password from Redshift
    secret manager.
    """
    client = boto3.client("secretsmanager", region_name="us-east-1")
    get_secret_value_response = client.get_secret_value(SecretId="odp-fin-nprod-gla-fsso")
    secret = get_secret_value_response['SecretString']
    secret = json.loads(secret)
    return secret

def exec_query():
    print("***************Data API successfully loaded .....**************************")
    
    query_string = "select * from hvrstats_audit_table where table_name = 'zx_rates_tl';"
    result_of_sql = client_redshift.execute_statement(
        ClusterIdentifier='odp-fin-dev-etl-redshift',
        Database='gehc_data',
        DbUser = 'odpfindevetl',
        Sql = query_string
        )
    # To get sql statment execution id 
    sql_execution_id = result_of_sql['Id']
    # Storing sql statment execution status
    statment = ''
    status = ''
    
    while status != 'FINISHED' and status != 'FAILED' and status != 'ABORTED':
        statment = client.describe_statement(Id = sql_execution_id)
        status = statment['Status']
        status1 = statment
        print('status1',status1)
        print('Status',status)
        time.sleep(5)
    print('')
    print(json.dumps(statement, indent=4, default=str))
    print('')

def lambda_handler(event, context):
    print("Connection estiblished ....")
    
    check_secret = get_redshift_credentials()
    #connection_checkpoint = connect_redshift()
    checking_query = exec_query()
    print("checking_query",checking_query)
    print("checkt",check_secret)
    