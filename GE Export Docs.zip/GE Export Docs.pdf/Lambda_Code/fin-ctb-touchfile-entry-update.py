import json
from datetime import datetime, timedelta
import boto3
import os

DDB_TABLE = os.environ['envprefix'] + "-metadata" #fin-ctb-nprod-metadata
DDB_REGION = os.environ["region"]

s3_client = boto3.client('s3')

ddb_client = boto3.resource("dynamodb", region_name=DDB_REGION)
ddb_table = ddb_client.Table(DDB_TABLE)

print(ddb_table)

def ddb_insert_records(ddb_record):
    try:
        
        print('format {}'.format(ddb_record))
        ddb_put_response = ddb_table.put_item(Item=ddb_record)
        print("Insert {}".format(ddb_put_response))
        
    except Exception as e:
        print("Put error {}".format(e))
        return False

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    print("file path:",key)
    file = key;
    print("file name1:",file)

    
    current_date = (datetime.now()).strftime('%Y-%m-%d')
    print(current_date)
    
    current_time = (datetime.now()).strftime("%H%M")
    print(current_time)
    
    #get current timestamp
    current_timestamp = int(datetime.timestamp(datetime.now()))
    
    source = file.split("/")[0]

    if(source == "orchestration"):
        #STEPFUNCTIONNAME-AWSSERVICE-TRACKNAME-DATE-HOUR-MIN.txt
        touchfile = file.split("/")[3]
        
        touchfilewoextn = os.path.splitext(touchfile)
        touchfile = touchfilewoextn[0]
        
        step_function_name, service, track_name, file_date, file_hour, file_min =  touchfile.split('-')

        ddb_record = {
            "partition_key": source + '-' + step_function_name,
            "sort_key": current_date ,
            "track": track_name,
            "type" : service,
            "date" : file_date,
            "HOUR": file_hour,
            "MINUTE":file_min,
            "touchfile" : touchfile,
            "timestamp" : current_timestamp
        }
        
        ddb_insert_records(ddb_record)
        
    elif(source == "finance_touchfile"):
        
        touchfile = file.split("/")[1]
        print("Ingestion file name:",touchfile)
        track_name = 'ctb'
        #SOURCENAME-HUBNAME-CHANNELNAME-DATE-HOUR-MIN.txt
        
        touchfilewoextn = os.path.splitext(touchfile)
        touchfile = touchfilewoextn[0]
        
        source_name, hub_name, channel, file_date, file_hour, file_min = touchfile.split('-')

        ddb_record = {
           
            "partition_key": source +'-'+ hub_name +'-' + channel,
            "sort_key": current_date + '-' +current_time,
            #"sort_key": current_date ,
            "track": track_name,
            "source_name" : source_name,
            "hub_name" : hub_name,
            "date" : file_date,
            "HOUR": file_hour,
            "MINUTE":file_min,
            "touchfile" : touchfile,
            "timestamp" : current_timestamp
        }
        
        ddb_insert_records(ddb_record)
    
    else:
        print(" No need to add records to DynamoDB Table")
    
    # partkey, sortkey = "fin-ctb-channel-touchfile", filetstartuptime
    # ddb_update_records(partkey, sortkey, channel, filedate, filetime, filetstartuptime,touchfile)