import json
import boto3
import os
import time
from datetime import datetime
from datetime import time
from dynamodb_interfaces import query_dynamodb, _deserialize

sfn_client = boto3.client('stepfunctions')
sns_client = boto3.client('sns')

AM_region     = "02:15" #7:45AM_IST
AM2_region    = "07:45" #1:15PM_IST
PRE_AS_region = "12:15" #5:45PM_IST
AS_region     = "14:45" #8:15PM_IST
EU_region     = "20:45" #2:15AM_IST

def sns_notification(sns_arn, msg, task_status, task_date):
    try:
        response = sns_client.publish(
            TopicArn=sns_arn,
            Message=msg,
            Subject='CTB STEP FUNCTION LOAD STATUS ' + task_status + ' - ' + task_date
        )
        return True

    except Exception as e:
        print("Not able to send notification!. Error {}".format(e))
        return False

def unique(list):
        unique_list = []
        for x in list:
                if x not in unique_list:
                        unique_list.append(x)

        for x in unique_list:
                print (x)
                
        y= len(unique_list)  
        print(y)
        return y
        
def check_entry_for_period():
        current_date = (datetime.now()).strftime('%Y-%m-%d')
        period_partiql_statement = """ SELECT * FROM "fin-ctb-nprod-metadata" WHERE "partition_key" = 'orchestration-COMMON_COA_PERD' AND "sort_key" = 'date' """
        
        period_partiql_statement = period_partiql_statement.replace("date",current_date)
        
        period_data = query_dynamodb(period_partiql_statement)
        
        if(len(period_data[0]) == 0 ):
                print("No data")
                return False
        
        else:
                return True

def check_entry_for_ingestion():
        current_date = (datetime.now()).strftime('%Y-%m-%d')
        
        #get current timestamp
        current_timestamp = int(datetime.timestamp(datetime.now()))
        prev_timestamp = int(datetime.timestamp(datetime.now())) - 5400  #before 90 minutes 
        
        
        time  = datetime.now()
        print(current_date)
        print(current_timestamp)
        print(prev_timestamp)
        
        ingestion_partiql_statement = """ SELECT "partition_key" FROM "fin-ctb-nprod-metadata" WHERE  "partition_key" IN ('finance_touchfile-ushvr00-biosap_fr_04','finance_touchfile-gla_poc-glprod_fr_9','finance_touchfile-gla_poc-hcit_fr_2','finance_touchfile-gla_poc-biosap_fr_04','finance_touchfile-gla_poc-glprod_fr_te','finance_touchfile-ushvr00-glprod_fr_03')  AND "timestamp"  BETWEEN   prev_timestamp AND current_timestamp """
        
        ingestion_partiql_statement = ingestion_partiql_statement.replace("prev_timestamp",str(prev_timestamp)).replace("current_timestamp",str(current_timestamp))
        print(ingestion_partiql_statement)
        
        ingestion_data = query_dynamodb(ingestion_partiql_statement)
        
        unique_record = unique(ingestion_data)
        print(unique_record)
        

        if( unique_record == 6 ):
                return True
        else:
                print("Ingestion touchfile not generated")
                return False
        
        

def lambda_handler(event, context):
        
        current_account_number = context.invoked_function_arn.split(":")[4]
        
        success_sns_arn = 'arn:aws:sns:' + os.environ['AWS_REGION'] + ':' + current_account_number + ':fin-ctb-sfn-success'
        failure_sns_arn = 'arn:aws:sns:' + os.environ['AWS_REGION'] + ':' + current_account_number + ':fin-ctb-sfn-failure'
        sfn = 'arn:aws:states:' + os.environ['AWS_REGION'] + ':' + current_account_number + ':stateMachine:' 
        #print("SFN ARN {}".format(sfn_arn))
        
        CURRENT_DATE = (datetime.now()).strftime('%Y-%m-%d')
        time  = datetime.now()
        Current_time = time.strftime("%H") + ':' + time.strftime("%M")
        
        current_datetime = CURRENT_DATE +  '-' + Current_time
        print("Current date & time {}".format(current_datetime))
        
        period_flag = check_entry_for_period()
        ingestion_flag = check_entry_for_ingestion()
        
        if(period_flag is True and ingestion_flag is True):
                if Current_time == AM_region:
                        region = "AM"
                        sfn_name = "fin-ctb-finance-ctb-am-load"
                        Input = {  "INPUT": {    "Finance_CTB_Dimensions": "N",    "fin-ctb-glp_local_balances": "N",    "fin-ctb-hit_local_balances": "N",    "fin-ctb-sap_local_balances": "N" ,    "region": "AM",    "fin-ctb-finance_ctb_elims": "N",    "fin-ctb-global_balances": "N" ,   "fin-ctb-gl_fx_coa_am_load": "N"  ,   "fin-ctb-local_balances_archival": "N"      }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                        
                        #for gl_stats_coa
                        sfn_name = "fin-ctb-gl-stat-coa-am-load"
                        Input = {  "INPUT": {    "Finance_CTB_GL_STAT_COA_GLP_LOAD": "N",    "Finance_CTB_GL_STAT_COA_SAP_LOAD": "N",    "region": "AM" }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                        
                elif Current_time == AM2_region:
                        region = "AM2"
                        sfn_name = "fin-ctb-finance-ctb-am2-load"
                        Input = {  "INPUT": {    "Finance_CTB_Dimensions": "N",    "fin-ctb-glp_local_balances": "N",    "fin-ctb-hit_local_balances": "N",    "fin-ctb-sap_local_balances": "N" ,    "region": "AM2",    "fin-ctb-finance_ctb_elims": "N",    "fin-ctb-global_balances": "N" ,     "fin-ctb-gl_fx_coa_am2_load": "N"  ,   "fin-ctb-local_balances_archival": "N"  }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                
                elif Current_time == PRE_AS_region:
                        region   = "PRE_AS"
                        sfn_name = "fin-ctb-finance-ctb-pre-as-load"
                        Input = {  "INPUT": {    "Finance_CTB_Dimensions": "N",    "fin-ctb-glp_local_balances": "N",    "fin-ctb-hit_local_balances": "N",    "fin-ctb-sap_local_balances": "N" ,    "region": "PRE_AS",    "fin-ctb-finance_ctb_elims": "N",    "fin-ctb-global_balances": "N" ,   "fin-ctb-gl_fx_coa_pre_as_load": "N"  ,   "fin-ctb-local_balances_archival": "N" }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                
                elif Current_time == AS_region:
                        region   = "AS"
                        sfn_name = "fin-ctb-finance-ctb-as-load"
                        Input = {  "INPUT": {    "Finance_CTB_Dimensions": "N",    "fin-ctb-glp_local_balances": "N",    "fin-ctb-hit_local_balances": "N",    "fin-ctb-sap_local_balances": "N" ,    "region": "AS",    "fin-ctb-finance_ctb_elims": "N",    "fin-ctb-global_balances": "N",   "fin-ctb-gl_fx_coa_as_load": "N"  ,   "fin-ctb-local_balances_archival": "N"    }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                        
                        #for gl_stats_coa
                        sfn_name = "fin-ctb-gl-stat-coa-as-load"
                        Input = {  "INPUT": {    "Finance_CTB_GL_STAT_COA_GLP_LOAD": "N",    "Finance_CTB_GL_STAT_COA_SAP_LOAD": "N",    "region": "AS" }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                
                elif Current_time == EU_region:
                        region   = "EU"
                        sfn_name = "fin-ctb-finance-ctb-eu-load"
                        Input = {  "INPUT": {    "Finance_CTB_Dimensions": "N",    "fin-ctb-glp_local_balances": "N",    "fin-ctb-hit_local_balances": "N",    "fin-ctb-sap_local_balances": "N" ,    "region": "EU",    "fin-ctb-finance_ctb_elims": "N",    "fin-ctb-global_balances": "N" ,   "fin-ctb-gl_fx_coa_eu_load": "N"  ,   "fin-ctb-local_balances_archival": "N"   }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                        
                        #for gl_stats_coa
                        sfn_name = "fin-ctb-gl-stat-coa-eu-load"
                        Input = {  "INPUT": {    "Finance_CTB_GL_STAT_COA_GLP_LOAD": "N",    "Finance_CTB_GL_STAT_COA_SAP_LOAD": "N",    "region": "EU" }}
                        sfn_arn = sfn + sfn_name
                        response = sfn_client.start_execution(stateMachineArn=sfn_arn, input=json.dumps(Input) )
                        print("response {}".format(response))
                        
                        msg = "Trigger has been start for {} Step function".format(sfn_name)
                        sns_notification(success_sns_arn, msg, "SUCCESS", current_datetime)
                else:
                        print("Invalid region")
                        msg = "Trigger has been failed for {} Step function due to Invalid region schedule"
                        sns_notification(failure_sns_arn, msg, "FAILURE", current_datetime)
        
        else:
                print(" Period Flag : {} " + format(period_flag)  )
                print(" Ingestion Flag : {}" + format(ingestion_flag) )
                msg = "Step function trigger has been Failed because of one of the touchfile not generated for {} GMT timeperiod".format(Current_time)
                sns_notification(failure_sns_arn, msg, "FAILURE", current_datetime)
	
          
