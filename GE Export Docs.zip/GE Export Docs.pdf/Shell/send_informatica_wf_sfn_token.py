import sys
import json
import boto3
import time
from datetime import datetime
from pathlib import Path
import re

sfn_client = boto3.client('stepfunctions',region_name='us-east-1')
ssm_client = boto3.client('ssm',region_name='us-east-1')


def get_error_message(log_file_path:str) -> str:
    """
    Parses the log file and returns the error message

    :param str log file name including the absolute path
    :return: error log Messages within the log file
    :rtype: str

    """
    if error_code == '3':
        error_pattern = '(?<=Task run error code: )[\S\s]*(?=Integration Service: )'
    else:
        error_pattern = '(?<=ERROR: )[\S\s]*(?=Disconnecting)'

    try:
        print("Parsing the log file for errors : " + log_file_path)

        file = open(log_file_path, "r")
        f = file.read()
        file.close()
        match = re.search(error_pattern, f)
        if match:
            error_message = re.search(error_pattern, f).group()
        else:
            error_message = ''

        error_msg = 'Error Message : ' + error_message

        return error_msg

    except Exception as e:
        print("Exception occured : " + str(e))
        raise

def run_shellscript(token,job_name,error_code,log_file_name):


    # success task token
    if(error_code == '0'):
        print (f'sending success response using token which is {token}')

        current_time = datetime.utcnow().strftime("%m-%d-%y %H:%M:%S")
        msg = job_name + " execution succeeded at " + current_time

        response = sfn_client.send_task_success(
            taskToken=token,
            output= json.dumps({"job_name" :  job_name,
            "status": "completed",
            "message": msg}))

    # failure task token
    else:
        print (f'sending failure response using token which is {token}')

        current_time = datetime.utcnow().strftime("%m-%d-%y %H:%M:%S")
        error_msg = get_error_message(log_file_name)
        error_status = " Informatica Workflow" + job_name + " failed at " + current_time + " code " + str(error_code)
        #error_status = "Informatica Workflow Execution Failed"

        response = sfn_client.send_task_failure(
            taskToken=token,
            error=error_status,
            cause=error_msg)

    print (f'send token response is {response}')
    print (f'sub token return -done000 ')


print (f'entering python script')
n = len(sys.argv)
for i in range(1, n):
    print(sys.argv[i], end = " ")

token = sys.argv[1]
job_name = sys.argv[2]
error_code = sys.argv[3]
log_file_name = sys.argv[4]

print (f'reading in token {token}')
print (f'sub token return')


run_shellscript(token,job_name,error_code,log_file_name)
print (f'sub token return -done ')

