import sys
import json
import boto3
import time
from datetime import datetime
from pathlib import Path
import re

cwlogs_client = boto3.client('logs', region_name='us-east-1')
workflow_name = sys.argv[1]
session_id = sys.argv[2]
infa_log_ec2 = sys.argv[3]
timestamp =sys.argv[4]
log_group =sys.argv[5]

seq_token_wf = None
seq_token_sess = None

#log_group = '/ops/infa/ods'
log_stream_wf = workflow_name+'_'+timestamp
log_stream_sess = session_id+'_'+timestamp

log_file_wf=infa_log_ec2+'/WorkflowLogs'+'/'+workflow_name+'_'+timestamp+'.log'
log_file_sess=infa_log_ec2+'/SessLogs'+'/'+session_id+'_'+timestamp+'.log'


def create_logstream_wf(log_stream_wf):
    response = cwlogs_client.create_log_stream(
        logGroupName=log_group,
        logStreamName=log_stream_wf
    )

def put_logs_wf(log_stream,log_message,seq_token_wf):

    log_event = {
        'logGroupName' : log_group,
        'logStreamName' : log_stream_wf,
        'logEvents' : [
        {
            'timestamp': int(round(time.time() * 1000)),
            'message': log_message
        }
    ]
    }
    if seq_token_wf:
        log_event['sequenceToken'] = seq_token_wf

    response = cwlogs_client.put_log_events(**log_event)

    seq_token_wf = response['nextSequenceToken']

    #print(seq_token_wf)
    return(response)

def create_logstream_sess(log_stream_sess):
    response = cwlogs_client.create_log_stream(
        logGroupName=log_group,
        logStreamName=log_stream_sess
    )

def put_logs_sess(log_stream,log_message,seq_token_sess):

    log_event = {
        'logGroupName' : log_group,
        'logStreamName' : log_stream_sess,
        'logEvents' : [
        {
            'timestamp': int(round(time.time() * 1000)),
            'message': log_message
        }
    ]
    }
    if seq_token_sess:
        log_event['sequenceToken'] = seq_token_sess

    response = cwlogs_client.put_log_events(**log_event)

    seq_token_sess = response['nextSequenceToken']

    #print(seq_token_sess)
    return(response)

try:
    create_logstream_wf(log_stream_wf)
except Exception as e:
    print(e)

try:
    with open(log_file_wf) as f:
        while True:
            log_file_wf = f.read(252144)
            if not log_file_wf:
                break
            response=put_logs_wf(log_stream_wf,log_file_wf,seq_token_wf)
            seq_token_wf = response['nextSequenceToken']
        print("Workflow Logs Published Successfully to CloudWatch")
except Exception as e:
    print("WF Logs not published: ",e)

try:
    create_logstream_wf(log_stream_sess)
except Exception as e:
    print(e)

try:
    with open(log_file_sess) as f:
        while True:
            log_file_sess = f.read(252144)
            if not log_file_sess:
                break
            response=put_logs_sess(log_stream_sess,log_file_sess,seq_token_sess)
            seq_token_sess = response['nextSequenceToken']
        print("Session Logs published successfully in Cloudwatch")
except Exception as e:
    print("Sess Logs not Published: ",e)

