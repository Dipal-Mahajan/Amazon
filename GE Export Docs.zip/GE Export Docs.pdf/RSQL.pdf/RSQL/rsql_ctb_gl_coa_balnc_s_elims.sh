#-GE CONFIDENTIAL- or -GE HIGHLY CONFIDENTIAL-
#Type: Source Code
#Copyright (c) 2022, GE Healthcare
#All Rights Reserved
#This unpublished material is proprietary to GE Healthcare. The methods and
#techniques described herein are considered trade secrets and/or
#confidential. Reproduction or distribution, in whole or in part, is
#forbidden except by express written permission of GE Healthcare.


# <RSQL> SCRIPT NAME - rsql_ctb_gl_coa_balnc_s_elims.sh  </RSQL>
# <RSQL> SCRIPT DESCRIPTION - "Current RSQL is inserting data for elims to $STGDB.GL_COA_BALNC_S from $STGDB.GL_COA_HFM_ELIM_S table as a part of Global Balance Flow"  </RSQL>
# <RSQL> PARAMETER FILE NAME - ctb_parameter.sh.sh </RSQL>
# <RSQL>  SOURCE SCHEMA - $STGDB  </RSQL>
# <RSQL>  SOURCE TABLE  - GL_COA_HFM_ELIM_S  </RSQL>
# <RSQL>  TARGET SCHEMA - $STGDB  </RSQL>
# <RSQL>  TARGET TABLE  - GL_COA_BALNC_S </RSQL>
# <RSQL>  STMT TYPES    - INSERT  </RSQL>
# <RSQL>  CREATED ON    - 16-OCT-2022  </RSQL>
# <RSQL>  CREATED BY    - healthfinance.odpctb@ge.com  </RSQL>
# <RSQL>  LAST MODIFIED ON    - 22-NOV-2022  </RSQL>
# <RSQL>  LAST MODIFIED BY    - healthfinance.odpctb@ge.com  </RSQL>

echo "Calling the CTB Parameter file --> ctb_parameter.sh"
source /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "Printing Content of Parameter File"
cat /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

if [ $# -eq 0 ]
  then
    echo "No arguments supplied , Please pass the parameter value in 0 and 1 , 0 for open_period , 1 for future_period"
    exit 1
fi

if [ $5 -gt 1 ]
  then
    echo "Please pass argument between 0 and 1, 0 for open_period , 1 for future_period"
    exit 1
fi


period_param=$5

echo "period_param from param --> " $period_param

echo "--------------------------------------------------------"

echo "                              "
echo "Current RSQL is inserting data for elims to $STGDB.GL_COA_BALNC_S from $STGDB.GL_COA_HFM_ELIM_S table as a part of Global Balance Flow "
echo "                              "

script_started=$(date "+%F-%H-%M-%S")
echo "Script Started at --> $script_started"

start=`date +%s`


#source /ops/finance/common/scripts/get_redshift_creds.sh 'odp-fin-nprod-ctb-fsso' 'us-east-1'
source /ops/finance/common/scripts/aws_run_profile.sh $1 $2 $3 $4

rsql -h $HOST -U $USER -d $DB << EOF
\timing true
BEGIN ;

/* Set the Query Band for the session */

\echo '\n ----Setting Query Band to $QBSTR--------- \n'
SET query_group to '$QBSTR';

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 1
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\echo '\n ----Setting Search Path to $STGDB--------- \n'

/* ******************************Setting Database************************************************* */
SET SEARCH_PATH TO $STGDB, pg_catalog;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 2
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\set period_param $period_param

\echo "period_param --> " :period_param

/* ******************************Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;************************************ */

\echo '\n ----Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;--------- \n'


\if :period_param = 0
    \echo 'select perd_id  as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;'
      select perd_id  as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;
      \gset
    \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final
	    \if :ACTIVITYCOUNT = 0
           \echo 'period id future_perd_id is null so exiting . Please check and update the GL_COA_PERD_D table'
           \exit 1
        \endif

\elif :period_param = 1
    \echo 'SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;'
    SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;
    \gset
    \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final
        \if :ACTIVITYCOUNT = 0
           \echo 'future period id future_perd_id is null so exiting gracefully'
           \exit 0
        \endif

\else
    \echo 'Period parameter not in 0 and 1 so exiting the statement'
    \echo 'Error Code -'
    \remark :LAST_ERROR_MESSAGE
    \exit 1

\endif

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 3
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\set open_period '''':open_period_final''''

\echo "perd_id --> " :perd_id
\echo "open_period --> " :open_period

/* ******************************BTQ_FGL_120_DI_HFM_ELIM_GL_COA_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DI_HFM_ELIM_GL_COA_BALNC_FS.sh--------- \n'

\echo '\n ---Inserting data for elims to $STGDB.GL_COA_BALNC_S from $STGDB.GL_COA_HFM_ELIM_S table as a part of Global Balance Flow--------- \n'

INSERT INTO $STGDB.GL_COA_BALNC_S
(
LOCL_SEGMNT1_SYS_KEY ,
LOCL_SEGMNT2_SYS_KEY ,
LOCL_SEGMNT3_SYS_KEY ,
LOCL_SEGMNT4_SYS_KEY ,
LOCL_SEGMNT5_SYS_KEY ,
LOCL_SEGMNT6_SYS_KEY ,
LOCL_SEGMNT7_SYS_KEY ,
LOCL_SEGMNT8_SYS_KEY ,
LOCL_SEGMNT9_SYS_KEY ,
LOCL_SEGMNT10_SYS_KEY ,
LOCL_SEGMNT11_SYS_KEY ,
LOCL_SEGMNT1_KEY,
LOCL_SEGMNT2_KEY,
LOCL_SEGMNT3_KEY,
LOCL_SEGMNT4_KEY,
LOCL_SEGMNT5_KEY,
LOCL_SEGMNT6_KEY,
LOCL_SEGMNT7_KEY,
LOCL_SEGMNT8_KEY,
LOCL_SEGMNT9_KEY,
LOCL_SEGMNT10_KEY,
LOCL_SEGMNT11_KEY,
ES_SEGMNT1_KEY,
ES_SEGMNT2_KEY,
ES_SEGMNT3_KEY,
ES_SEGMNT4_KEY,
ES_SEGMNT5_KEY,
ES_SEGMNT6_KEY,
ES_SEGMNT7_KEY,
ES_SEGMNT8_KEY,
ES_SEGMNT9_KEY,
ES_SEGMNT10_KEY,
ES_SEGMNT11_KEY,
LOCL_SEGMNT_KEY,
LOCL_SEGMNT_KEY_DESC,
ICP_KEY,
ICP_MAP_KEY,
ICP_ALT_MAP_KEY,
SET_OF_BOK_KEY,
CD_COMBN_KEY,
BALNC_TYP_KEY,
LOCL_CURR_MAIN_KEY,
TRANS_CURR_MAIN_KEY,
TIM_MAIN_PERD_KEY,
PART_NAM,
FC_PERD_NET_DR_AMT,
FC_PERD_NET_CR_AMT,
FC_YTD_BALNC_DR_AMT,
FC_YTD_BALNC_CR_AMT,
FC_YTD_BALNC_NET_AMT,
MOR_RT,
PREV_YR_MOR_RT,
MOR_PERD_NET_DR_AMT,
MOR_PERD_NET_CR_AMT,
MOR_YTD_BALNC_DR_AMT,
MOR_YTD_BALNC_CR_AMT,
GAP_RT,
PREV_YR_GAP_RT,
GAP_PERD_NET_DR_AMT,
GAP_PERD_NET_CR_AMT,
GAP_YTD_BALNC_DR_AMT,
GAP_YTD_BALNC_CR_AMT,
HIST_RT,
PREV_YR_HIST_RT,
HIST_AMT,
FCTA_PERD_NET_DR_AMT,
FCTA_PERD_NET_CR_AMT,
FCTA_YTD_BALNC_DR_AMT,
FCTA_YTD_BALNC_CR_AMT,
APPLD_RT,
PREV_YR_APPLD_RT,
APPLD_PERD_NET_DR_AMT,
APPLD_PERD_NET_CR_AMT,
APPLD_YTD_BALNC_DR_AMT,
APPLD_YTD_BALNC_CR_AMT,
APPLD_FLAG,
OP_RT,
PREV_YR_OP_RT,
OP_PERD_NET_DR_AMT,
OP_PERD_NET_CR_AMT,
OP_YTD_BALNC_DR_AMT,
OP_YTD_BALNC_CR_AMT,
TRANSLTD_FLAG,
PERD_ID,
LOAD_ID,
CHANGE_SIGN,
BALNC_DAT_TYP,
ATRBT_1,
ATRBT_2,
ATRBT_3,
ATRBT_4,
ATRBT_5,
LEDGR_CATGRY_CD,
SRC_SYS_ID,
DATA_ORIGIN,
POSTING_AGENT,
SOURCE_NAME,
SOURCE_CREATION_ID,
SOURCE_CREATION_DTM,
SOURCE_UPDATE_ID,
SOURCE_UPDATE_DTM,
LOAD_DTM,
UPDATE_DTM,
MEMO_FLD1,
MEMO_FLD2,
ES_SEGMNT1_SYS_KEY ,
ES_SEGMNT2_SYS_KEY ,
ES_SEGMNT3_SYS_KEY ,
ES_SEGMNT4_SYS_KEY ,
ES_SEGMNT5_SYS_KEY ,
ES_SEGMNT6_SYS_KEY ,
ES_SEGMNT7_SYS_KEY ,
ES_SEGMNT8_SYS_KEY ,
ES_SEGMNT9_SYS_KEY ,
ES_SEGMNT10_SYS_KEY ,
ES_SEGMNT11_SYS_KEY ,
SET_OF_BOK_SYS_KEY , 
LOCL_CURR_MAIN_SYS_KEY , 
TRANS_CURR_MAIN_SYS_KEY , 
TIM_MAIN_PERD_SYS_KEY,
FISCL_YEAR,
FISCL_MONTH,
BALNC_TYP_DESC
)
SELECT
       A.LOCL_SEGMNT1_KEY||'~'||'GLPROD'||'~'||'ECA_CO' ,
	   A.LOCL_SEGMNT2_KEY||'~'||'GLPROD'||'~'||'ECA_AC' ,
	   A.LOCL_SEGMNT3_KEY||'~'||'GLPROD'||'~'||'ECA_TP' ,
	   A.LOCL_SEGMNT4_KEY||'~'||'GLPROD'||'~'||'ECA_CC' ,
	   A.LOCL_SEGMNT5_KEY||'~'||'GLPROD'||'~'||'ECA_GO' ,
	   A.LOCL_SEGMNT6_KEY||'~'||'GLPROD'||'~'||'ECA_PR' ,
	   A.LOCL_SEGMNT7_KEY||'~'||'GLPROD'||'~'||'ECA_RF' ,
	   A.LOCL_SEGMNT8_KEY||'~'||'GLPROD'||'~'||'ECA_PL' ,
	   A.LOCL_SEGMNT9_KEY||'~'||'GLPROD'||'~'||'ECA_BT' ,
	   A.LOCL_SEGMNT10_KEY||'~'||'GLPROD'||'~'||'ECA_FU1' ,
	   A.LOCL_SEGMNT11_KEY||'~'||'GLPROD'||'~'||'ECA_FU2' ,
       A.LOCL_SEGMNT1_KEY  AS LOCL_SEGMNT1_KEY,
       A.LOCL_SEGMNT2_KEY  AS LOCL_SEGMNT2_KEY,
       A.LOCL_SEGMNT3_KEY  AS LOCL_SEGMNT3_KEY,
       A.LOCL_SEGMNT4_KEY  AS LOCL_SEGMNT4_KEY,
       A.LOCL_SEGMNT5_KEY  AS LOCL_SEGMNT5_KEY,
       A.LOCL_SEGMNT6_KEY  AS LOCL_SEGMNT6_KEY,
       A.LOCL_SEGMNT7_KEY  AS LOCL_SEGMNT7_KEY,
       A.LOCL_SEGMNT8_KEY  AS LOCL_SEGMNT8_KEY,
       A.LOCL_SEGMNT9_KEY  AS LOCL_SEGMNT9_KEY,
       A.LOCL_SEGMNT10_KEY AS LOCL_SEGMNT10_KEY,
       A.LOCL_SEGMNT11_KEY AS LOCL_SEGMNT11_KEY,
       A.ES_SEGMNT1_KEY    AS ES_SEGMNT1_KEY,
       A.ES_SEGMNT2_KEY    AS ES_SEGMNT2_KEY,
       A.ES_SEGMNT3_KEY    AS ES_SEGMNT3_KEY,
       A.ES_SEGMNT4_KEY    AS ES_SEGMNT4_KEY,
       A.ES_SEGMNT5_KEY    AS ES_SEGMNT5_KEY,
       A.ES_SEGMNT6_KEY    AS ES_SEGMNT6_KEY,
       A.ES_SEGMNT7_KEY    AS ES_SEGMNT7_KEY,
       A.ES_SEGMNT8_KEY    AS ES_SEGMNT8_KEY,
       A.ES_SEGMNT9_KEY    AS ES_SEGMNT9_KEY,
       A.ES_SEGMNT10_KEY   AS ES_SEGMNT10_KEY,
       A.ES_SEGMNT11_KEY   AS ES_SEGMNT11_KEY,
	   A.LOCL_SEGMNT1_KEY||'.'||A.LOCL_SEGMNT2_KEY||'.'||A.LOCL_SEGMNT3_KEY||'.'||A.LOCL_SEGMNT4_KEY||'.'||A.LOCL_SEGMNT5_KEY||'.'||A.LOCL_SEGMNT6_KEY||'.'||A.LOCL_SEGMNT7_KEY||'.'||A.LOCL_SEGMNT8_KEY||'.'||A.LOCL_SEGMNT9_KEY||'.'||'000000000.000000'  AS LOCL_SEGMNT_KEY,
       A.LOCL_SEGMNT1_KEY||'.'||A.LOCL_SEGMNT2_KEY||'.'||A.LOCL_SEGMNT3_KEY||'.'||A.LOCL_SEGMNT4_KEY||'.'||A.LOCL_SEGMNT5_KEY||'.'||A.LOCL_SEGMNT6_KEY||'.'||A.LOCL_SEGMNT7_KEY||'.'||A.LOCL_SEGMNT8_KEY||'.'||A.LOCL_SEGMNT9_KEY||'.'||'000000000.000000'||'.'||A.CURR_MAIN_KEY||'.'||A.TIM_MAIN_PERD_KEY  AS LOCL_SEGMNT_KEY_DESC,
       'N/A'               AS ICP_KEY,
       'N/A'               AS ICP_MAP_KEY,
       'N/A'               AS ICP_ALT_MAP_KEY,
       A.SET_OF_BOK_KEY    AS SET_OF_BOK_KEY,
       A.CD_COMBN_KEY      AS CD_COMBN_KEY,
       A.BALNC_TYP_KEY     AS BALNC_TYP_KEY,
       A.CURR_MAIN_KEY     AS LOCL_CURR_MAIN_KEY,
       A.CURR_MAIN_KEY     AS TRANS_CURR_MAIN_KEY,
       A.TIM_MAIN_PERD_KEY AS TIM_MAIN_PERD_KEY,
       'N/A'               AS PART_NAM,
       0                   AS FC_PERD_NET_DR_AMT,
       0                   AS FC_PERD_NET_CR_AMT,
       0                   AS FC_YTD_BALNC_DR_AMT,
       0                   AS FC_YTD_BALNC_CR_AMT,
       0                   AS FC_YTD_BALNC_NET_AMT,
       0                   AS MOR_RT,
       0                   AS PREV_YR_MOR_RT,
       0                   AS MOR_PERD_NET_DR_AMT,
       0                   AS MOR_PERD_NET_CR_AMT,
       0                   AS MOR_YTD_BALNC_DR_AMT,
       0                   AS MOR_YTD_BALNC_CR_AMT,
       0                   AS GAP_RT,
       0                   AS PREV_YR_GAP_RT,
       0                   AS GAP_PERD_NET_DR_AMT,
       0                   AS GAP_PERD_NET_CR_AMT,
       0                   AS GAP_YTD_BALNC_DR_AMT,
       0                   AS GAP_YTD_BALNC_CR_AMT,
       0                   AS HIST_RT,
       0                   AS PREV_YR_HIST_RT,
       0                   AS HIST_AMT,
       0                   AS FCTA_PERD_NET_DR_AMT,
       0                   AS FCTA_PERD_NET_CR_AMT,
       0                   AS FCTA_YTD_BALNC_DR_AMT,
       0                   AS FCTA_YTD_BALNC_CR_AMT,
       1                   AS APPLD_RT,
       0                   AS PREV_YR_APPLD_RT,
       A.YTD_BALNC_DR_AMT  AS APPLD_PERD_NET_DR_AMT,
       0                   AS APPLD_PERD_NET_CR_AMT,
       A.YTD_BALNC_DR_AMT  AS APPLD_YTD_BALNC_DR_AMT,
       0                   AS APPLD_YTD_BALNC_CR_AMT,
       'ELIM'              AS APPLD_FLAG,
       0                   AS OP_RT,
       0                   AS PREV_YR_OP_RT,
       0                   AS OP_PERD_NET_DR_AMT,
       0                   AS OP_PERD_NET_CR_AMT,
       0                   AS OP_YTD_BALNC_DR_AMT,
       0                   AS OP_YTD_BALNC_CR_AMT,
       NULL                AS TRANSLTD_FLAG,
       A.PERD_ID           AS PERD_ID,
       '1'                 AS LOAD_ID,
       '1'                 AS CHANGE_SIGN,
       'ADJ'               AS FINAL_BALNC_DAT_TYP,
       'N/A'               AS ATRBT_1,
       'N/A'               AS ATRBT_2,
       'N/A'               AS ATRBT_3,
       'N/A'               AS ATRBT_4,
       'N/A'               AS ATRBT_5,
       'PRIMARY'           AS LEDGR_CATGRY_CD,
       A.CD_COMBN_KEY||'~'||COALESCE(A.SET_OF_BOK_KEY,'')||'~'||COALESCE(A.CURR_MAIN_KEY,'')||'~'||A.BALNC_TYP_KEY||'~'||A.PERD_ID||'~'||'1'||'~'||'GLPROD'||'~'||FINAL_BALNC_DAT_TYP AS SRC_SYS_ID,
       A.DATA_ORIGIN           AS DAT_ORGN,
       'rsql_ctb_gl_coa_balnc_s_elims.sh'       AS POSTING_AGENT,
       'GLPROD'            AS SOURCE_NAME,
       COALESCE(A.SOURCE_CREATION_ID,'-99999')              AS SOURCE_CREATION_ID ,
       A.SOURCE_CREATION_DTM       AS SOURCE_CREATION_DTM ,
       COALESCE(A.SOURCE_UPDATE_ID ,'-99999')               AS SOURCE_UPDATE_ID ,
       A.SOURCE_UPDATE_DTM         AS SOURCE_UPDATE_DTM ,
       A.LOAD_DTM      AS LOAD_DTM ,
       A.UPDATE_DTM         AS UPDATE_DTM ,
       'N/A'               AS MEMO_FLD1,
       'N/A'               AS MEMO_FLD2,
	   A.ES_SEGMNT1_KEY||'~'||'ECA'||'~'||'ECA_CO' ,
	   A.ES_SEGMNT2_KEY||'~'||'ECA'||'~'||'ECA_AC' ,
	   A.ES_SEGMNT3_KEY||'~'||'ECA'||'~'||'ECA_TP' ,
	   A.ES_SEGMNT4_KEY||'~'||'ECA'||'~'||'ECA_CC' ,
	   A.ES_SEGMNT5_KEY||'~'||'ECA'||'~'||'ECA_GO' ,
	   A.ES_SEGMNT6_KEY||'~'||'ECA'||'~'||'ECA_PR' ,
	   A.ES_SEGMNT7_KEY||'~'||'ECA'||'~'||'ECA_RF' ,
	   A.ES_SEGMNT8_KEY||'~'||'ECA'||'~'||'ECA_PL' ,
	   A.ES_SEGMNT9_KEY||'~'||'ECA'||'~'||'ECA_BT' ,
	   A.ES_SEGMNT10_KEY||'~'||'ECA'||'~'||'ECA_FU1' ,
	   A.ES_SEGMNT11_KEY||'~'||'ECA'||'~'||'ECA_FU2' ,
	   Case when A.SET_OF_BOK_KEY='-1' then '-99999' 
	   else A.SET_OF_BOK_KEY||'~'||'GLPROD' 
	   end AS SET_OF_BOK_SYS_KEY,
	   Case when A.CURR_MAIN_KEY  is null then '-99999' 
	   else A.CURR_MAIN_KEY||'~'||'GLPROD'
	   end AS LOCL_CURR_MAIN_SYS_KEY,
	   Case when A.CURR_MAIN_KEY is null  then '-99999' 
	   else A.CURR_MAIN_KEY||'~'||'GLPROD'
	   end AS TRANS_CURR_MAIN_SYS_KEY,
	   A.PERD_ID||'~'||'GEMS_CALENDAR'||'~'||'1'||'~'||'GLPROD' as TIM_MAIN_PERD_SYS_KEY,
	   cast(SUBSTR(TRIM(:perd_id), 1, 4) as INTEGER) AS FISCL_YEAR,
       cast(SUBSTR(TRIM(:perd_id), 5, 2) as INTEGER) AS FISCL_MONTH,
	   'SYS' as BALNC_TYP_DESC
FROM   $STGDB.GL_COA_HFM_ELIM_S A
     WHERE A.PERD_ID in (:perd_id);


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 4
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

COMMIT;

end;

EOF

rsqlexitcode=$?

echo "Elims Insertion Completed for Global Balance"

echo "Exited with error code $rsqlexitcode"
echo "---------------------------------"

script_ended=$(date "+%F-%H-%M-%S")
echo "Script ended at --> $script_ended"

end=`date +%s`
exec=`expr $end - $start`
time_taken=`date -d@$exec -u +%H:%M:%S`

echo "Time Taken --> $time_taken"

python3 /ops/finance/common/scripts/send_sfn_token.py $token $script_name $rsqlexitcode $log_file_name

exit $rsqlexitcode