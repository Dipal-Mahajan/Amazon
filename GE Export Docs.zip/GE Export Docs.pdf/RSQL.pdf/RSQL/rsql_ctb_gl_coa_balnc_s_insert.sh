#-GE CONFIDENTIAL- or -GE HIGHLY CONFIDENTIAL-
#Type: Source Code
#Copyright (c) 2022, GE Healthcare
#All Rights Reserved
#This unpublished material is proprietary to GE Healthcare. The methods and
#techniques described herein are considered trade secrets and/or
#confidential. Reproduction or distribution, in whole or in part, is
#forbidden except by express written permission of GE Healthcare.


# <RSQL> SCRIPT NAME - rsql_ctb_gl_coa_balnc_s_insert.sh  </RSQL>
# <RSQL> SCRIPT DESCRIPTION - "Current RSQL is inserting data to $STGDB.GL_COA_BALNC_S from $TGTDB.GL_LOCL_BALNC_F table as a part of Global Balance Flow"  </RSQL>
# <RSQL> PARAMETER FILE NAME - ctb_parameter.sh.sh </RSQL>
# <RSQL>  SOURCE SCHEMA - $TGTDB  </RSQL>
# <RSQL>  SOURCE TABLE  - GL_LOCL_BALNC_F  </RSQL>
# <RSQL>  TARGET SCHEMA - $STGDB  </RSQL>
# <RSQL>  TARGET TABLE  - GL_COA_BALNC_S </RSQL>
# <RSQL>  STMT TYPES    - TRUNCATE , INSERT, SELECT , UPDATE  </RSQL>
# <RSQL>  CREATED ON    - 16-OCT-2022  </RSQL>
# <RSQL>  CREATED BY    - healthfinance.odpctb@ge.com  </RSQL>
# <RSQL>  LAST MODIFIED ON    - 22-NOV-2022  </RSQL>
# <RSQL>  LAST MODIFIED BY    - healthfinance.odpctb@ge.com  </RSQL>


echo "Calling the CTB Parameter file --> ctb_parameter.sh"
source /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "Printing Content of Parameter File"
cat /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

if [ $# -eq 0 ]
  then
    echo "No arguments supplied , Please pass the parameter value in 0 and 1 , 0 for open_period , 1 for future_period"
    exit 1
fi

if [ $5 -gt 1 ]
  then
    echo "Please pass argument between 0 and 1, 0 for open_period , 1 for future_period"
    exit 1
fi

echo "Capturing the argument passed in period param variable to process it furthur"
period_param=$5

echo "period_param from param --> " $period_param

echo "--------------------------------------------------------"

echo "                              "
echo "Current RSQL is inserting data to $STGDB.GL_COA_BALNC_S from $TGTDB.GL_LOCL_BALNC_F depending on transformation logic "
echo "                              "

script_started=$(date "+%F-%H-%M-%S")
echo "Script Started at --> $script_started"

start=`date +%s`

#source /ops/finance/common/scripts/get_redshift_creds.sh 'odp-fin-nprod-ctb-fsso' 'us-east-1'
source /ops/finance/common/scripts/aws_run_profile.sh $1 $2 $3 $4


rsql -h $HOST -U $USER -d $DB << EOF
\timing true
BEGIN ;

/* Set the Query Band for the session */

\echo '\n ----Setting Query Band to $QBSTR--------- \n'
SET query_group to '$QBSTR';

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 1
\else
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\echo '\n ----Setting Search Path to $STGDB--------- \n'

/* ******************************Setting Database************************************************* */
SET SEARCH_PATH TO $STGDB, pg_catalog;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 2
\else
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\set period_param $period_param

\echo "period_param --> " :period_param

/* ******************************Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;************************************ */

\echo '\n ----Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;--------- \n'


\if :period_param = 0
    \echo ' select perd_id  as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;'
      select perd_id  as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;
      \gset
    \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final

\elif :period_param = 1
    \echo 'SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;'
    SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;
    \gset
     \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final
        \if :ACTIVITYCOUNT = 0
           \echo 'future period id future_perd_id is null so exiting gracefully'
           \exit 0
        \endif

\else
    \echo 'Period parameter not in 0 and 1 so exiting the statement'
    \echo 'Error Code -'
    \remark :LAST_ERROR_MESSAGE
    \exit 1

\endif

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 3
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\set open_period '''':open_period_final''''

\echo "open_period --> " :open_period

/* ******************************BTQ_FGL_120_DI_DWH_OSTG_GLOBL_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq to RSQL BTQ_FGL_120_DI_DWH_OSTG_GLOBL_BALNC_FS.sh--------- \n'
\echo '\n ----Truncating Table $STGDB.GL_COA_BALNC_S --------- \n'

CALL $CMN_SP_DB.SP_STAGE_TRUNCATE('$STGDB','GL_COA_BALNC_S');

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 4
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\echo '\n ----Inserting data to $STGDB.GL_COA_BALNC_S from $TGTDB.GL_LOCL_BALNC_F for all three sources - GLPROD , BIO-SAPEU and HCIT-PS9--------- \n'

INSERT INTO $STGDB.GL_COA_BALNC_S
  (
   LOCL_SEGMNT1_SYS_KEY ,
   LOCL_SEGMNT2_SYS_KEY ,
   LOCL_SEGMNT3_SYS_KEY ,
   LOCL_SEGMNT4_SYS_KEY ,
   LOCL_SEGMNT5_SYS_KEY ,
   LOCL_SEGMNT6_SYS_KEY ,
   LOCL_SEGMNT7_SYS_KEY ,
   LOCL_SEGMNT8_SYS_KEY ,
   LOCL_SEGMNT9_SYS_KEY ,
   LOCL_SEGMNT10_SYS_KEY ,
   LOCL_SEGMNT11_SYS_KEY ,
   LOCL_SEGMNT1_KEY,
   LOCL_SEGMNT2_KEY,
   LOCL_SEGMNT3_KEY,
   LOCL_SEGMNT4_KEY,
   LOCL_SEGMNT5_KEY,
   LOCL_SEGMNT6_KEY,
   LOCL_SEGMNT7_KEY,
   LOCL_SEGMNT8_KEY,
   LOCL_SEGMNT9_KEY,
   LOCL_SEGMNT10_KEY,
   LOCL_SEGMNT11_KEY,
   LOCL_SEGMNT_KEY,
   LOCL_SEGMNT_KEY_DESC,
   ICP_KEY,
   ICP_MAP_KEY,
   ICP_ALT_MAP_KEY,
   SET_OF_BOK_KEY,
   CD_COMBN_KEY,
   BALNC_TYP_KEY,
   LOCL_CURR_MAIN_KEY ,
   TIM_MAIN_PERD_KEY,
   PART_NAM,
   BEGIN_BALANCE_DR_AMT,
   BEGIN_BALANCE_CR_AMT,
   FC_PERD_NET_DR_AMT,
   FC_PERD_NET_CR_AMT,
   FC_YTD_BALNC_DR_AMT,
   FC_YTD_BALNC_CR_AMT,
   FC_YTD_BALNC_NET_AMT,
   MOR_RT,
   MOR_PERD_NET_DR_AMT,
   MOR_PERD_NET_CR_AMT,
   MOR_YTD_BALNC_DR_AMT,
   MOR_YTD_BALNC_CR_AMT,
   GAP_RT,
   GAP_PERD_NET_DR_AMT,
   GAP_PERD_NET_CR_AMT,
   GAP_YTD_BALNC_DR_AMT,
   GAP_YTD_BALNC_CR_AMT,
   HIST_RT,
   HIST_AMT,
   FCTA_PERD_NET_DR_AMT,
   FCTA_PERD_NET_CR_AMT,
   FCTA_YTD_BALNC_DR_AMT,
   FCTA_YTD_BALNC_CR_AMT,
   APPLD_RT,
   APPLD_PERD_NET_DR_AMT,
   APPLD_PERD_NET_CR_AMT,
   APPLD_YTD_BALNC_DR_AMT,
   APPLD_YTD_BALNC_CR_AMT,
   APPLD_FLAG,
   OP_RT,
   OP_PERD_NET_DR_AMT,
   OP_PERD_NET_CR_AMT,
   OP_YTD_BALNC_DR_AMT,
   OP_YTD_BALNC_CR_AMT,
   TRANSLTD_FLAG,
   LOAD_ID,
   PERD_ID,
   CHANGE_SIGN,
   BALNC_DAT_TYP,
   ATRBT_1,
   ATRBT_2,
   ATRBT_3,
   ATRBT_4,
   ATRBT_5,
   SRC_SYS_ID,
   SOURCE_CREATION_ID,
   SOURCE_CREATION_DTM,
   SOURCE_UPDATE_ID,
   SOURCE_UPDATE_DTM,
   DATA_ORIGIN,
   POSTING_AGENT,
   source_name,
   LOAD_DTM,
   UPDATE_DTM,
   MEMO_FLD1,
   MEMO_FLD2,
   ES_SEGMNT1_KEY,
   ES_SEGMNT2_KEY,
   ES_SEGMNT3_KEY,
   ES_SEGMNT4_KEY,
   ES_SEGMNT5_KEY,
   ES_SEGMNT6_KEY,
   ES_SEGMNT7_KEY,
   ES_SEGMNT8_KEY,
   ES_SEGMNT9_KEY,
   ES_SEGMNT10_KEY,
   ES_SEGMNT11_KEY,
   ES_SEGMNT1_SYS_KEY ,
   ES_SEGMNT2_SYS_KEY ,
   ES_SEGMNT3_SYS_KEY ,
   ES_SEGMNT4_SYS_KEY ,
   ES_SEGMNT5_SYS_KEY ,
   ES_SEGMNT6_SYS_KEY ,
   ES_SEGMNT7_SYS_KEY ,
   ES_SEGMNT8_SYS_KEY ,
   ES_SEGMNT9_SYS_KEY ,
   ES_SEGMNT10_SYS_KEY ,
   ES_SEGMNT11_SYS_KEY ,
   SET_OF_BOK_SYS_KEY , 
   LOCL_CURR_MAIN_SYS_KEY , 
   TRANS_CURR_MAIN_SYS_KEY , 
   TIM_MAIN_PERD_SYS_KEY,
   RECORD_FLAG,
   FISCL_YEAR,
   FISCL_MONTH,
   BALNC_TYP_DESC
   )
     SELECT 
         CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT1_KEY || '~' ||'GLPROD'|| '~' ||'ECA_CO' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'LB_'||LOCL.LOCL_SEGMNT1_KEY || '~' ||'ECA'|| '~' ||'ECA_CO' 
         END as LOCL_SEGMNT1_SYS_KEY, 
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT2_KEY || '~' ||'GLPROD'|| '~' ||'ECA_AC' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'AC_'||LOCL.LOCL_SEGMNT2_KEY || '~' ||'ECA'|| '~' ||'ECA_AC' 
         END as LOCL_SEGMNT2_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT3_KEY || '~' ||'GLPROD'|| '~' ||'ECA_TP' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'TP_'||LOCL.LOCL_SEGMNT3_KEY || '~' ||'ECA'|| '~' ||'ECA_TP' 
         END as LOCL_SEGMNT3_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT4_KEY || '~' ||'GLPROD'|| '~' ||'ECA_CC' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'CC_'||LOCL.LOCL_SEGMNT4_KEY || '~' ||'ECA'|| '~' ||'ECA_CC' 
         END as LOCL_SEGMNT4_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT5_KEY || '~' ||'GLPROD'|| '~' ||'ECA_GO' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'GO_'||LOCL.LOCL_SEGMNT5_KEY || '~' ||'ECA'|| '~' ||'ECA_GO' 
         END as LOCL_SEGMNT5_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT6_KEY || '~' ||'GLPROD'|| '~' ||'ECA_PR' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'PR_'||LOCL.LOCL_SEGMNT6_KEY || '~' ||'ECA'|| '~' ||'ECA_PR' 
         END as LOCL_SEGMNT6_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT7_KEY || '~' ||'GLPROD'|| '~' ||'ECA_RF' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'RF_'||LOCL.LOCL_SEGMNT7_KEY || '~' ||'ECA'|| '~' ||'ECA_RF' 
         END as LOCL_SEGMNT7_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT8_KEY || '~' ||'GLPROD'|| '~' ||'ECA_PL' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'PL_'||LOCL.LOCL_SEGMNT8_KEY || '~' ||'ECA'|| '~' ||'ECA_PL' 
         END as LOCL_SEGMNT8_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT9_KEY || '~' ||'GLPROD'|| '~' ||'ECA_BT' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'BT_'||LOCL.LOCL_SEGMNT9_KEY || '~' ||'ECA'|| '~' ||'ECA_BT' 
         END as LOCL_SEGMNT9_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT10_KEY || '~' ||'GLPROD'|| '~' ||'ECA_FU1' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'FU_'||LOCL.LOCL_SEGMNT10_KEY || '~' ||'ECA'|| '~' ||'ECA_FU1' 
         END as LOCL_SEGMNT10_SYS_KEY ,
		 CASE WHEN LOCL.source_name='GLPROD' then LOCL.LOCL_SEGMNT11_KEY || '~' ||'GLPROD'|| '~' ||'ECA_FU2' 
	     WHEN LOCL.source_name in ('HCIT_PS9','BIO-SAPEU')  then 'FU_'||LOCL.LOCL_SEGMNT11_KEY || '~' ||'ECA'|| '~' ||'ECA_FU2' 
         END as LOCL_SEGMNT11_SYS_KEY ,
		 COALESCE(LOCL.LOCL_SEGMNT1_KEY,'N/A') as LOCL_SEGMNT1_KEY,
         COALESCE(LOCL.LOCL_SEGMNT2_KEY,'N/A') as LOCL_SEGMNT2_KEY,
         COALESCE(LOCL.LOCL_SEGMNT3_KEY,'N/A') as LOCL_SEGMNT3_KEY,
         COALESCE(LOCL.LOCL_SEGMNT4_KEY,'N/A') as LOCL_SEGMNT4_KEY,
         COALESCE(LOCL.LOCL_SEGMNT5_KEY,'N/A') as LOCL_SEGMNT5_KEY,
         COALESCE(LOCL.LOCL_SEGMNT6_KEY,'N/A') as LOCL_SEGMNT6_KEY,
         COALESCE(LOCL.LOCL_SEGMNT7_KEY,'N/A') as LOCL_SEGMNT7_KEY,
         COALESCE(LOCL.LOCL_SEGMNT8_KEY,'N/A') as LOCL_SEGMNT8_KEY,
         COALESCE(LOCL.LOCL_SEGMNT9_KEY,'N/A') as LOCL_SEGMNT9_KEY,
         COALESCE(LOCL.LOCL_SEGMNT10_KEY,'N/A') as LOCL_SEGMNT10_KEY,
         COALESCE(LOCL.LOCL_SEGMNT11_KEY,'N/A') as LOCL_SEGMNT11_KEY,	COALESCE(LOCL.LOCL_SEGMNT1_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT2_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT3_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT4_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT5_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT6_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT7_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT8_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT9_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT10_KEY,'N/A')||'.'||COALESCE(LOCL.LOCL_SEGMNT11_KEY,'N/A') AS LOCL_SEGMNT_KEY,
         LOCL.LOCL_SEGMNT_KEY_DESC as LOCL_SEGMNT_KEY_DESC, 
         'N/A' AS ICP_KEY,
         'N/A' AS ICP_MAP_KEY,
         'N/A' AS ICP_ALT_MAP_KEY,
         LOCL.SET_OF_BOK_KEY as SET_OF_BOK_KEY,
         LOCL.CD_COMBN_KEY as CD_COMBN_KEY,
         '6' AS FINAL_BALNC_TYP_KEY,
         LOCL.CURR_MAIN_KEY as LOCL_CURR_MAIN_KEY,
         LOCL.TIM_MAIN_PERD_KEY as TIM_MAIN_PERD_KEY,
         'N/A' AS PART_NAM,
         LOCL.BEGIN_BALANCE_DR_AMT as BEGIN_BALANCE_DR_AMT,
         LOCL.BEGIN_BALANCE_CR_AMT as BEGIN_BALANCE_CR_AMT,
         LOCL.PERIOD_NET_DR_AMT as FC_PERD_NET_DR_AMT,
         LOCL.PERIOD_NET_CR_AMT as FC_PERD_NET_CR_AMT,
         LOCL.YTD_BALNC_DR_AMT as FC_YTD_BALNC_DR_AMT,
         LOCL.YTD_BALNC_CR_AMT as FC_YTD_BALNC_CR_AMT,
         CASE WHEN LOCL.SOURCE_NAME = 'HCIT_PS9' THEN 0 ELSE (LOCL.YTD_BALNC_DR_AMT-LOCL.YTD_BALNC_CR_AMT) END AS FC_YTD_BALNC_NET_AMT,
         0 AS MOR_RT,
         0 AS MOR_PERD_NET_DR_AMT,
         0 AS MOR_PERD_NET_CR_AMT,
         0 AS MOR_YTD_BALNC_DR_AMT,
         0 AS MOR_YTD_BALNC_CR_AMT,
         0 AS GAP_RT,
         0 AS GAP_PERD_NET_DR_AMT,
         0 AS GAP_PERD_NET_CR_AMT,
         0 AS GAP_YTD_BALNC_DR_AMT,
         0 AS GAP_YTD_BALNC_CR_AMT,
         0 AS HIST_RT,
         0 AS HIST_AMT,
         0 AS FCTA_PERD_NET_DR_AMT,
         0 AS FCTA_PERD_NET_CR_AMT,
         0 AS FCTA_YTD_BALNC_DR_AMT,
         0 AS FCTA_YTD_BALNC_CR_AMT,
         0 AS APPLD_RT,
         0 AS APPLD_PERD_NET_DR_AMT,
         0 AS APPLD_PERD_NET_CR_AMT,
         0 AS APPLD_YTD_BALNC_DR_AMT,
         0 AS APPLD_YTD_BALNC_CR_AMT,
         'DEFAULT' AS APPLD_FLAG,
         LOCL.OP_RT,
         LOCL.OP_PERD_NET_DR_AMT,
         LOCL.OP_PERD_NET_CR_AMT,
         LOCL.OP_YTD_BALNC_DR_AMT,
         LOCL.OP_YTD_BALNC_CR_AMT,
         LOCL.TRANSLTD_FLAG,
         LOCL.LOAD_ID,
         LOCL.PERD_ID,
          1 as CHANGE_SIGN,
         'SYS' AS FINAL_BALNC_DAT_TYP,
         LOCL.ATRBT_1,
         LOCL.ATRBT_2,
         LOCL.LOAD_ID,
         LOCL.ATRBT_4,
         LOCL.ATRBT_5,
         CASE 
			WHEN LOCL.SOURCE_NAME IN ('GLPROD','BIO-SAPEU') 
			THEN LOCL.CD_COMBN_KEY||'~'||LOCL.SET_OF_BOK_KEY||'~'||LOCL.CURR_MAIN_KEY||'~'||FINAL_BALNC_TYP_KEY||'~'||LOCL.PERD_ID||'~'||LOCL.LOAD_ID||'~'||LOCL.SOURCE_NAME||'~'||FINAL_BALNC_DAT_TYP
			WHEN LOCL.SOURCE_NAME IN ('HCIT_PS9')
			THEN COALESCE(LOCL.ATRBT_1,'NA')||'~'||LOCL.CD_COMBN_KEY||'~'||LOCL.SET_OF_BOK_KEY||'~'||LOCL.CURR_MAIN_KEY||'~'||FINAL_BALNC_TYP_KEY||'~'||LOCL.PERD_ID||'~'||LOCL.LOAD_ID||'~'||LOCL.SOURCE_NAME||'~'||FINAL_BALNC_DAT_TYP
		 END AS SRC_SYS_ID,
         LOCL.SOURCE_CREATION_ID,
         LOCL.SOURCE_CREATION_DTM,
         LOCL.SOURCE_UPDATE_ID,
         LOCL.SOURCE_UPDATE_DTM,
         LOCL.DATA_ORIGIN,
         'rsql_ctb_gl_coa_balnc_s_insert.sh' as POSTING_AGENT,
         LOCL.source_name,
         CURRENT_TIMESTAMP(0),
         CURRENT_TIMESTAMP(0),
		 CASE WHEN LOCL.SOURCE_NAME = 'HCIT_PS9' THEN 'AC_SUSPENSE' ELSE 'N/A' END,
         CASE WHEN LOCL.SOURCE_NAME = 'HCIT_PS9' THEN 'OR_INP_SUSPENSE' ELSE 'N/A' END,
		 'LB_'||LOCL.LOCL_SEGMNT1_KEY AS ES_SEGMNT1_KEY_FINAL,
		 'AC_'||LOCL.LOCL_SEGMNT2_KEY AS ES_SEGMNT2_KEY_FINAL,
		 'TP_'||LOCL.LOCL_SEGMNT3_KEY AS ES_SEGMNT3_KEY_FINAL,
		 'CC_'||LOCL.LOCL_SEGMNT4_KEY AS ES_SEGMNT4_KEY_FINAL,
		 'GO_'||LOCL.LOCL_SEGMNT5_KEY AS ES_SEGMNT5_KEY_FINAL,
		 'PR_'||LOCL.LOCL_SEGMNT6_KEY AS ES_SEGMNT6_KEY_FINAL,
		 'RF_'||LOCL.LOCL_SEGMNT7_KEY AS ES_SEGMNT7_KEY_FINAL,
		 'PL_'||LOCL.LOCL_SEGMNT8_KEY AS ES_SEGMNT8_KEY_FINAL,
		  CASE WHEN LOCL.LOCL_SEGMNT9_KEY = 'GG' AND LOCL.SOURCE_NAME = 'BIO-SAPEU' THEN 'BT_G'
		       WHEN LOCL.LOCL_SEGMNT9_KEY = 'GS' AND LOCL.SOURCE_NAME = 'BIO-SAPEU' THEN 'BT_S'
			   WHEN LOCL.LOCL_SEGMNT9_KEY NOT IN ('GG','GS') AND LOCL.SOURCE_NAME = 'BIO-SAPEU' THEN 'BT_P'
			   ELSE 'BT_'||LOCL.LOCL_SEGMNT9_KEY
		  END AS ES_SEGMNT9_KEY_FINAL,
		 'FU_'||LOCL.LOCL_SEGMNT10_KEY AS ES_SEGMNT10_KEY_FINAL,
		 'FU_'||LOCL.LOCL_SEGMNT11_KEY AS ES_SEGMNT11_KEY_FINAL,
		 ES_SEGMNT1_KEY_FINAL||'~'||'ECA'||'~'||'ECA_CO' as ES_SEGMNT1_SYS_KEY,
		 ES_SEGMNT2_KEY_FINAL||'~'||'ECA'||'~'||'ECA_AC' as ES_SEGMNT2_SYS_KEY,
		 ES_SEGMNT3_KEY_FINAL||'~'||'ECA'||'~'||'ECA_TP' as ES_SEGMNT3_SYS_KEY,
		 ES_SEGMNT4_KEY_FINAL||'~'||'ECA'||'~'||'ECA_CC' as ES_SEGMNT4_SYS_KEY,
		 ES_SEGMNT5_KEY_FINAL||'~'||'ECA'||'~'||'ECA_GO' as ES_SEGMNT5_SYS_KEY,
		 ES_SEGMNT6_KEY_FINAL||'~'||'ECA'||'~'||'ECA_PR' as ES_SEGMNT6_SYS_KEY,
		 ES_SEGMNT7_KEY_FINAL||'~'||'ECA'||'~'||'ECA_RF' as ES_SEGMNT7_SYS_KEY,
		 ES_SEGMNT8_KEY_FINAL||'~'||'ECA'||'~'||'ECA_PL' as ES_SEGMNT8_SYS_KEY,
		 ES_SEGMNT9_KEY_FINAL||'~'||'ECA'||'~'||'ECA_BT' as ES_SEGMNT9_SYS_KEY,
		 ES_SEGMNT10_KEY_FINAL||'~'||'ECA'||'~'||'ECA_FU1' as ES_SEGMNT10_SYS_KEY,
		 ES_SEGMNT11_KEY_FINAL||'~'||'ECA'||'~'||'ECA_FU2' as ES_SEGMNT11_SYS_KEY,
		 Case when LOCL.SET_OF_BOK_KEY='-1' then '-99999' 
		 else LOCL.SET_OF_BOK_KEY||'~'||'GLPROD' 
		 end AS SET_OF_BOK_SYS_KEY,
		 Case when LOCL.CURR_MAIN_KEY is Null then '-99999' 
		 else LOCL.CURR_MAIN_KEY||'~'||LOCL.source_name 
		 end AS LOCL_CURR_MAIN_SYS_KEY,
		 '-99999' AS TRANS_CURR_MAIN_SYS_KEY,
		 Case when LOCL.SOURCE_NAME='GLPROD' then LOCL.PERD_ID ||'~'||'GEMS_CALENDAR'||'~'||'1'||'~'||'GLPROD'
         when LOCL.SOURCE_NAME='BIO-SAPEU' then LOCL.TIM_MAIN_PERD_KEY ||'~'||'NA'||'~'||'BIO-SAPEU'
         when LOCL.SOURCE_NAME='HCIT_PS9' then '-99999'
         end AS TIM_MAIN_PERD_SYS_KEY,
		 LOCL.RECORD_FLAG,
		 cast(SUBSTR(TRIM(:perd_id), 1, 4) as INTEGER) AS FISCL_YEAR,
         cast(SUBSTR(TRIM(:perd_id), 5, 2) as INTEGER) AS FISCL_MONTH,
		 'SYS' as BALNC_TYP_DESC
    FROM $TGTDB.GL_LOCL_BALNC_F LOCL
    WHERE LOCL.PERD_ID = :perd_id 
    AND LOCL.BALNC_TYP_KEY='1'
    AND LOCL.LEDGR_CATGRY_CD in ('PRIMARY','ALC','LOCAL')
    AND LOCL.ES_ESB_FLAG IN ('VV');
	
\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 5
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\echo '\n ---Updating column FC_YTD_BALNC_NET_AMT for table $STGDB.GL_COA_BALNC_S for source HCIT-PS9--------- \n'

UPDATE $STGDB.GL_COA_BALNC_S
SET FC_YTD_BALNC_NET_AMT=a.FC_YTD_BALNC_NET_AMT
from
(SELECT LOCL_SEGMNT_KEY_DESC,SUM(FC_YTD_BALNC_DR_AMT)-SUM(
   FC_YTD_BALNC_CR_AMT) FC_YTD_BALNC_NET_AMT
FROM $STGDB.GL_COA_BALNC_S WHERE source_name='HCIT_PS9' and BALNC_DAT_TYP='SYS'
GROUP BY LOCL_SEGMNT_KEY_DESC) a
WHERE $STGDB.GL_COA_BALNC_S.LOCL_SEGMNT_KEY_DESC=a.LOCL_SEGMNT_KEY_DESC
and source_name='HCIT_PS9' and BALNC_DAT_TYP='SYS';


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 6
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


/* ******************************BTQ_FGL_120_DI_DWH_GLOBL_BALNC_F.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DI_DWH_GLOBL_BALNC_F.sh not needed--------- \n'

\echo '\n ----Migrating Bteq BTQ_FGL_120_DI_DWH_OSTG_COA_BALNC_FS.sh NOT NEEDED FOR GLOBAL BALANCE , DATA ORIGIN SHOULD CHECK--------- \n'


/* ******************************BTQ_FGL_120_DI_LOAD_CHECK.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DI_LOAD_CHECK.sh--------- \n'
\echo '\n ----Performing load check for table $STGDB.GL_COA_BALNC_S for all three sources and if any one of these are empty , exiting the job with status 100 --------- \n'

SELECT GL_COA_BALNC_S.source_name,COUNT(1)  FROM   $STGDB.GL_COA_BALNC_S GL_COA_BALNC_S
WHERE  GL_COA_BALNC_S.BALNC_DAT_TYP = 'SYS'   AND GL_COA_BALNC_S.source_name ='GLPROD'
GROUP BY  GL_COA_BALNC_S.source_name;

\if :ACTIVITYCOUNT = 0
  \echo "Exiting because record count is 0 for GLPROD"
   \exit 100
\endif

SELECT GL_COA_BALNC_S.source_name,COUNT(1)  FROM   $STGDB.GL_COA_BALNC_S GL_COA_BALNC_S
WHERE  GL_COA_BALNC_S.BALNC_DAT_TYP = 'SYS'   AND GL_COA_BALNC_S.source_name ='HCIT_PS9'
GROUP BY  GL_COA_BALNC_S.source_name;

\if :ACTIVITYCOUNT = 0
  \echo "Exiting because record count is 0 for HCIT_PS9"
   \exit 100
\endif

SELECT GL_COA_BALNC_S.source_name,COUNT(1)  FROM   $STGDB.GL_COA_BALNC_S GL_COA_BALNC_S
WHERE  GL_COA_BALNC_S.BALNC_DAT_TYP = 'SYS'   AND GL_COA_BALNC_S.source_name ='BIO-SAPEU'
GROUP BY  GL_COA_BALNC_S.source_name;

\if :ACTIVITYCOUNT = 0
  \echo "Exiting because record count is 0 for BIO-SAPEU"
  \exit 100
\endif

/* ******************************BTQ_FGL_120_DI_DWH_MSNG_COMBN_COA_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DI_DWH_MSNG_COMBN_COA_BALNC_FS.sh--------- \n'

\echo '\n ----Inserting data to $STGDB.GL_COA_BALNC_S for missing combination from $TGTDB.GL_COA_BALNC_F --------- \n'

INSERT INTO $STGDB.GL_COA_BALNC_S
            ( 
			  LOCL_SEGMNT1_SYS_KEY 
			 ,LOCL_SEGMNT2_SYS_KEY 
			 ,LOCL_SEGMNT3_SYS_KEY 
			 ,LOCL_SEGMNT4_SYS_KEY 
			 ,LOCL_SEGMNT5_SYS_KEY 
			 ,LOCL_SEGMNT6_SYS_KEY 
			 ,LOCL_SEGMNT7_SYS_KEY 
			 ,LOCL_SEGMNT8_SYS_KEY 
			 ,LOCL_SEGMNT9_SYS_KEY 
			 ,LOCL_SEGMNT10_SYS_KEY 
			 ,LOCL_SEGMNT11_SYS_KEY 
			 ,LOCL_SEGMNT1_KEY
             ,LOCL_SEGMNT2_KEY
             ,LOCL_SEGMNT3_KEY
             ,LOCL_SEGMNT4_KEY
             ,LOCL_SEGMNT5_KEY
             ,LOCL_SEGMNT6_KEY
             ,LOCL_SEGMNT7_KEY
             ,LOCL_SEGMNT8_KEY
             ,LOCL_SEGMNT9_KEY
             ,LOCL_SEGMNT10_KEY
             ,LOCL_SEGMNT11_KEY
             ,LOCL_SEGMNT_KEY
             ,LOCL_SEGMNT_KEY_DESC
             ,ICP_KEY
             ,ICP_MAP_KEY
             ,ICP_ALT_MAP_KEY
             ,SET_OF_BOK_KEY
             ,CD_COMBN_KEY
             ,BALNC_TYP_KEY
             ,LOCL_CURR_MAIN_KEY
             ,TRANS_CURR_MAIN_KEY
             ,TIM_MAIN_PERD_KEY
             ,PART_NAM
             ,FC_PERD_NET_DR_AMT
             ,FC_PERD_NET_CR_AMT
             ,FC_YTD_BALNC_DR_AMT
             ,FC_YTD_BALNC_CR_AMT
             ,FC_YTD_BALNC_NET_AMT
             ,MOR_RT
             ,PREV_YR_MOR_RT
             ,MOR_PERD_NET_DR_AMT
             ,MOR_PERD_NET_CR_AMT
             ,MOR_YTD_BALNC_DR_AMT
             ,MOR_YTD_BALNC_CR_AMT
             ,GAP_RT
             ,PREV_YR_GAP_RT
             ,GAP_PERD_NET_DR_AMT
             ,GAP_PERD_NET_CR_AMT
             ,GAP_YTD_BALNC_DR_AMT
             ,GAP_YTD_BALNC_CR_AMT
             ,HIST_RT
             ,PREV_YR_HIST_RT
             ,HIST_AMT
             ,FCTA_PERD_NET_DR_AMT
             ,FCTA_PERD_NET_CR_AMT
             ,FCTA_YTD_BALNC_DR_AMT
             ,FCTA_YTD_BALNC_CR_AMT
             ,APPLD_RT
             ,PREV_YR_APPLD_RT
             ,APPLD_PERD_NET_DR_AMT
             ,APPLD_PERD_NET_CR_AMT
             ,APPLD_YTD_BALNC_DR_AMT
             ,APPLD_YTD_BALNC_CR_AMT
             ,APPLD_FLAG
             ,OP_RT
             ,PREV_YR_OP_RT
             ,OP_PERD_NET_DR_AMT
             ,OP_PERD_NET_CR_AMT
             ,OP_YTD_BALNC_DR_AMT
             ,OP_YTD_BALNC_CR_AMT
             ,TRANSLTD_FLAG
             ,PERD_ID
             ,LOAD_ID
             ,CHANGE_SIGN
             ,BALNC_DAT_TYP
             ,ATRBT_1
             ,ATRBT_2
             ,ATRBT_3
             ,ATRBT_4
             ,ATRBT_5
             ,SRC_SYS_ID
             ,DATA_ORIGIN
             ,POSTING_AGENT
             ,SOURCE_NAME
             ,SOURCE_CREATION_ID
             ,SOURCE_CREATION_DTM
             ,SOURCE_UPDATE_ID
             ,SOURCE_UPDATE_DTM
             ,LOAD_DTM
             ,UPDATE_DTM
             ,LEDGR_CATGRY_CD
             ,ES_SEGMNT1_KEY
             ,ES_SEGMNT2_KEY
             ,ES_SEGMNT3_KEY
             ,ES_SEGMNT4_KEY
             ,ES_SEGMNT5_KEY
             ,ES_SEGMNT6_KEY
             ,ES_SEGMNT7_KEY
             ,ES_SEGMNT8_KEY
             ,ES_SEGMNT9_KEY
             ,ES_SEGMNT10_KEY
             ,ES_SEGMNT11_KEY
             ,MEMO_FLD1
             ,MEMO_FLD2
			 ,ES_SEGMNT1_SYS_KEY 
             ,ES_SEGMNT2_SYS_KEY 
             ,ES_SEGMNT3_SYS_KEY 
             ,ES_SEGMNT4_SYS_KEY 
             ,ES_SEGMNT5_SYS_KEY 
             ,ES_SEGMNT6_SYS_KEY 
             ,ES_SEGMNT7_SYS_KEY 
             ,ES_SEGMNT8_SYS_KEY 
             ,ES_SEGMNT9_SYS_KEY 
             ,ES_SEGMNT10_SYS_KEY
             ,ES_SEGMNT11_SYS_KEY
             ,SET_OF_BOK_SYS_KEY 
             ,LOCL_CURR_MAIN_SYS_KEY 
             ,TRANS_CURR_MAIN_SYS_KEY 
             ,TIM_MAIN_PERD_SYS_KEY
			 ,RECORD_FLAG
			 ,FISCL_YEAR
             ,FISCL_MONTH
			 ,BALNC_TYP_DESC
)
SELECT  
      	F1.LOCL_SEGMNT1_SYS_KEY 
	   ,F1.LOCL_SEGMNT2_SYS_KEY 
	   ,F1.LOCL_SEGMNT3_SYS_KEY 
	   ,F1.LOCL_SEGMNT4_SYS_KEY 
	   ,F1.LOCL_SEGMNT5_SYS_KEY 
	   ,F1.LOCL_SEGMNT6_SYS_KEY 
	   ,F1.LOCL_SEGMNT7_SYS_KEY 
	   ,F1.LOCL_SEGMNT8_SYS_KEY 
	   ,F1.LOCL_SEGMNT9_SYS_KEY 
	   ,F1.LOCL_SEGMNT10_SYS_KEY 
	   ,F1.LOCL_SEGMNT11_SYS_KEY 
	   ,F1.LOCL_SEGMNT1_KEY
       ,F1.LOCL_SEGMNT2_KEY
       ,F1.LOCL_SEGMNT3_KEY
       ,F1.LOCL_SEGMNT4_KEY
       ,F1.LOCL_SEGMNT5_KEY
       ,F1.LOCL_SEGMNT6_KEY
       ,F1.LOCL_SEGMNT7_KEY
       ,F1.LOCL_SEGMNT8_KEY
       ,F1.LOCL_SEGMNT9_KEY
       ,F1.LOCL_SEGMNT10_KEY
       ,F1.LOCL_SEGMNT11_KEY
       ,F1.LOCL_SEGMNT_KEY
       ,TRIM(F1.LOCL_SEGMNT_KEY)||'.'||TRIM(F1.SET_OF_BOK_KEY)||'.'||TRIM(F1.LOCL_CURR_MAIN_KEY)||'.'||TRIM(:open_period)||'.'||TRIM(F1.LOAD_ID) AS LOCL_SEGMNT_KEY_DESC
       ,F1.ICP_KEY
       ,F1.ICP_MAP_KEY
       ,F1.ICP_ALT_MAP_KEY
       ,F1.SET_OF_BOK_KEY
       ,F1.CD_COMBN_KEY
       ,F1.BALNC_TYP_KEY AS FINAL_BALNC_TYP_KEY
       ,F1.LOCL_CURR_MAIN_KEY
       ,F1.TRANS_CURR_MAIN_KEY
       ,TRIM(:open_period) AS TIM_MAIN_PERD_KEY
       ,F1.PART_NAM
       ,0.00 AS FC_PERD_NET_DR_AMT
       ,0.00 AS FC_PERD_NET_CR_AMT
	    ,CASE  
	      WHEN F1.BALNC_DAT_TYP = 'ADJ' THEN F1.FC_YTD_BALNC_NET_AMT 
          ELSE F1.FC_YTD_BALNC_DR_AMT
        END AS FC_YTD_BALNC_DR_AMT
       ,0.00 AS FC_YTD_BALNC_CR_AMT
       ,0.00 AS FC_YTD_BALNC_NET_AMT
       ,0.00 AS MOR_RT
       ,0.00 AS PREV_YR_MOR_RT
       ,0.00 AS MOR_PERD_NET_DR_AMT
       ,0.00 AS MOR_PERD_NET_CR_AMT
       ,0.00 AS MOR_YTD_BALNC_DR_AMT
       ,0.00 AS MOR_YTD_BALNC_CR_AMT
       ,0.00 AS GAP_RT
       ,0.00 AS PREV_YR_GAP_RT
       ,0.00 AS GAP_PERD_NET_DR_AMT
       ,0.00 AS GAP_PERD_NET_CR_AMT
       ,0.00 AS GAP_YTD_BALNC_DR_AMT
       ,0.00 AS GAP_YTD_BALNC_CR_AMT
       ,0.00 AS HIST_RT
       ,0.00 AS PREV_YR_HIST_RT
       ,0.00 AS HIST_AMT
       ,0.00 AS FCTA_PERD_NET_DR_AMT
       ,0.00 AS FCTA_PERD_NET_CR_AMT
       ,0.00 AS FCTA_YTD_BALNC_DR_AMT
       ,0.00 AS FCTA_YTD_BALNC_CR_AMT
       ,0.00 AS APPLD_RT
       ,0.00 AS PREV_YR_APPLD_RT
       ,0.00 AS APPLD_PERD_NET_DR_AMT
       ,0.00 AS APPLD_PERD_NET_CR_AMT
       ,0.00 AS APPLD_YTD_BALNC_DR_AMT
       ,0.00 AS APPLD_YTD_BALNC_CR_AMT
       ,F1.APPLD_FLAG
       ,F1.OP_RT AS OP_RT
       ,0.00 AS PREV_YR_OP_RT
       ,0.00 AS OP_PERD_NET_DR_AMT
       ,0.00 AS OP_PERD_NET_CR_AMT
       ,0.00 AS OP_YTD_BALNC_DR_AMT
       ,0.00 AS OP_YTD_BALNC_CR_AMT
       ,F1.TRANSLTD_FLAG
       ,:perd_id AS PERD_ID
       ,F1.LOAD_ID
       ,F1.CHANGE_SIGN
       ,CASE WHEN F1.BALNC_DAT_TYP LIKE 'GMAP_%' THEN F1.BALNC_DAT_TYP ELSE TRIM('GMAP_'||F1.BALNC_DAT_TYP) END AS FINAL_BALNC_DAT_TYP
       ,F1.ATRBT_1
       ,F1.ATRBT_2
       ,F1.ATRBT_3
       ,F1.ATRBT_4
       ,F1.ATRBT_5
       ,CASE 
			WHEN F1.SOURCE_NAME IN ('GLPROD','BIO-SAPEU') 
			THEN F1.CD_COMBN_KEY||'~'||F1.SET_OF_BOK_KEY||'~'||F1.LOCL_CURR_MAIN_KEY||'~'||FINAL_BALNC_TYP_KEY||'~'||:perd_id||'~'||F1.LOAD_ID||'~'||F1.SOURCE_NAME||'~'||FINAL_BALNC_DAT_TYP
			WHEN F1.SOURCE_NAME IN ('HCIT_PS9')
			THEN COALESCE(F1.ATRBT_1,'NA')||'~'||F1.CD_COMBN_KEY||'~'||F1.SET_OF_BOK_KEY||'~'||F1.LOCL_CURR_MAIN_KEY||'~'||FINAL_BALNC_TYP_KEY||'~'||:perd_id||'~'||F1.LOAD_ID||'~'||F1.SOURCE_NAME||'~'||FINAL_BALNC_DAT_TYP
		END AS SRC_SYS_ID
	   ,F1.DATA_ORIGIN
       ,'rsql_ctb_gl_coa_balnc_s_insert.sh' as POSTING_AGENT
       ,F1.SOURCE_NAME
       ,F1.SOURCE_CREATION_ID
       ,F1.SOURCE_CREATION_DTM
       ,F1.SOURCE_UPDATE_ID
       ,F1.SOURCE_UPDATE_DTM
       ,CURRENT_TIMESTAMP(0)
       ,CURRENT_TIMESTAMP(0)
       ,F1.LEDGR_CATGRY_CD
       ,F1.ES_SEGMNT1_KEY
       ,F1.ES_SEGMNT2_KEY
       ,F1.ES_SEGMNT3_KEY
       ,F1.ES_SEGMNT4_KEY
       ,F1.ES_SEGMNT5_KEY
       ,F1.ES_SEGMNT6_KEY
       ,F1.ES_SEGMNT7_KEY
       ,F1.ES_SEGMNT8_KEY
       ,F1.ES_SEGMNT9_KEY
       ,F1.ES_SEGMNT10_KEY
       ,F1.ES_SEGMNT11_KEY
       ,F1.MEMO_FLD1
       ,F1.MEMO_FLD2
	   ,F1.ES_SEGMNT1_SYS_KEY 
       ,F1.ES_SEGMNT2_SYS_KEY 
       ,F1.ES_SEGMNT3_SYS_KEY 
       ,F1.ES_SEGMNT4_SYS_KEY 
       ,F1.ES_SEGMNT5_SYS_KEY 
       ,F1.ES_SEGMNT6_SYS_KEY 
       ,F1.ES_SEGMNT7_SYS_KEY 
       ,F1.ES_SEGMNT8_SYS_KEY 
       ,F1.ES_SEGMNT9_SYS_KEY 
       ,F1.ES_SEGMNT10_SYS_KEY
       ,F1.ES_SEGMNT11_SYS_KEY
       ,F1.SET_OF_BOK_SYS_KEY 
       ,F1.LOCL_CURR_MAIN_SYS_KEY 
       ,F1.TRANS_CURR_MAIN_SYS_KEY 
       ,F1.TIM_MAIN_PERD_SYS_KEY
	   ,F1.RECORD_FLAG
	   ,cast(SUBSTR(TRIM(:perd_id), 1, 4) as INTEGER) AS FISCL_YEAR
       ,cast(SUBSTR(TRIM(:perd_id), 5, 2) as INTEGER) AS FISCL_MONTH
	   ,'SYS' as BALNC_TYP_DESC
FROM   $TGTDB.GL_COA_BALNC_F F1
WHERE
F1.APPLD_FLAG IN('MOR','GAP','HIST','MOR-T')
       AND F1.PERD_ID in ( :perd_id - 1 )  AND F1.BALNC_TYP_KEY = '6'
       AND ((F1.FC_YTD_BALNC_DR_AMT-F1.FC_YTD_BALNC_CR_AMT) <>0 OR (F1.APPLD_YTD_BALNC_DR_AMT-F1.APPLD_YTD_BALNC_CR_AMT) <>0
       OR (F1.OP_YTD_BALNC_DR_AMT-F1.OP_YTD_BALNC_CR_AMT) <>0)
       AND NOT EXISTS (SELECT 1
                       FROM   $STGDB.GL_COA_BALNC_S FS
                       WHERE  F1.PERD_ID = FS.PERD_ID - 1
                              AND F1.SOURCE_NAME = FS.SOURCE_NAME
                              AND F1.SET_OF_BOK_KEY = FS.SET_OF_BOK_KEY
                              AND F1.LOCL_CURR_MAIN_KEY = FS.LOCL_CURR_MAIN_KEY
                              AND F1.LOCL_SEGMNT_KEY = FS.LOCL_SEGMNT_KEY
                              AND F1.ES_SEGMNT1_KEY = FS.ES_SEGMNT1_KEY
                              AND F1.ES_SEGMNT2_KEY = FS.ES_SEGMNT2_KEY
                              AND F1.ES_SEGMNT3_KEY = FS.ES_SEGMNT3_KEY
                              AND F1.ES_SEGMNT4_KEY = FS.ES_SEGMNT4_KEY
                              AND F1.ES_SEGMNT5_KEY = FS.ES_SEGMNT5_KEY
                              AND F1.ES_SEGMNT6_KEY = FS.ES_SEGMNT6_KEY
                              AND F1.ES_SEGMNT7_KEY = FS.ES_SEGMNT7_KEY
                              AND F1.ES_SEGMNT8_KEY = FS.ES_SEGMNT8_KEY
                              AND F1.ES_SEGMNT9_KEY = FS.ES_SEGMNT9_KEY
                              AND F1.ES_SEGMNT10_KEY = FS.ES_SEGMNT10_KEY
                              AND F1.ES_SEGMNT11_KEY = FS.ES_SEGMNT11_KEY
                              AND FS.PERD_ID IN( :perd_id)
                              AND F1.PERD_ID IN( :perd_id - 1 ));
      /* QUALIFY ROW_NUMBER() OVER (PARTITION BY
       F1.SET_OF_BOK_KEY,
       F1.LOCL_CURR_MAIN_KEY,
       F1.LOCL_SEGMNT_KEY,
       F1.ES_SEGMNT1_KEY,
       F1.ES_SEGMNT2_KEY,
       F1.ES_SEGMNT3_KEY,
       F1.ES_SEGMNT4_KEY,
       F1.ES_SEGMNT5_KEY,
       F1.ES_SEGMNT6_KEY,
       F1.ES_SEGMNT7_KEY,
       F1.ES_SEGMNT8_KEY,
       F1.ES_SEGMNT9_KEY,
       F1.ES_SEGMNT10_KEY,
       F1.ES_SEGMNT11_KEY,
       COALESCE(F1.ATRBT_1,'NA')
       ORDER BY
       F1.SET_OF_BOK_KEY,
       F1.LOCL_CURR_MAIN_KEY,
       F1.LOCL_SEGMNT_KEY,
       F1.ES_SEGMNT1_KEY,
       F1.ES_SEGMNT2_KEY,
       F1.ES_SEGMNT3_KEY,
       F1.ES_SEGMNT4_KEY,
       F1.ES_SEGMNT5_KEY,
       F1.ES_SEGMNT6_KEY,
       F1.ES_SEGMNT7_KEY,
       F1.ES_SEGMNT8_KEY,
       F1.ES_SEGMNT9_KEY,
       F1.ES_SEGMNT10_KEY,
       F1.ES_SEGMNT11_KEY,
       COALESCE(F1.ATRBT_1,'NA'))=1;*/


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 7
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


/* ******************************BTQ_FGL_120_DUP_COA_BALNC_FS_IDN.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DUP_COA_BALNC_FS_IDN.sh--------- \n'

UPDATE $STGDB.GL_COA_BALNC_S
SET LEDGR_CATGRY_CD=CASE WHEN LOCL_SEGMNT9_KEY NOT IN ('GG','GS') THEN 'PRIMARY' ELSE 'SECONDARY' END
WHERE
PERD_ID = :perd_id
AND SOURCE_NAME NOT IN ('GLPROD','HCIT_PS9'); 

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 8
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


UPDATE $STGDB.GL_COA_BALNC_S 
SET LEDGR_CATGRY_CD=LEDGR.ledger_category_code
FROM $GLPROD_EXT_DB.gl_ledgers LEDGR
WHERE
PERD_ID = :perd_id
AND $STGDB.GL_COA_BALNC_S.SET_OF_BOK_KEY=LEDGR.ledger_id
--AND $STGDB.GL_COA_BALNC_S.SRC_IDN =LEDGR.SRC_IDN 
and $STGDB.GL_COA_BALNC_S.SOURCE_NAME <> 'HCIT_PS9';  

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 9
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


UPDATE $STGDB.GL_COA_BALNC_S
SET LEDGR_CATGRY_CD = COALESCE(ATRBT_5 ,'LOCAL')
WHERE SOURCE_NAME = 'HCIT_PS9' 
AND PERD_ID = :perd_id;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 10
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


/* ******************************BTQ_FGL_120_DUP_DWH_RT_COA_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DUP_DWH_RT_COA_BALNC_FS.sh--------- \n'

/***********************MOR RATE UPDATE*****************************************/
\echo '\n ---Updating column MOR_RT for table $STGDB.GL_COA_BALNC_S from $CFD_DB.GCD_CURR_RT_HIST_F--------- \n'

UPDATE $STGDB.GL_COA_BALNC_S
SET MOR_RT=X.CURR_CONV_RT
FROM
(
SELECT Y.SRC_SYS_ID  as SRC_SYS_ID ,X.CURR_CONV_RT,X.from_curr_key
FROM
$STGDB.GL_COA_BALNC_S Y,
(SELECT
from_curr_key,
TIM_MAIN_PERD_KEY
,CURR_CONV_RT
FROM
$CFD_DB.GCD_CURR_RT_HIST_F
WHERE
to_curr_key='USD'
AND CURR_RT_TYP='Monthly'
AND source_name = 'GLPROD'
) X
WHERE
Y.TIM_MAIN_PERD_KEY=X.TIM_MAIN_PERD_KEY
AND Y.LOCL_CURR_MAIN_KEY=X.from_curr_key
)X
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID=X.SRC_SYS_ID
AND $STGDB.GL_COA_BALNC_S.PERD_ID = :perd_id;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 11
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\echo '\n ---Updating column GAP_RT for table $STGDB.GL_COA_BALNC_S from $CFD_DB.GCD_CURR_RT_HIST_F--------- \n'

UPDATE $STGDB.GL_COA_BALNC_S
SET GAP_RT=X.CURR_CONV_RT
FROM
(
SELECT Y.SRC_SYS_ID  as SRC_SYS_ID ,X.CURR_CONV_RT,X.from_curr_key
FROM
$STGDB.GL_COA_BALNC_S Y,
(SELECT
from_curr_key,
TIM_MAIN_PERD_KEY
,CURR_CONV_RT
FROM
$CFD_DB.GCD_CURR_RT_HIST_F
WHERE
to_curr_key='USD'
AND CURR_RT_TYP='GAP'
AND source_name = 'GLPROD'
) X
WHERE
Y.TIM_MAIN_PERD_KEY=X.TIM_MAIN_PERD_KEY
AND Y.LOCL_CURR_MAIN_KEY=X.from_curr_key
)X
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID=X.SRC_SYS_ID
AND $STGDB.GL_COA_BALNC_S.PERD_ID = :perd_id;


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 12
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\echo '\n ---Updating columns MOR_RT and GAP_RT for table $STGDB.GL_COA_BALNC_S to 1 where LOCL_CURR_MAIN_KEY=USD--------- \n'


UPDATE $STGDB.GL_COA_BALNC_S
SET
MOR_RT=1 ,
GAP_RT=1
WHERE
LOCL_CURR_MAIN_KEY='USD';

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 13
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


COMMIT;

end;

EOF

rsqlexitcode=$?

echo "Insertion Completed for Global Balance"

echo "Exited with error code $rsqlexitcode"
echo "---------------------------------"

script_ended=$(date "+%F-%H-%M-%S")
echo "Script ended at --> $script_ended"

end=`date +%s`
exec=`expr $end - $start`
time_taken=`date -d@$exec -u +%H:%M:%S`

echo "Time Taken --> $time_taken"

python3 /ops/finance/common/scripts/send_sfn_token.py $token $script_name $rsqlexitcode $log_file_name

exit $rsqlexitcode
