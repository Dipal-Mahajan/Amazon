#-GE CONFIDENTIAL- or -GE HIGHLY CONFIDENTIAL-
#Type: Source Code
#Copyright (c) 2022, GE Healthcare
#All Rights Reserved
#This unpublished material is proprietary to GE Healthcare. The methods and
#techniques described herein are considered trade secrets and/or
#confidential. Reproduction or distribution, in whole or in part, is
#forbidden except by express written permission of GE Healthcare.


# <RSQL> SCRIPT NAME - rsql_ctb_gl_coa_balnc_s_rate.sh  </RSQL>
# <RSQL> SCRIPT DESCRIPTION - "Current RSQL is updating data of $STGDB.GL_COA_BALNC_S from $TGTDB.GL_COA_BALNC_F depending on transformation logic "  </RSQL>
# <RSQL> PARAMETER FILE NAME - ctb_parameter.sh.sh </RSQL>
# <RSQL>  SOURCE SCHEMA - $TGTDB  </RSQL>
# <RSQL>  SOURCE TABLE  - GL_COA_BALNC_F  </RSQL>
# <RSQL>  TARGET SCHEMA - $STGDB  </RSQL>
# <RSQL>  TARGET TABLE  - GL_COA_BALNC_S </RSQL>
# <RSQL>  STMT TYPES    -  Update  </RSQL>
# <RSQL>  CREATED ON    - 16-OCT-2022  </RSQL>
# <RSQL>  CREATED BY    - healthfinance.odpctb@ge.com  </RSQL>
# <RSQL>  LAST MODIFIED ON    - 22-NOV-2022  </RSQL>
# <RSQL>  LAST MODIFIED BY    - healthfinance.odpctb@ge.com  </RSQL>


echo "Calling the CTB Parameter file --> ctb_parameter.sh"
source /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "Printing Content of Parameter File"
cat /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

if [ $# -eq 0 ]
  then
    echo "No arguments supplied , Please pass the parameter value in 0 and 1 , 0 for open_period , 1 for future_period"
    exit 1
fi

if [ $5 -gt 1 ]
  then
    echo "Please pass argument between 0 and 1, 0 for open_period , 1 for future_period"
    exit 1
fi


period_param=$5

echo "period_param from param --> " $period_param

echo "--------------------------------------------------------"

echo "                              "
echo "Current RSQL is updating data of $STGDB.GL_COA_BALNC_S from $TGTDB.GL_COA_BALNC_F depending on transformation logic "
echo "                              "

script_started=$(date "+%F-%H-%M-%S")
echo "Script Started at --> $script_started"

start=`date +%s`


#source /ops/finance/common/scripts/get_redshift_creds.sh 'odp-fin-nprod-ctb-fsso' 'us-east-1'
source /ops/finance/common/scripts/aws_run_profile.sh $1 $2 $3 $4

rsql -h $HOST -U $USER -d $DB << EOF
\timing true
BEGIN ;

/* Set the Query Band for the session */

\echo '\n ----Setting Query Band to $QBSTR--------- \n'
SET query_group to '$QBSTR';

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 1
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\echo '\n ----Setting Search Path to $STGDB--------- \n'

/* ******************************Setting Database************************************************* */
SET SEARCH_PATH TO $STGDB, pg_catalog;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 2
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif



\set period_param $period_param

\echo "period_param --> " :period_param

/* ******************************Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;************************************ */

\echo '\n ----Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;--------- \n'

\if :period_param = 0
    \echo 'select perd_id  as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;'
      select perd_id as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;
      \gset
    \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final

\elif :period_param = 1
    \echo 'SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;'
    SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;
    \gset
    \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final
        \if :ACTIVITYCOUNT = 0
           \echo 'future period id future_perd_id is null so exiting gracefully'
           \exit 0
        \endif

\else
    \echo 'Period parameter not in 0 and 1 so exiting the statement'
    \echo 'Error Code -'
    \remark :LAST_ERROR_MESSAGE
    \exit 1

\endif

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 3
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\set open_period '''':open_period_final''''

\echo "perd_id --> " :perd_id
\echo "open_period --> " :open_period

/* ******************************BTQ_FGL_120_DUP_DWH_USDAMT_COA_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DUP_DWH_USDAMT_COA_BALNC_FS.sh--------- \n'


/******************************TRANSLATED USD UPDATE FOR BS YTD ACTIVITY ******************/
UPDATE $STGDB.GL_COA_BALNC_S
SET
GAP_YTD_BALNC_DR_AMT = cast(FC_YTD_BALNC_DR_AMT as DECIMAL(38,10)) * cast(GAP_RT as DECIMAL(38,10)),
GAP_YTD_BALNC_CR_AMT = cast(FC_YTD_BALNC_CR_AMT as DECIMAL(38,10)) * cast(GAP_RT as DECIMAL(38,10)),
FC_PERD_NET_SRC_DR_AMT = FC_PERD_NET_DR_AMT,
FC_PERD_NET_SRC_CR_AMT = FC_PERD_NET_CR_AMT,
ATRBT_9=OP_PERD_NET_DR_AMT,
ATRBT_10=OP_PERD_NET_CR_AMT
WHERE
PERD_ID = :perd_id;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 4
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/******************************UPDATE AMOUNT COLUMNS WITH NULL ***************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
MOR_YTD_BALNC_DR_AMT = NULL,
MOR_YTD_BALNC_CR_AMT = NULL,
MOR_PERD_NET_DR_AMT  = NULL,
MOR_PERD_NET_CR_AMT  = NULL,
GAP_PERD_NET_DR_AMT  = NULL,
GAP_PERD_NET_CR_AMT  = NULL,
FC_PERD_NET_DR_AMT   = CASE WHEN TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN FC_YTD_BALNC_DR_AMT ELSE NULL END,
FC_PERD_NET_CR_AMT   = CASE WHEN TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN FC_YTD_BALNC_CR_AMT ELSE NULL END,
OP_PERD_NET_DR_AMT  = CASE WHEN TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN OP_YTD_BALNC_DR_AMT ELSE NULL END,
OP_PERD_NET_CR_AMT  = CASE WHEN TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN OP_YTD_BALNC_CR_AMT ELSE NULL END,
APPLD_PERD_NET_DR_AMT= 0.00,
APPLD_PERD_NET_CR_AMT= 0.00,
APPLD_YTD_BALNC_DR_AMT=0.00,
APPLD_YTD_BALNC_CR_AMT=0.00 ;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 5
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/**************************FUNCTIONAL PTD & TRANSLATED USD FOR SYS ***********************/

UPDATE $STGDB.GL_COA_BALNC_S
SET    MOR_YTD_BALNC_DR_AMT =  X.YTD_DR_MOR
       ,MOR_YTD_BALNC_CR_AMT = X.YTD_CR_MOR
       ,MOR_PERD_NET_DR_AMT =  X.PTD_DR_MOR
       ,MOR_PERD_NET_CR_AMT =  X.PTD_CR_MOR
       ,GAP_PERD_NET_DR_AMT =  X.PTD_DR_GAP
       ,GAP_PERD_NET_CR_AMT =  X.PTD_CR_GAP
       ,FC_PERD_NET_CR_AMT  =  X.FC_PERD_NET_CR_AMT1
       ,FC_PERD_NET_DR_AMT  =  X.FC_PERD_NET_DR_AMT1
       ,OP_PERD_NET_DR_AMT  =  X.OP_PERD_NET_DR_AMT1
       ,OP_PERD_NET_CR_AMT  =  X.OP_PERD_NET_CR_AMT1
FROM(
SELECT
B.SRC_SYS_ID
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN
        (CASE WHEN C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.FC_YTD_BALNC_DR_AMT, 0.00)
        ELSE COALESCE(B.FC_PERD_NET_DR_AMT, 0.00)  END)
   ELSE B.FC_YTD_BALNC_DR_AMT - COALESCE(A.FC_YTD_BALNC_DR_AMT, 0.00)
END  AS FC_PERD_NET_DR_AMT1
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN
        (CASE WHEN C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.FC_YTD_BALNC_CR_AMT, 0.00)
        ELSE COALESCE(B.FC_PERD_NET_CR_AMT, 0.00) END)
   ELSE B.FC_YTD_BALNC_CR_AMT - COALESCE(A.FC_YTD_BALNC_CR_AMT, 0.00)
END  AS FC_PERD_NET_CR_AMT1
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.OP_YTD_BALNC_DR_AMT, 0.00)
   ELSE B.OP_YTD_BALNC_DR_AMT - COALESCE(A.OP_YTD_BALNC_DR_AMT, 0.00)
   END  AS OP_PERD_NET_DR_AMT1
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.OP_YTD_BALNC_CR_AMT, 0.00)
   ELSE B.OP_YTD_BALNC_CR_AMT - COALESCE(A.OP_YTD_BALNC_CR_AMT, 0.00)
END  AS OP_PERD_NET_CR_AMT1
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN
   CAST(B.FC_YTD_BALNC_DR_AMT AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
   ELSE COALESCE(A.MOR_YTD_BALNC_DR_AMT, 0.00) + (CAST(FC_PERD_NET_DR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10)))
END  YTD_DR_MOR
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN
   CAST(B.FC_YTD_BALNC_CR_AMT AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
   ELSE COALESCE(A.MOR_YTD_BALNC_CR_AMT, 0.00) + CAST(FC_PERD_NET_CR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
END  YTD_CR_MOR
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PERD_NET_DR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
ELSE COALESCE(YTD_DR_MOR,0)-COALESCE(A.MOR_YTD_BALNC_DR_AMT,0.00) END PTD_DR_MOR
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PERD_NET_CR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
ELSE COALESCE(YTD_CR_MOR,0)-COALESCE(A.MOR_YTD_BALNC_CR_AMT,0) END PTD_CR_MOR
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PERD_NET_DR_AMT1 AS DECIMAL(38,10)) * CAST(B.GAP_RT AS DECIMAL(38,10))
ELSE COALESCE(B.GAP_YTD_BALNC_DR_AMT,0)-COALESCE(A.GAP_YTD_BALNC_DR_AMT,0.00) END PTD_DR_GAP
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PERD_NET_CR_AMT1 AS DECIMAL(38,10)) * CAST(B.GAP_RT AS DECIMAL(38,10))
ELSE COALESCE(B.GAP_YTD_BALNC_CR_AMT,0)-COALESCE(A.GAP_YTD_BALNC_CR_AMT,0) END PTD_CR_GAP
FROM
(SELECT
       CD_COMBN_KEY
       ,ES_SEGMNT1_KEY
       ,ES_SEGMNT2_KEY
       ,ES_SEGMNT3_KEY
       ,ES_SEGMNT4_KEY
       ,ES_SEGMNT5_KEY
       ,ES_SEGMNT6_KEY
       ,ES_SEGMNT7_KEY
       ,ES_SEGMNT8_KEY
       ,ES_SEGMNT9_KEY
       ,ES_SEGMNT10_KEY
       ,ES_SEGMNT11_KEY
       ,SET_OF_BOK_KEY
       ,SUM(FC_YTD_BALNC_DR_AMT ) AS FC_YTD_BALNC_DR_AMT
       ,SUM(FC_YTD_BALNC_CR_AMT ) AS FC_YTD_BALNC_CR_AMT
       ,SUM(MOR_YTD_BALNC_DR_AMT ) AS MOR_YTD_BALNC_DR_AMT
       ,SUM(MOR_YTD_BALNC_CR_AMT ) AS MOR_YTD_BALNC_CR_AMT
       ,SUM(GAP_YTD_BALNC_DR_AMT ) AS GAP_YTD_BALNC_DR_AMT
       ,SUM(GAP_YTD_BALNC_CR_AMT ) AS GAP_YTD_BALNC_CR_AMT
       ,LOCL_CURR_MAIN_KEY
       ,SOURCE_NAME
       ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
       ,PERD_ID
       ,SUM(OP_YTD_BALNC_DR_AMT ) AS OP_YTD_BALNC_DR_AMT
       ,SUM(OP_YTD_BALNC_CR_AMT ) AS OP_YTD_BALNC_CR_AMT
FROM   $TGTDB.GL_COA_BALNC_F
WHERE  PERD_ID =  :perd_id -1 
       AND BALNC_DAT_TYP IN('SYS','GMAP_SYS')
       group by 1,2,3,4,5,6,7,8,9,10,11,12,13,20,21,22,23
) A
JOIN
(SELECT SRC_SYS_ID
       ,CD_COMBN_KEY
       ,ES_SEGMNT1_KEY
       ,ES_SEGMNT2_KEY
       ,ES_SEGMNT3_KEY
       ,ES_SEGMNT4_KEY
       ,ES_SEGMNT5_KEY
       ,ES_SEGMNT6_KEY
       ,ES_SEGMNT7_KEY
       ,ES_SEGMNT8_KEY
       ,ES_SEGMNT9_KEY
       ,ES_SEGMNT10_KEY
       ,ES_SEGMNT11_KEY
       ,SET_OF_BOK_KEY
       ,FC_YTD_BALNC_DR_AMT
       ,FC_YTD_BALNC_CR_AMT
       ,FC_PERD_NET_DR_AMT
       ,FC_PERD_NET_CR_AMT
       ,MOR_YTD_BALNC_DR_AMT
       ,MOR_YTD_BALNC_CR_AMT
       ,MOR_RT
       ,GAP_YTD_BALNC_DR_AMT
       ,GAP_YTD_BALNC_CR_AMT
       ,GAP_RT
       ,OP_PERD_NET_DR_AMT
       ,OP_PERD_NET_CR_AMT
       ,OP_YTD_BALNC_DR_AMT
       ,OP_YTD_BALNC_CR_AMT
       ,OP_RT
       ,LOCL_CURR_MAIN_KEY
       ,SOURCE_NAME
       ,PERD_ID
       ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
       ,TIM_MAIN_PERD_KEY
FROM   $STGDB.GL_COA_BALNC_S
WHERE  PERD_ID =  :perd_id
       AND BALNC_DAT_TYP IN( 'SYS','GMAP_SYS')  ) B
         ON A.CD_COMBN_KEY = B.CD_COMBN_KEY
            AND A.ES_SEGMNT1_KEY = B.ES_SEGMNT1_KEY
            AND A.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY
            AND A.ES_SEGMNT3_KEY = B.ES_SEGMNT3_KEY
            AND A.ES_SEGMNT4_KEY = B.ES_SEGMNT4_KEY
            AND A.ES_SEGMNT5_KEY = B.ES_SEGMNT5_KEY
            AND A.ES_SEGMNT6_KEY = B.ES_SEGMNT6_KEY
            AND A.ES_SEGMNT7_KEY = B.ES_SEGMNT7_KEY
            AND A.ES_SEGMNT8_KEY = B.ES_SEGMNT8_KEY
            AND A.ES_SEGMNT9_KEY = B.ES_SEGMNT9_KEY
            AND A.ES_SEGMNT10_KEY = B.ES_SEGMNT10_KEY
            AND A.ES_SEGMNT11_KEY = B.ES_SEGMNT11_KEY
            AND A.SET_OF_BOK_KEY = B.SET_OF_BOK_KEY
            AND A.LOCL_CURR_MAIN_KEY = B.LOCL_CURR_MAIN_KEY
            AND A.SOURCE_NAME = B.SOURCE_NAME
            AND COALESCE(A.ATRBT_1, 'DEFAULT') = COALESCE(B.ATRBT_1, 'DEFAULT')
            AND A.PERD_ID = :perd_id - 1
JOIN $CFD_DB.GL_ES_SEGMNT2_DH1 C
ON C.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY
)X
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID  = X.SRC_SYS_ID;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 6
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/**************************FUNCTIONAL PTD FOR SYS (If still NULL) ***********************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
 FC_PERD_NET_CR_AMT=CASE WHEN FC_PERD_NET_CR_AMT IS NULL THEN FC_YTD_BALNC_CR_AMT ELSE 0.00 END
,FC_PERD_NET_DR_AMT=CASE WHEN FC_PERD_NET_DR_AMT IS NULL THEN FC_YTD_BALNC_DR_AMT ELSE 0.00 END
WHERE
PERD_ID =  :perd_id
AND BALNC_DAT_TYP IN ('SYS','GMAP_SYS')
AND (FC_PERD_NET_CR_AMT IS NULL OR
FC_PERD_NET_DR_AMT IS NULL);

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 7
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/**************************OPFx PTD FOR SYS (If still NULL) ***********************/
UPDATE $STGDB.GL_COA_BALNC_S
SET
 OP_PERD_NET_DR_AMT=CASE WHEN OP_PERD_NET_DR_AMT IS NULL THEN OP_YTD_BALNC_DR_AMT ELSE 0.00 END
,OP_PERD_NET_CR_AMT=CASE WHEN OP_PERD_NET_CR_AMT IS NULL THEN OP_YTD_BALNC_CR_AMT ELSE 0.00 END
WHERE
PERD_ID = :perd_id
AND BALNC_DAT_TYP IN ('SYS','GMAP_SYS')
AND (OP_PERD_NET_DR_AMT IS NULL OR
OP_PERD_NET_CR_AMT IS NULL);

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 8
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/**********************************TRANSLATED USD FOR SYS (If still NULL)**********************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
MOR_YTD_BALNC_DR_AMT  = CASE WHEN MOR_YTD_BALNC_DR_AMT IS NULL THEN CAST(FC_YTD_BALNC_DR_AMT AS DECIMAL(38,10)) *  CAST(MOR_RT AS DECIMAL(38,10))  ELSE 0.00 END
,MOR_YTD_BALNC_CR_AMT = CASE WHEN MOR_YTD_BALNC_CR_AMT IS NULL THEN CAST(FC_YTD_BALNC_CR_AMT AS DECIMAL(38,10)) *  CAST(MOR_RT AS DECIMAL(38,10))  ELSE 0.00 END
,MOR_PERD_NET_DR_AMT  = CASE WHEN MOR_PERD_NET_DR_AMT IS NULL THEN  CAST(FC_PERD_NET_DR_AMT AS DECIMAL(38,10)) *   CAST(MOR_RT  AS DECIMAL(38,10))  ELSE 0.00 END
,MOR_PERD_NET_CR_AMT  = CASE WHEN MOR_PERD_NET_CR_AMT IS NULL THEN  CAST(FC_PERD_NET_CR_AMT AS DECIMAL(38,10)) *   CAST(MOR_RT  AS DECIMAL(38,10))  ELSE 0.00 END
,GAP_PERD_NET_DR_AMT  = CASE WHEN GAP_PERD_NET_DR_AMT IS NULL THEN  CAST(FC_PERD_NET_DR_AMT AS DECIMAL(38,10)) *   CAST(GAP_RT  AS DECIMAL(38,10))  ELSE 0.00 END
,GAP_PERD_NET_CR_AMT  = CASE WHEN GAP_PERD_NET_CR_AMT IS NULL THEN  CAST(FC_PERD_NET_CR_AMT AS DECIMAL(38,10)) *   CAST(GAP_RT  AS DECIMAL(38,10))  ELSE 0.00 END
WHERE
PERD_ID = :perd_id
AND BALNC_DAT_TYP IN ('SYS','GMAP_SYS')
AND
(MOR_YTD_BALNC_DR_AMT IS NULL OR
 MOR_YTD_BALNC_CR_AMT IS NULL OR
 MOR_PERD_NET_DR_AMT IS NULL OR
 MOR_PERD_NET_CR_AMT IS NULL OR
 GAP_PERD_NET_DR_AMT IS NULL OR
 GAP_PERD_NET_CR_AMT IS NULL);

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 9
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/******************************UPDATE BEGIN_BALANCE AMT TO ZERO***************************/
UPDATE $STGDB.GL_COA_BALNC_S
SET
BEGIN_BALANCE_DR_AMT = 0.00,
BEGIN_BALANCE_CR_AMT = 0.00
WHERE
PERD_ID = :perd_id;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 10
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/************************UPDATE BEGIN_BALANCE AMT 4 REST ALL******************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
        BEGIN_BALANCE_DR_AMT = HYP_PREV_END_BAL_DR,
        BEGIN_BALANCE_CR_AMT = HYP_PREV_END_BAL_CR
FROM(
SELECT CURR.SRC_SYS_ID        AS SRC_SYS_ID
       ,CURR.SOURCE_NAME         AS SOURCE_NAME
       ,CURR.PERD_ID             AS CURR_PERD_ID
       ,PREV.FC_YTD_BALNC_DR_AMT AS HYP_PREV_END_BAL_DR
       ,PREV.FC_YTD_BALNC_CR_AMT AS HYP_PREV_END_BAL_CR
FROM   (SELECT
               CD_COMBN_KEY
               ,ES_SEGMNT1_KEY
               ,ES_SEGMNT2_KEY
               ,ES_SEGMNT3_KEY
               ,ES_SEGMNT4_KEY
               ,ES_SEGMNT5_KEY
               ,ES_SEGMNT6_KEY
               ,ES_SEGMNT7_KEY
               ,ES_SEGMNT8_KEY
               ,ES_SEGMNT9_KEY
               ,ES_SEGMNT10_KEY
               ,ES_SEGMNT11_KEY
               ,SET_OF_BOK_KEY
               ,SUM(FC_YTD_BALNC_DR_AMT ) AS FC_YTD_BALNC_DR_AMT
               ,SUM(FC_YTD_BALNC_CR_AMT ) AS FC_YTD_BALNC_CR_AMT
               ,LOCL_CURR_MAIN_KEY
               ,SOURCE_NAME
               ,TRANS_CURR_MAIN_KEY
               ,ATRBT_1
               ,PERD_ID
               ,BALNC_TYP_KEY
        FROM   $TGTDB.GL_COA_BALNC_F
        WHERE  PERD_ID =  :perd_id - 1
               AND BALNC_TYP_KEY IN ('6')
               AND BALNC_DAT_TYP NOT IN('ADJ' )
               group by 1,2,3,4,5,6,7,8,9,10,11,12,13,16,17,18,19,20,21
) PREV
       JOIN (SELECT SRC_SYS_ID
                    ,CD_COMBN_KEY
                    ,ES_SEGMNT1_KEY
                    ,ES_SEGMNT2_KEY
                    ,ES_SEGMNT3_KEY
                    ,ES_SEGMNT4_KEY
                    ,ES_SEGMNT5_KEY
                    ,ES_SEGMNT6_KEY
                    ,ES_SEGMNT7_KEY
                    ,ES_SEGMNT8_KEY
                    ,ES_SEGMNT9_KEY
                    ,ES_SEGMNT10_KEY
                    ,ES_SEGMNT11_KEY
                    ,SET_OF_BOK_KEY
                    ,FC_YTD_BALNC_DR_AMT
                    ,FC_YTD_BALNC_CR_AMT
                    ,FC_PERD_NET_SRC_DR_AMT
                    ,FC_PERD_NET_SRC_CR_AMT
                    ,LOCL_CURR_MAIN_KEY
                    ,SOURCE_NAME
                    ,PERD_ID
                    ,TRANS_CURR_MAIN_KEY
                    ,ATRBT_1
                    ,TIM_MAIN_PERD_KEY
                    ,BALNC_TYP_KEY
             FROM   $STGDB.GL_COA_BALNC_S
             WHERE  PERD_ID = :perd_id
                    AND BALNC_TYP_KEY IN ('6')
                    AND BALNC_DAT_TYP NOT IN('ADJ' )) CURR
         ON PREV.CD_COMBN_KEY = CURR.CD_COMBN_KEY
            AND PREV.ES_SEGMNT1_KEY = CURR.ES_SEGMNT1_KEY
            AND PREV.ES_SEGMNT2_KEY = CURR.ES_SEGMNT2_KEY
            AND PREV.ES_SEGMNT3_KEY = CURR.ES_SEGMNT3_KEY
            AND PREV.ES_SEGMNT4_KEY = CURR.ES_SEGMNT4_KEY
            AND PREV.ES_SEGMNT5_KEY = CURR.ES_SEGMNT5_KEY
            AND PREV.ES_SEGMNT6_KEY = CURR.ES_SEGMNT6_KEY
            AND PREV.ES_SEGMNT7_KEY = CURR.ES_SEGMNT7_KEY
            AND PREV.ES_SEGMNT8_KEY = CURR.ES_SEGMNT8_KEY
            AND PREV.ES_SEGMNT9_KEY = CURR.ES_SEGMNT9_KEY
            AND PREV.ES_SEGMNT10_KEY = CURR.ES_SEGMNT10_KEY
            AND PREV.ES_SEGMNT11_KEY = CURR.ES_SEGMNT11_KEY
            AND PREV.SET_OF_BOK_KEY = CURR.SET_OF_BOK_KEY
            AND PREV.BALNC_TYP_KEY  = CURR.BALNC_TYP_KEY
            AND PREV.LOCL_CURR_MAIN_KEY = CURR.LOCL_CURR_MAIN_KEY
            AND PREV.SOURCE_NAME = CURR.SOURCE_NAME
            AND COALESCE(PREV.ATRBT_1, 'NA') = COALESCE(CURR.ATRBT_1, 'NA')
            AND COALESCE(PREV.TRANS_CURR_MAIN_KEY, 'N/A') =
                COALESCE(CURR.TRANS_CURR_MAIN_KEY, 'N/A') ) SUB
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID = sub.SRC_SYS_ID
AND PERD_ID   = sub.CURR_PERD_ID
AND PERD_ID   = :perd_id;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 11
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/************************UPDATE BEGIN_BALANCE AMT 4 JAN*****************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
BEGIN_BALANCE_DR_AMT = FC_YTD_BALNC_DR_AMT - FC_PERD_NET_SRC_DR_AMT,
BEGIN_BALANCE_CR_AMT = FC_YTD_BALNC_CR_AMT - FC_PERD_NET_SRC_CR_AMT
WHERE
TIM_MAIN_PERD_KEY LIKE '%JAN%'
AND PERD_ID = :perd_id;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 12
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


/* ******************************BTQ_FGL_120_DUP_DWH_USDAMT_NONSYS_COA_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DUP_DWH_USDAMT_NONSYS_COA_BALNC_FS.sh--------- \n'

/***************************************PTD FUNC FOR JAN  *******************************************/
UPDATE $STGDB.GL_COA_BALNC_S
SET
FC_PERD_NET_DR_AMT=NULL ,
FC_PERD_NET_CR_AMT=NULL
WHERE BALNC_DAT_TYP IN ('ADJ','GMAP_ADJ');

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 13
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************Update on GL_COA_BALNC_FS  *******************************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
FC_PERD_NET_DR_AMT =X.FC_PTD_DR,
FC_PERD_NET_CR_AMT =X.FC_PTD_CR
FROM
(
SELECT B.SRC_SYS_ID
,CASE WHEN C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.FC_YTD_BALNC_DR_AMT, 0.00)
           ELSE  COALESCE(B.FC_YTD_BALNC_DR_AMT, 0.00) - COALESCE(A.FC_YTD_BALNC_DR_AMT, 0.00) END AS FC_PTD_DR
,CASE WHEN C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.FC_YTD_BALNC_CR_AMT, 0.00)
           ELSE COALESCE(B.FC_YTD_BALNC_CR_AMT,0.00) - COALESCE(A.FC_YTD_BALNC_CR_AMT, 0.00) END AS FC_PTD_CR
FROM   (SELECT SRC_SYS_ID
               ,CD_COMBN_KEY
               ,LOCL_SEGMNT_KEY
               ,ES_SEGMNT1_KEY
               ,ES_SEGMNT2_KEY
               ,ES_SEGMNT3_KEY
               ,ES_SEGMNT4_KEY
               ,ES_SEGMNT5_KEY
               ,ES_SEGMNT6_KEY
               ,ES_SEGMNT7_KEY
               ,ES_SEGMNT8_KEY
               ,ES_SEGMNT9_KEY
               ,ES_SEGMNT10_KEY
               ,ES_SEGMNT11_KEY
               ,SET_OF_BOK_KEY
               ,FC_YTD_BALNC_DR_AMT
               ,FC_YTD_BALNC_CR_AMT
               ,MOR_YTD_BALNC_DR_AMT
               ,MOR_YTD_BALNC_CR_AMT
               ,GAP_YTD_BALNC_DR_AMT
               ,GAP_YTD_BALNC_CR_AMT
               ,LOCL_CURR_MAIN_KEY
               ,SOURCE_NAME
               ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
               ,PERD_ID
        FROM   $TGTDB.GL_COA_BALNC_F
        WHERE  PERD_ID = :perd_id - 89  
        AND BALNC_DAT_TYP IN ('ADJ','GMAP_ADJ')) A
       JOIN (SELECT SRC_SYS_ID
                    ,LOCL_SEGMNT_KEY
                    ,ES_SEGMNT1_KEY
                    ,ES_SEGMNT2_KEY
                    ,ES_SEGMNT3_KEY
                    ,ES_SEGMNT4_KEY
                    ,ES_SEGMNT5_KEY
                    ,ES_SEGMNT6_KEY
                    ,ES_SEGMNT7_KEY
                    ,ES_SEGMNT8_KEY
                    ,ES_SEGMNT9_KEY
                    ,ES_SEGMNT10_KEY
                    ,ES_SEGMNT11_KEY
                    ,CD_COMBN_KEY
                    ,SET_OF_BOK_KEY
                    ,FC_YTD_BALNC_DR_AMT
                    ,FC_YTD_BALNC_CR_AMT
                    ,FC_PERD_NET_DR_AMT
                    ,FC_PERD_NET_CR_AMT
                    ,MOR_YTD_BALNC_DR_AMT
                    ,MOR_YTD_BALNC_CR_AMT
                    ,MOR_RT
                    ,GAP_YTD_BALNC_DR_AMT
                    ,GAP_YTD_BALNC_CR_AMT
                    ,GAP_RT
                    ,LOCL_CURR_MAIN_KEY
                    ,SOURCE_NAME
                    ,PERD_ID
                    ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
                    ,TIM_MAIN_PERD_KEY
             FROM   $STGDB.GL_COA_BALNC_S
             WHERE  PERD_ID = :perd_id
                    AND SUBSTRING(TIM_MAIN_PERD_KEY,3,3) = 'JAN'
                    AND BALNC_DAT_TYP IN ('ADJ','GMAP_ADJ')) B
         ON A.LOCL_SEGMNT_KEY = B.LOCL_SEGMNT_KEY
            AND A.ES_SEGMNT1_KEY = B.ES_SEGMNT1_KEY
            AND A.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY
            AND A.ES_SEGMNT3_KEY = B.ES_SEGMNT3_KEY
            AND A.ES_SEGMNT4_KEY = B.ES_SEGMNT4_KEY
            AND A.ES_SEGMNT5_KEY = B.ES_SEGMNT5_KEY
            AND A.ES_SEGMNT6_KEY = B.ES_SEGMNT6_KEY
            AND A.ES_SEGMNT7_KEY = B.ES_SEGMNT7_KEY
            AND A.ES_SEGMNT8_KEY = B.ES_SEGMNT7_KEY
            AND A.ES_SEGMNT9_KEY = B.ES_SEGMNT8_KEY
            AND A.ES_SEGMNT10_KEY = B.ES_SEGMNT10_KEY
            AND A.ES_SEGMNT11_KEY = B.ES_SEGMNT11_KEY
            AND A.SET_OF_BOK_KEY = B.SET_OF_BOK_KEY
            AND A.LOCL_CURR_MAIN_KEY = B.LOCL_CURR_MAIN_KEY
            AND A.source_name = B.source_name
            AND A.PERD_ID =  :perd_id - 89   
JOIN $CFD_DB.GL_ES_SEGMNT2_DH1 C
ON C.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY
 )X
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID=X.SRC_SYS_ID;


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 14
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************TRANSLATED USD FOR ADJ ************************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
FC_PERD_NET_DR_AMT =X.FC_PTD_DR,
FC_PERD_NET_CR_AMT =X.FC_PTD_CR,
MOR_YTD_BALNC_DR_AMT =X.YTD_DR_MOR,
MOR_YTD_BALNC_CR_AMT =X.YTD_CR_MOR,
MOR_PERD_NET_DR_AMT =X.PTD_DR_MOR,
MOR_PERD_NET_CR_AMT =X.PTD_CR_MOR,
GAP_PERD_NET_DR_AMT =X.PTD_DR_GAP,
GAP_PERD_NET_CR_AMT =X.PTD_CR_GAP
FROM
(
SELECT B.SRC_SYS_ID
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN
        (CASE WHEN C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.FC_YTD_BALNC_DR_AMT, 0.00)
        ELSE COALESCE(B.FC_PERD_NET_DR_AMT, 0.00) END)
   ELSE COALESCE(B.FC_YTD_BALNC_DR_AMT, 0) - COALESCE(A.FC_YTD_BALNC_DR_AMT, 0.00) END AS FC_PTD_DR
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN
        (CASE WHEN C.ES_ACNT_TYP IN ('Expense','Revenue') THEN COALESCE(B.FC_YTD_BALNC_CR_AMT, 0.00)
        ELSE COALESCE(B.FC_PERD_NET_CR_AMT, 0.00) END)
   ELSE  COALESCE(B.FC_YTD_BALNC_CR_AMT, 0.00) - COALESCE(A.FC_YTD_BALNC_CR_AMT, 0.00) END AS FC_PTD_CR
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN
   CAST(B.FC_YTD_BALNC_DR_AMT AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
   ELSE COALESCE(A.MOR_YTD_BALNC_DR_AMT, 0.00) + CAST(FC_PTD_DR AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10)) END AS YTD_DR_MOR
,CASE
   WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(B.FC_YTD_BALNC_CR_AMT AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
   ELSE COALESCE(A.MOR_YTD_BALNC_CR_AMT, 0.00) + CAST(FC_PTD_CR AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10)) END AS YTD_CR_MOR
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PTD_DR AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
ELSE COALESCE(YTD_DR_MOR,0)-COALESCE(A.MOR_YTD_BALNC_DR_AMT,0.00) END PTD_DR_MOR
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PTD_CR AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))
ELSE COALESCE(YTD_CR_MOR,0)-COALESCE(A.MOR_YTD_BALNC_CR_AMT,0) END PTD_CR_MOR
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PTD_DR AS DECIMAL(38,10))* CAST(B.GAP_RT AS DECIMAL(38,10))
ELSE COALESCE(B.GAP_YTD_BALNC_DR_AMT,0)-COALESCE(A.GAP_YTD_BALNC_DR_AMT,0.00) END PTD_DR_GAP
,CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' AND C.ES_ACNT_TYP IN ('Expense','Revenue') THEN CAST(FC_PTD_CR AS DECIMAL(38,10)) * CAST(B.GAP_RT AS DECIMAL(38,10))
ELSE COALESCE(B.GAP_YTD_BALNC_CR_AMT,0)-COALESCE(A.GAP_YTD_BALNC_CR_AMT,0) END PTD_CR_GAP
FROM   (SELECT SRC_SYS_ID
               ,CD_COMBN_KEY
               ,LOCL_SEGMNT_KEY
               ,ES_SEGMNT1_KEY
               ,ES_SEGMNT2_KEY
               ,ES_SEGMNT3_KEY
               ,ES_SEGMNT4_KEY
               ,ES_SEGMNT5_KEY
               ,ES_SEGMNT6_KEY
               ,ES_SEGMNT7_KEY
               ,ES_SEGMNT8_KEY
               ,ES_SEGMNT9_KEY
               ,ES_SEGMNT10_KEY
               ,ES_SEGMNT11_KEY
               ,SET_OF_BOK_KEY
               ,FC_YTD_BALNC_DR_AMT
               ,FC_YTD_BALNC_CR_AMT
               ,MOR_YTD_BALNC_DR_AMT
               ,MOR_YTD_BALNC_CR_AMT
               ,GAP_YTD_BALNC_DR_AMT
               ,GAP_YTD_BALNC_CR_AMT
               ,LOCL_CURR_MAIN_KEY
               ,SOURCE_NAME
               ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
               ,PERD_ID
        FROM   $TGTDB.GL_COA_BALNC_F
        WHERE  PERD_ID =  :perd_id  -1 
        AND BALNC_DAT_TYP IN ('ADJ','GMAP_ADJ')) A
       JOIN (SELECT SRC_SYS_ID
                    ,LOCL_SEGMNT_KEY
                    ,ES_SEGMNT1_KEY
                    ,ES_SEGMNT2_KEY
                    ,ES_SEGMNT3_KEY
                    ,ES_SEGMNT4_KEY
                    ,ES_SEGMNT5_KEY
                    ,ES_SEGMNT6_KEY
                    ,ES_SEGMNT7_KEY
                    ,ES_SEGMNT8_KEY
                    ,ES_SEGMNT9_KEY
                    ,ES_SEGMNT10_KEY
                    ,ES_SEGMNT11_KEY
                    ,CD_COMBN_KEY
                    ,SET_OF_BOK_KEY
                    ,FC_YTD_BALNC_DR_AMT
                    ,FC_YTD_BALNC_CR_AMT
                    ,FC_PERD_NET_DR_AMT
                    ,FC_PERD_NET_CR_AMT
                    ,MOR_YTD_BALNC_DR_AMT
                    ,MOR_YTD_BALNC_CR_AMT
                    ,MOR_RT
                    ,GAP_YTD_BALNC_DR_AMT
                    ,GAP_YTD_BALNC_CR_AMT
                    ,GAP_RT
                    ,LOCL_CURR_MAIN_KEY
                    ,source_name
                    ,PERD_ID
                    ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
                    ,TIM_MAIN_PERD_KEY
             FROM   $STGDB.GL_COA_BALNC_S
             WHERE  PERD_ID = :perd_id
                    AND BALNC_DAT_TYP IN ('ADJ','GMAP_ADJ')) B
         ON A.LOCL_SEGMNT_KEY = B.LOCL_SEGMNT_KEY
            AND A.ES_SEGMNT1_KEY = B.ES_SEGMNT1_KEY
            AND A.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY
            AND A.ES_SEGMNT3_KEY = B.ES_SEGMNT3_KEY
            AND A.ES_SEGMNT4_KEY = B.ES_SEGMNT4_KEY
            AND A.ES_SEGMNT5_KEY = B.ES_SEGMNT5_KEY
            AND A.ES_SEGMNT6_KEY = B.ES_SEGMNT6_KEY
            AND A.ES_SEGMNT7_KEY = B.ES_SEGMNT7_KEY
            AND A.ES_SEGMNT8_KEY = B.ES_SEGMNT8_KEY
            AND A.ES_SEGMNT9_KEY = B.ES_SEGMNT9_KEY
            AND A.ES_SEGMNT10_KEY = B.ES_SEGMNT10_KEY
            AND A.ES_SEGMNT11_KEY = B.ES_SEGMNT11_KEY
            AND A.SET_OF_BOK_KEY = B.SET_OF_BOK_KEY
            AND A.LOCL_CURR_MAIN_KEY = B.LOCL_CURR_MAIN_KEY
            AND A.SOURCE_NAME = B.SOURCE_NAME
            AND A.PERD_ID = :perd_id - 1  
JOIN $CFD_DB.GL_ES_SEGMNT2_DH1 C
ON C.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY
 )X
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID=X.SRC_SYS_ID;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 15
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************FUNCTIONAL PTD FOR ADJ (If still NULL)*************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
 FC_PERD_NET_DR_AMT = CASE WHEN FC_PERD_NET_DR_AMT IS NULL THEN FC_YTD_BALNC_DR_AMT ELSE 0.00 END
,FC_PERD_NET_CR_AMT = CASE WHEN FC_PERD_NET_CR_AMT IS NULL THEN FC_YTD_BALNC_CR_AMT ELSE 0.00 END
WHERE
PERD_ID = :perd_id
AND BALNC_DAT_TYP IN ('ADJ','GMAP_ADJ')
AND
(FC_PERD_NET_DR_AMT IS NULL OR
 FC_PERD_NET_CR_AMT IS NULL);

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 16
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************TRANSLATED USD FOR ADJ (If still NULL) **********************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
 MOR_YTD_BALNC_DR_AMT = CASE WHEN MOR_YTD_BALNC_DR_AMT IS NULL THEN CAST(FC_YTD_BALNC_DR_AMT AS DECIMAL(38,10)) * CAST(MOR_RT AS DECIMAL(38,10)) ELSE 0.00 END
,MOR_YTD_BALNC_CR_AMT = CASE WHEN MOR_YTD_BALNC_CR_AMT IS NULL THEN CAST(FC_YTD_BALNC_CR_AMT AS DECIMAL(38,10)) * CAST(MOR_RT AS DECIMAL(38,10)) ELSE 0.00 END
,MOR_PERD_NET_DR_AMT = CASE WHEN MOR_PERD_NET_DR_AMT IS NULL THEN CAST(FC_PERD_NET_DR_AMT AS DECIMAL(38,10)) * CAST(MOR_RT AS DECIMAL(38,10)) ELSE 0.00 END
,MOR_PERD_NET_CR_AMT = CASE WHEN MOR_PERD_NET_CR_AMT IS NULL THEN CAST(FC_PERD_NET_CR_AMT AS DECIMAL(38,10)) * CAST(MOR_RT AS DECIMAL(38,10)) ELSE 0.00 END
,GAP_PERD_NET_DR_AMT = CASE WHEN GAP_PERD_NET_DR_AMT IS NULL THEN CAST(FC_PERD_NET_DR_AMT AS DECIMAL(38,10)) * CAST(GAP_RT AS DECIMAL(38,10)) ELSE 0.00 END
,GAP_PERD_NET_CR_AMT = CASE WHEN GAP_PERD_NET_CR_AMT IS NULL THEN CAST(FC_PERD_NET_CR_AMT AS DECIMAL(38,10)) * CAST(GAP_RT AS DECIMAL(38,10)) ELSE 0.00 END
WHERE
PERD_ID = :perd_id
AND BALNC_DAT_TYP IN ('ADJ','GMAP_ADJ')
AND
(MOR_YTD_BALNC_DR_AMT IS NULL OR
 MOR_YTD_BALNC_CR_AMT IS NULL OR
 MOR_PERD_NET_DR_AMT IS NULL  OR
 MOR_PERD_NET_CR_AMT IS NULL  OR
 GAP_PERD_NET_DR_AMT IS NULL  OR
 GAP_PERD_NET_CR_AMT IS NULL );

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 17
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/* ******************************BTQ_FGL_120_DUP_DWH_APPLDAMT_COA_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DUP_DWH_APPLDAMT_COA_BALNC_FS.sh--------- \n'

/*************************************APPLIED AMT for P&L**********************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
APPLD_FLAG              = 'MOR' ,
APPLD_RT                = TEMP.MOR_RT,
APPLD_PERD_NET_DR_AMT   = TEMP.MOR_PERD_NET_DR_AMT,
APPLD_PERD_NET_CR_AMT   = TEMP.MOR_PERD_NET_CR_AMT,
APPLD_YTD_BALNC_DR_AMT  = TEMP.MOR_YTD_BALNC_DR_AMT,
APPLD_YTD_BALNC_CR_AMT  = TEMP.MOR_YTD_BALNC_CR_AMT
FROM
(
SELECT A.SRC_SYS_ID
,A.SOURCE_NAME
,A.MOR_RT
,A.MOR_PERD_NET_DR_AMT
,A.MOR_PERD_NET_CR_AMT
,A.MOR_YTD_BALNC_DR_AMT
,A.MOR_YTD_BALNC_CR_AMT
FROM
$STGDB.GL_COA_BALNC_S A
,$CFD_DB.GL_ES_SEGMNT2_DH1 B
WHERE
A.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY AND
B.ES_ACNT_TYP IN ('Expense','Revenue')
) TEMP
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID = TEMP.SRC_SYS_ID ;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 18
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


/***************************************APPLIED AMT for BS  **********************/
UPDATE $STGDB.GL_COA_BALNC_S
SET
APPLD_FLAG              = 'GAP' ,
APPLD_RT                = TEMP.GAP_RT,
APPLD_PERD_NET_DR_AMT   = TEMP.GAP_PERD_NET_DR_AMT,
APPLD_PERD_NET_CR_AMT   = TEMP.GAP_PERD_NET_CR_AMT,
APPLD_YTD_BALNC_DR_AMT  = TEMP.GAP_YTD_BALNC_DR_AMT,
APPLD_YTD_BALNC_CR_AMT  = TEMP.GAP_YTD_BALNC_CR_AMT
FROM
(
SELECT
A.SRC_SYS_ID
,A.SOURCE_NAME
,A.GAP_RT
,A.GAP_PERD_NET_DR_AMT
,A.GAP_PERD_NET_CR_AMT
,A.GAP_YTD_BALNC_DR_AMT
,A.GAP_YTD_BALNC_CR_AMT
FROM
$STGDB.GL_COA_BALNC_S A
,$CFD_DB.GL_ES_SEGMNT2_DH1 B
WHERE
A.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY AND
(B.ES_ACNT_TYP IN ('Asset','Liability','OwnershipStockholdersEquity') OR B.ES_ACNT_TYP LIKE 'Owner%Equity')
) TEMP
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID = TEMP.SRC_SYS_ID ;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 19
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************FC & MOR AMT for TRANSLTN_CD='D'***************************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET     MOR_YTD_BALNC_DR_AMT = X.YTD_DR_MOR
       ,MOR_YTD_BALNC_CR_AMT = X.YTD_CR_MOR
       ,MOR_PERD_NET_DR_AMT = X.PTD_DR_MOR
       ,MOR_PERD_NET_CR_AMT = X.PTD_CR_MOR
       ,FC_PERD_NET_CR_AMT  = X.FC_PERD_NET_CR_AMT1
       ,FC_PERD_NET_DR_AMT  = X.FC_PERD_NET_DR_AMT1
FROM(
SELECT
B.SRC_SYS_ID
,B.FC_YTD_BALNC_DR_AMT - COALESCE(A.FC_YTD_BALNC_DR_AMT, 0.00) AS FC_PERD_NET_DR_AMT1
,B.FC_YTD_BALNC_CR_AMT - COALESCE(A.FC_YTD_BALNC_CR_AMT, 0.00) AS FC_PERD_NET_CR_AMT1
,COALESCE(A.APPLD_YTD_BALNC_DR_AMT, 0.00) + CAST(FC_PERD_NET_DR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10)) AS YTD_DR_MOR
,COALESCE(A.APPLD_YTD_BALNC_CR_AMT, 0.00) + CAST(FC_PERD_NET_CR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10)) AS YTD_CR_MOR
,CAST(FC_PERD_NET_DR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))  AS PTD_DR_MOR
,CAST(FC_PERD_NET_CR_AMT1 AS DECIMAL(38,10)) * CAST(B.MOR_RT AS DECIMAL(38,10))  AS PTD_CR_MOR
FROM
(SELECT
       CD_COMBN_KEY
       ,ES_SEGMNT1_KEY
       ,ES_SEGMNT2_KEY
       ,ES_SEGMNT3_KEY
       ,ES_SEGMNT4_KEY
       ,ES_SEGMNT5_KEY
       ,ES_SEGMNT6_KEY
       ,ES_SEGMNT7_KEY
       ,ES_SEGMNT8_KEY
       ,ES_SEGMNT9_KEY
       ,ES_SEGMNT10_KEY
       ,ES_SEGMNT11_KEY
       ,SET_OF_BOK_KEY
       ,SUM(FC_YTD_BALNC_DR_AMT ) AS FC_YTD_BALNC_DR_AMT
       ,SUM(FC_YTD_BALNC_CR_AMT ) AS FC_YTD_BALNC_CR_AMT
       ,SUM(APPLD_YTD_BALNC_DR_AMT ) AS APPLD_YTD_BALNC_DR_AMT
       ,SUM(APPLD_YTD_BALNC_CR_AMT ) AS APPLD_YTD_BALNC_CR_AMT
       ,SUM(GAP_YTD_BALNC_DR_AMT ) AS GAP_YTD_BALNC_DR_AMT
       ,SUM(GAP_YTD_BALNC_CR_AMT ) AS GAP_YTD_BALNC_CR_AMT
       ,LOCL_CURR_MAIN_KEY
       ,SOURCE_NAME
       ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
       ,PERD_ID
FROM   $TGTDB.GL_COA_BALNC_F
WHERE  PERD_ID =(CASE WHEN SUBSTRING(TRIM(:perd_id),5,2)='01' THEN :perd_id - 89 ELSE :perd_id - 1  END)
       AND BALNC_DAT_TYP IN('SYS','GMAP_SYS')
       group by 1,2,3,4,5,6,7,8,9,10,11,12,13,20,21,22,23
) A
JOIN
(SELECT SRC_SYS_ID
       ,CD_COMBN_KEY
       ,ES_SEGMNT1_KEY
       ,ES_SEGMNT2_KEY
       ,ES_SEGMNT3_KEY
       ,ES_SEGMNT4_KEY
       ,ES_SEGMNT5_KEY
       ,ES_SEGMNT6_KEY
       ,ES_SEGMNT7_KEY
       ,ES_SEGMNT8_KEY
       ,ES_SEGMNT9_KEY
       ,ES_SEGMNT10_KEY
       ,ES_SEGMNT11_KEY
       ,SET_OF_BOK_KEY
       ,FC_YTD_BALNC_DR_AMT
       ,FC_YTD_BALNC_CR_AMT
       ,FC_PERD_NET_DR_AMT
       ,FC_PERD_NET_CR_AMT
       ,MOR_YTD_BALNC_DR_AMT
       ,MOR_YTD_BALNC_CR_AMT
       ,MOR_RT
       ,GAP_YTD_BALNC_DR_AMT
       ,GAP_YTD_BALNC_CR_AMT
       ,GAP_RT
       ,LOCL_CURR_MAIN_KEY
       ,SOURCE_NAME
       ,PERD_ID
       ,COALESCE(ATRBT_1, 'DEFAULT') ATRBT_1
       ,TIM_MAIN_PERD_KEY
FROM   $STGDB.GL_COA_BALNC_S
WHERE  PERD_ID = :perd_id
       AND BALNC_DAT_TYP IN( 'SYS','GMAP_SYS')  ) B
         ON A.CD_COMBN_KEY = B.CD_COMBN_KEY
            AND A.ES_SEGMNT1_KEY = B.ES_SEGMNT1_KEY
            AND A.ES_SEGMNT2_KEY = B.ES_SEGMNT2_KEY
            AND A.ES_SEGMNT3_KEY = B.ES_SEGMNT3_KEY
            AND A.ES_SEGMNT4_KEY = B.ES_SEGMNT4_KEY
            AND A.ES_SEGMNT5_KEY = B.ES_SEGMNT5_KEY
            AND A.ES_SEGMNT6_KEY = B.ES_SEGMNT6_KEY
            AND A.ES_SEGMNT7_KEY = B.ES_SEGMNT7_KEY
            AND A.ES_SEGMNT8_KEY = B.ES_SEGMNT8_KEY
            AND A.ES_SEGMNT9_KEY = B.ES_SEGMNT9_KEY
            AND A.ES_SEGMNT10_KEY = B.ES_SEGMNT10_KEY
            AND A.ES_SEGMNT11_KEY = B.ES_SEGMNT11_KEY
            AND A.SET_OF_BOK_KEY = B.SET_OF_BOK_KEY
            AND A.LOCL_CURR_MAIN_KEY = B.LOCL_CURR_MAIN_KEY
            AND A.SOURCE_NAME = B.SOURCE_NAME
            AND COALESCE(A.ATRBT_1, 'DEFAULT') = COALESCE(B.ATRBT_1, 'DEFAULT')
            AND A.PERD_ID = (CASE WHEN B.TIM_MAIN_PERD_KEY LIKE '%JAN%' THEN :perd_id - 89 ELSE :perd_id - 1  END)
AND B.ES_SEGMNT2_KEY in (
SELECT D.SEGMNT_K2_KEY  FROM $CFD_DB.gl_coa_segmnt2_d D
WHERE  D.SOURCE_NAME='ECA'
AND D.TRANSLTN_CD='D')
)X
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID = X.SRC_SYS_ID;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 20
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************APPLIED AMT for TRANSLTN_CD='D'***************************************/

UPDATE $STGDB.GL_COA_BALNC_S
SET
APPLD_FLAG              = 'MOR-T' ,
APPLD_RT                = TEMP.MOR_RT,
APPLD_PERD_NET_DR_AMT   = TEMP.MOR_PERD_NET_DR_AMT,
APPLD_PERD_NET_CR_AMT   = TEMP.MOR_PERD_NET_CR_AMT,
APPLD_YTD_BALNC_DR_AMT  = TEMP.MOR_YTD_BALNC_DR_AMT,
APPLD_YTD_BALNC_CR_AMT  = TEMP.MOR_YTD_BALNC_CR_AMT
FROM
(
SELECT A.SRC_SYS_ID
,A.SOURCE_NAME
,A.MOR_RT
,A.MOR_PERD_NET_DR_AMT
,A.MOR_PERD_NET_CR_AMT
,A.MOR_YTD_BALNC_DR_AMT
,A.MOR_YTD_BALNC_CR_AMT
FROM
$STGDB.GL_COA_BALNC_S A
,$CFD_DB.GL_COA_SEGMNT2_D B
WHERE
A.ES_SEGMNT2_KEY = B.SEGMNT_K2_KEY
AND B.SOURCE_NAME='ECA'
AND B.TRANSLTN_CD='D'
--AND APPLD_FLAG= 'GAP'
) TEMP
WHERE
$STGDB.GL_COA_BALNC_S.SRC_SYS_ID = TEMP.SRC_SYS_ID ;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 21
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************APPLIED AMT for HIST OVERRIDES for SYS(GLP,BIO,HCIT)**********************/


DROP TABLE IF EXISTS GL_COA_ES_HBR_S;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 22
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

CREATE TEMPORARY TABLE IF NOT EXISTS GL_COA_ES_HBR_S
(
LOCL_SEGMNT1_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT2_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT3_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT4_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT5_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT6_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT7_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT8_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT9_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT10_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
LOCL_SEGMNT11_KEY character varying(250)  COLLATE CASE_INSENSITIVE,
PERD_ID INTEGER,
SRC_NAM CHARACTER VARYING(50)COLLATE CASE_INSENSITIVE,
HIST_AMT DECIMAL(38,10),
TIM_MAIN_PERD_KEY character varying(250)  COLLATE CASE_INSENSITIVE
)
DISTSTYLE EVEN;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 23
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

INSERT INTO GL_COA_ES_HBR_S
(
LOCL_SEGMNT1_KEY ,
LOCL_SEGMNT2_KEY ,
LOCL_SEGMNT3_KEY ,
LOCL_SEGMNT4_KEY ,
LOCL_SEGMNT5_KEY ,
LOCL_SEGMNT6_KEY ,
LOCL_SEGMNT7_KEY ,
LOCL_SEGMNT8_KEY ,
LOCL_SEGMNT9_KEY ,
LOCL_SEGMNT10_KEY,
LOCL_SEGMNT11_KEY,
PERD_ID,
SRC_NAM,
HIST_AMT,
TIM_MAIN_PERD_KEY
)
select 
LOCL_SEGMNT1_KEY ,
LOCL_SEGMNT2_KEY ,
LOCL_SEGMNT3_KEY ,
LOCL_SEGMNT4_KEY ,
LOCL_SEGMNT5_KEY ,
LOCL_SEGMNT6_KEY ,
LOCL_SEGMNT7_KEY ,
LOCL_SEGMNT8_KEY ,
LOCL_SEGMNT9_KEY ,
LOCL_SEGMNT10_KEY,
LOCL_SEGMNT11_KEY,
'-99999',
case when SUBSTRING(CurrentlyProcessedFileName,10,3)='GLP' then 'GLPROD'
     WHEN SUBSTRING(CurrentlyProcessedFileName,10,3)='PS9' then 'HCIT_PS9'
     WHEN SUBSTRING(CurrentlyProcessedFileName,10,3)='SAP' then 'BIO-SAPEU'
     END  AS SOURCE_NAME,
hbr_amt ,
SUBSTRING(LOCL_SEGMNT_KEY, REGEXP_INSTR (LOCL_SEGMNT_KEY, '[.]', 1, 13)+1)
from $FLAT_FILE_DB.es_hbr_histoverrides ;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 24
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

UPDATE GL_COA_ES_HBR_S
SET PERD_ID=sub.PERD
FROM
(SELECT PERD_KEY AS KEY1,PERD_ID AS PERD  FROM $CFD_DB.TIM_MAIN_PERD_D WHERE SOURCE_NAME='GLPROD' GROUP BY 1,2) sub
WHERE
GL_COA_ES_HBR_S.TIM_MAIN_PERD_KEY=sub.KEY1;


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 25
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

DELETE FROM GL_COA_ES_HBR_S WHERE COALESCE(PERD_ID,'999999') NOT IN (:perd_id);

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 26
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

UPDATE $STGDB.GL_COA_BALNC_S 
SET HIST_RT                = A.HIST_RT,
       HIST_AMT               = A.HIST_AMT,
       APPLD_FLAG             = 'HIST' ,
       APPLD_RT               = A.HIST_RT,
       APPLD_PERD_NET_DR_AMT  = 0,
       APPLD_PERD_NET_CR_AMT  = 0,
       APPLD_YTD_BALNC_DR_AMT = A.HIST_AMT,
       APPLD_YTD_BALNC_CR_AMT = 0
FROM (
SELECT
 B.SRC_SYS_ID AS SRC_SYS_ID
,1 AS HIST_RT
,A.HIST_AMT
FROM
GL_COA_ES_HBR_S A
,$STGDB.GL_COA_BALNC_S B
--(SEL SEGMNT_K2_KEY,TRANSLTN_CD  FROM $ODS_ETL_TARGET.GL_COA_SEGMNT2_D WHERE SRC_IDN=250 AND TRANSLTN_CD='D' GROUP BY 1,2) C
--,$ODS_TARGT.GCD_DAT_SORC_D D
 WHERE A.LOCL_SEGMNT1_KEY = COALESCE(B.LOCL_SEGMNT1_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT2_KEY = COALESCE(B.LOCL_SEGMNT2_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT3_KEY = COALESCE(B.LOCL_SEGMNT3_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT4_KEY = COALESCE(B.LOCL_SEGMNT4_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT5_KEY = COALESCE(B.LOCL_SEGMNT5_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT6_KEY = COALESCE(B.LOCL_SEGMNT6_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT7_KEY = COALESCE(B.LOCL_SEGMNT7_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT8_KEY = COALESCE(B.LOCL_SEGMNT8_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT9_KEY = COALESCE(B.LOCL_SEGMNT9_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT10_KEY = COALESCE(B.LOCL_SEGMNT10_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT11_KEY = COALESCE(B.LOCL_SEGMNT11_KEY, 'DEFAULT') AND
       --A.SET_OF_BOK_KEY = B.SET_OF_BOK_KEY AND
       --A.TIM_MAIN_PERD_KEY = B.TIM_MAIN_PERD_KEY AND
       A.PERD_ID = B.PERD_ID AND
       --B.ES_SEGMNT2_KEY = C.SEGMNT_K2_KEY AND
       A.SRC_NAM = B.SOURCE_NAME AND
       --B.SRC_IDN = D.DATA_SORC_IDN AND
       B.BALNC_DAT_TYP='SYS'
       --C.BALNC_FLTR_TYP = 'HISTORICAL ACCOUNTS' AND
       --A.BALNC_DAT_TYP = 'HBR'
) A
WHERE $STGDB.GL_COA_BALNC_S.SRC_SYS_ID = A.SRC_SYS_ID
AND $STGDB.GL_COA_BALNC_S.SOURCE_NAME IN ('GLPROD','HCIT_PS9','BIO-SAPEU');


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 27
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

/***************************************APPLIED AMT 0 for HIST OVERRIDES GMAP_SYS(GLP,BIO,HCIT) **********************/

UPDATE $STGDB.GL_COA_BALNC_S 
   SET HIST_RT                = A.HIST_RT,
       HIST_AMT               = 0,
       APPLD_FLAG             = 'HIST' ,
       APPLD_RT               = A.HIST_RT,
       APPLD_PERD_NET_DR_AMT  = 0,
       APPLD_PERD_NET_CR_AMT  = 0,
       APPLD_YTD_BALNC_DR_AMT = 0,
       APPLD_YTD_BALNC_CR_AMT = 0
FROM (
SELECT
 B.SRC_SYS_ID AS SRC_SYS_ID
,1 AS HIST_RT
,A.HIST_AMT
FROM
GL_COA_ES_HBR_S A
,$STGDB.GL_COA_BALNC_S  B
--(SEL SEGMNT_K2_KEY,TRANSLTN_CD  FROM $ODS_ETL_TARGET.GL_COA_SEGMNT2_D WHERE SRC_IDN=250 AND TRANSLTN_CD='D' GROUP BY 1,2) C
--,$ODS_TARGT.GCD_DAT_SORC_D D
 WHERE A.LOCL_SEGMNT1_KEY = COALESCE(B.LOCL_SEGMNT1_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT2_KEY = COALESCE(B.LOCL_SEGMNT2_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT3_KEY = COALESCE(B.LOCL_SEGMNT3_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT4_KEY = COALESCE(B.LOCL_SEGMNT4_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT5_KEY = COALESCE(B.LOCL_SEGMNT5_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT6_KEY = COALESCE(B.LOCL_SEGMNT6_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT7_KEY = COALESCE(B.LOCL_SEGMNT7_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT8_KEY = COALESCE(B.LOCL_SEGMNT8_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT9_KEY = COALESCE(B.LOCL_SEGMNT9_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT10_KEY = COALESCE(B.LOCL_SEGMNT10_KEY, 'DEFAULT') AND
       A.LOCL_SEGMNT11_KEY = COALESCE(B.LOCL_SEGMNT11_KEY, 'DEFAULT') AND
       --A.SET_OF_BOK_KEY = B.SET_OF_BOK_KEY AND
       --A.TIM_MAIN_PERD_KEY = B.TIM_MAIN_PERD_KEY AND
       A.PERD_ID = B.PERD_ID AND
       --B.ES_SEGMNT2_KEY = C.SEGMNT_K2_KEY AND
       A.SRC_NAM = B.SOURCE_NAME AND
       --B.SRC_IDN = D.DATA_SORC_IDN AND
       B.BALNC_DAT_TYP='GMAP_SYS'
       --C.BALNC_FLTR_TYP = 'HISTORICAL ACCOUNTS' AND
       --A.BALNC_DAT_TYP = 'HBR'
) A
WHERE $STGDB.GL_COA_BALNC_S.SRC_SYS_ID = A.SRC_SYS_ID
AND $STGDB.GL_COA_BALNC_S.SOURCE_NAME IN ('GLPROD','HCIT_PS9','BIO-SAPEU');

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 28
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


/* ******************************BTQ_FGL_120_DUP_DWH_FCTA_COA_BALNC_FS.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DUP_DWH_FCTA_COA_BALNC_FS.sh--------- \n'

UPDATE $STGDB.GL_COA_BALNC_S
SET
FCTA_YTD_BALNC_CR_AMT  = FCTA_YTD_BALNC_NET_AMOUNT,
APPLD_YTD_BALNC_CR_AMT = FCTA_YTD_BALNC_NET_AMOUNT,
APPLD_FLAG             = 'FCTA'
FROM
(
SELECT
SET_OF_BOK_KEY
,ES_SEGMNT1_KEY
,SOURCE_NAME
,(SUM(APPLD_YTD_BALNC_DR_AMT - APPLD_YTD_BALNC_CR_AMT)) AS FCTA_YTD_BALNC_NET_AMOUNT
FROM
$STGDB.GL_COA_BALNC_S
WHERE
PERD_ID = :perd_id
GROUP BY 1,2,3
) TEMP
WHERE
DATA_ORIGIN = 'MANUAL-FCTA'
AND PERD_ID = :perd_id
AND $STGDB.GL_COA_BALNC_S.SOURCE_NAME = TEMP.SOURCE_NAME
AND $STGDB.GL_COA_BALNC_S.ES_SEGMNT1_KEY = TEMP.ES_SEGMNT1_KEY
AND $STGDB.GL_COA_BALNC_S.SET_OF_BOK_KEY = TEMP.SET_OF_BOK_KEY;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 29
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


COMMIT;


end;

EOF

rsqlexitcode=$?

echo " Amount Updation Completed for Global Balance"

echo "Exited with error code $rsqlexitcode"
echo "---------------------------------"

script_ended=$(date "+%F-%H-%M-%S")
echo "Script ended at --> $script_ended"

end=`date +%s`
exec=`expr $end - $start`
time_taken=`date -d@$exec -u +%H:%M:%S`

echo "Time Taken --> $time_taken"

python3 /ops/finance/common/scripts/send_sfn_token.py $token $script_name $rsqlexitcode $log_file_name

exit $rsqlexitcode