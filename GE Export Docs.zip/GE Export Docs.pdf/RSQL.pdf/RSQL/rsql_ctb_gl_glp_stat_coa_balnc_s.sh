#-GE CONFIDENTIAL- or -GE HIGHLY CONFIDENTIAL-
#Type: Source Code
#Copyright (c) 2022, GE Healthcare
#All Rights Reserved
#This unpublished material is proprietary to GE Healthcare. The methods and
#techniques described herein are considered trade secrets and/or
#confidential. Reproduction or distribution, in whole or in part, is
#forbidden except by express written permission of GE Healthcare.


# <RSQL> SCRIPT NAME - rsql_ctb_gl_glp_stat_coa_balnc_s.sh  </RSQL>
# <RSQL> SCRIPT DESCRIPTION - "Current RSQL is inserting data to $STGDB.GL_GLP_STAT_COA_BALNC_S from $GLPROD_EXT_DB.GL_CODE_COMBINATIONS, $GLPROD_EXT_DB.GL_BALANCES tables as a part of STAT Flow"  </RSQL>
# <RSQL> PARAMETER FILE NAME - ctb_parameter.sh.sh </RSQL>
# <RSQL>  SOURCE SCHEMA - $GLPROD_EXT_DB  </RSQL>
# <RSQL>  SOURCE TABLE  - GL_CODE_COMBINATIONS , GL_BALANCES  </RSQL>
# <RSQL>  TARGET SCHEMA - $STGDB  </RSQL>
# <RSQL>  TARGET TABLE  - GL_GLP_STAT_COA_BALNC_S </RSQL>
# <RSQL>  STMT TYPES    - TRUNCATE , INSERT , UPDATE  </RSQL>
# <RSQL>  CREATED ON    - 09-DEC-2022  </RSQL>
# <RSQL>  CREATED BY    - healthfinance.odpctb@ge.com  </RSQL>
# <RSQL>  LAST MODIFIED ON    - 12-DEC-2022  </RSQL>
# <RSQL>  LAST MODIFIED BY    - healthfinance.odpctb@ge.com  </RSQL>


echo "Calling the CTB Parameter file --> ctb_parameter.sh"
source /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "Printing Content of Parameter File"
cat /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "--------------------------------------------------------"

echo "                              "
echo "Current RSQL is inserting data to $STGDB.GL_GLP_STAT_COA_BALNC_S from $GLPROD_EXT_DB.GL_BALANCES A,$GLPROD_EXT_DB.GL_CODE_COMBINATIONS table as a part of STAT Flow"
echo "                              "

script_started=$(date "+%F-%H-%M-%S")
echo "Script Started at --> $script_started"

start=`date +%s`

#source /ops/finance/common/scripts/get_redshift_creds.sh 'odp-fin-nprod-ctb-fsso' 'us-east-1'
source /ops/finance/common/scripts/aws_run_profile.sh $1 $2 $3 $4


rsql -h $HOST -U $USER -d $DB << EOF
\timing true

/* Set the Query Band for the session */

\echo '\n ----Setting Query Band to $QBSTR--------- \n'
SET query_group to '$QBSTR';

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 1
\else
 \remark '\n **** Statement 1 Executed Successfully **** \n'
\endif


\echo '\n ----Setting Search Path to $STGDB--------- \n'

/* ******************************Setting Database************************************************* */
SET SEARCH_PATH TO $STGDB, pg_catalog;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 2
\else
 \remark '\n **** Statement 2 Executed Successfully **** \n'
\endif

/* ------------------------------ Getting current period data from HDL_CMN_DATA.GL_COA_PERD_D ------------------------------ */

select perd_id as stat_perd from $CFD_DB.gl_coa_perd_d  ; 
\gset

\if :ERROR <> 0
    \echo 'Getting data from HDL_CMN_DATA.GL_COA_PERD Failed'
    \echo 'Error Code -'
    \echo :ERRORCODE
    \remark :LAST_ERROR_MESSAGE
    \exit 3
\else
    \echo :ACTIVITYCOUNT
    \remark '\n **** Statement 3 Executed Successfully **** \n'
\endif

\echo "STAT PERIOD --> " :stat_perd

CALL $CMN_SP_DB.SP_STAGE_TRUNCATE('$STGDB','GL_GLP_STAT_COA_BALNC_S');
--TRUNCATE TABLE $STGDB.GL_GLP_STAT_COA_BALNC_S;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 4
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 4 TRUNCATE Executed Successfully **** \n'
\endif

CALL $CMN_SP_DB.SP_STAGE_TRUNCATE('$STGDB','GL_GLP_ALL_BALNC_S');
--TRUNCATE TABLE $STGDB.GL_GLP_ALL_BALNC_S ;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 5
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 5 TRUNCATE Executed Successfully **** \n'
\endif

BEGIN ;

CREATE TEMPORARY TABLE GL_GLP_STAT_TEMP
(
LOCL_SEGMNT1_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT2_KEY   CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT3_KEY   CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT4_KEY   CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT5_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT6_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT7_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT8_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT9_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT10_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,LOCL_SEGMNT11_KEY   CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,SET_OF_BOK_KEY CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,CD_COMBN_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,CURR_MAIN_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,TIM_MAIN_PERD_KEY  CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,PERIOD_NET_DR_AMT  NUMERIC(38,10)
,PERIOD_NET_CR_AMT  NUMERIC(38,10)
,BEGIN_BALANCE_DR_AMT  NUMERIC(38,10)
,BEGIN_BALANCE_CR_AMT  NUMERIC(38,10)
,PERIOD_NET_DR_BEQ_AMT  NUMERIC(38,10)
,PERIOD_NET_CR_BEQ_AMT  NUMERIC(38,10)
,BEGIN_BALANCE_DR_BEQ_AMT  NUMERIC(38,10)
,BEGIN_BALANCE_CR_BEQ_AMT  NUMERIC(38,10)
,YTD_BALNC_DR_AMT  NUMERIC(38,10)
,YTD_BALNC_CR_AMT  NUMERIC(38,10)
,TRANSLTD_FLAG CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,ENTITY_STATS_FLAG CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,PERD_ID INTEGER
,SRC_CRETN_ID  CHARACTER VARYING(50)COLLATE CASE_INSENSITIVE
,SRC_CRETN_TS TIMESTAMP WITHOUT TIME ZONE 
,SRC_UPD_ID  CHARACTER VARYING(50)COLLATE CASE_INSENSITIVE
,SRC_UPD_TS TIMESTAMP WITHOUT TIME ZONE 
,DAT_ORGN  CHARACTER VARYING(50)COLLATE CASE_INSENSITIVE
,POSTNG_AGNT  CHARACTER VARYING(50)COLLATE CASE_INSENSITIVE
,SRC_NAM CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
,TGT_POSTNG_TS TIMESTAMP WITHOUT TIME ZONE 
,TGT_UPD_TS TIMESTAMP WITHOUT TIME ZONE 
)
DISTSTYLE EVEN;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 6
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 6 Executed Successfully **** \n'
\endif

INSERT INTO GL_GLP_STAT_TEMP 
(
LOCL_SEGMNT1_KEY 
,LOCL_SEGMNT2_KEY 
,LOCL_SEGMNT3_KEY 
,LOCL_SEGMNT4_KEY 
,LOCL_SEGMNT5_KEY 
,LOCL_SEGMNT6_KEY 
,LOCL_SEGMNT7_KEY 
,LOCL_SEGMNT8_KEY 
,LOCL_SEGMNT9_KEY 
,LOCL_SEGMNT10_KEY 
,LOCL_SEGMNT11_KEY  
,SET_OF_BOK_KEY
,CD_COMBN_KEY 
,CURR_MAIN_KEY 
,TIM_MAIN_PERD_KEY 
,PERIOD_NET_DR_AMT 
,PERIOD_NET_CR_AMT 
,BEGIN_BALANCE_DR_AMT 
,BEGIN_BALANCE_CR_AMT 
,PERIOD_NET_DR_BEQ_AMT 
,PERIOD_NET_CR_BEQ_AMT 
,BEGIN_BALANCE_DR_BEQ_AMT 
,BEGIN_BALANCE_CR_BEQ_AMT 
,YTD_BALNC_DR_AMT 
,YTD_BALNC_CR_AMT 
,TRANSLTD_FLAG
,ENTITY_STATS_FLAG
,PERD_ID 
,SRC_CRETN_ID 
,SRC_CRETN_TS 
,SRC_UPD_ID 
,SRC_UPD_TS 
,DAT_ORGN 
,POSTNG_AGNT 
,SRC_NAM 
,TGT_POSTNG_TS 
,TGT_UPD_TS
)
SELECT
SEGMENT1,
SEGMENT2,
SEGMENT3,
SEGMENT4,
SEGMENT5,
SEGMENT6,
SEGMENT7,
SEGMENT8,
SEGMENT9,
SEGMENT10,
SEGMENT11,
LEDGER_ID,
A.CODE_COMBINATION_ID,
CURRENCY_CODE,
PERIOD_NAME,
PERIOD_NET_DR,
PERIOD_NET_CR,
BEGIN_BALANCE_DR,
BEGIN_BALANCE_CR,
PERIOD_NET_DR_BEQ,
PERIOD_NET_CR_BEQ,
BEGIN_BALANCE_DR_BEQ,
BEGIN_BALANCE_CR_BEQ,
(PERIOD_NET_DR+BEGIN_BALANCE_DR )YTD_DR,
(PERIOD_NET_CR+BEGIN_BALANCE_CR )YTD_CR,
TRANSLATED_FLAG,
Null as ENTITY_STATS_FLAG,
cast(PERIOD_YEAR||SUBSTRING(PERIOD_NAME,1,2) as INTEGER),
'-99999' as SRC_CRETN_ID,
A.LAST_UPDATE_DATE as SRC_CRETN_TS,
'-99999' as SRC_UPD_ID,
A.LAST_UPDATE_DATE as SRC_UPD_TS,
'GL.GL_BALANCE' as DAT_ORGN,
'rsql_ctb_gl_glp_stat_coa_balnc_s.sh' as POSTNG_AGNT,
'GLPROD' as source_name,
CURRENT_TIMESTAMP(0),
CURRENT_TIMESTAMP(0)
FROM 
$GLPROD_DB.GL_BALANCES A,
$GLPROD_EXT_DB.GL_CODE_COMBINATIONS B
WHERE
A.CODE_COMBINATION_ID=B.CODE_COMBINATION_ID
AND A.actual_flag = 'A'
AND A.currency_code != 'STAT'
AND B.summary_flag = 'N' 
AND (TRANSLATED_FLAG IS NULL OR TRANSLATED_FLAG='R' OR TRANSLATED_FLAG='Y')
AND 
(
A.LAST_UPDATE_DATE > (select cdc.source_last_update_date from $TGTDB.last_upd_for_cdc_tables_fin cdc where cdc.src_sys_id='gl_glp_stat_coa_balnc_s~gl_balances' AND A.is_deleted=0)
OR 
A.HVR_LAST_UPD_TMS > (select cdc.source_last_update_date from $TGTDB.last_upd_for_cdc_tables_fin cdc where cdc.src_sys_id='gl_glp_stat_coa_balnc_s~gl_balances' AND A.is_deleted=1)
 );

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 7
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 7 Executed Successfully **** \n'
\endif

/*------------------UPDATE BEGIN_BALANCE AMT 4 REST ALL------------------*/

CREATE TEMPORARY TABLE GL_COA_BALNC_F_VT
(
CD_COMBN_KEY VARCHAR(250) COLLATE CASE_INSENSITIVE,
ES_SEGMNT1_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT2_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT3_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT4_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT5_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT6_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT7_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT8_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT9_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT10_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
ES_SEGMNT11_KEY VARCHAR(100) COLLATE CASE_INSENSITIVE,
LEDGR_CATGRY_CD VARCHAR(30) COLLATE CASE_INSENSITIVE,
SET_OF_BOK_KEY VARCHAR(50) COLLATE CASE_INSENSITIVE,
FC_YTD_BALNC_DR_AMT DECIMAL(38,10),
FC_YTD_BALNC_CR_AMT DECIMAL(38,10),
LOCL_CURR_MAIN_KEY VARCHAR(50) COLLATE CASE_INSENSITIVE,
SOURCE_NAME VARCHAR(250) COLLATE CASE_INSENSITIVE,
TRANS_CURR_MAIN_KEY VARCHAR(50) COLLATE CASE_INSENSITIVE,
ATRBT_1 VARCHAR(100) COLLATE CASE_INSENSITIVE,
PERD_ID INTEGER,
FISCL_YEAR INTEGER,
FISCL_MONTH INTEGER,
BALNC_TYP_KEY VARCHAR(50) COLLATE CASE_INSENSITIVE
)
DISTSTYLE EVEN;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 8
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 8 Executed Successfully **** \n'
\endif

/*------------------INSERT INTO VT TABLE------------------*/

INSERT INTO GL_COA_BALNC_F_VT
(
CD_COMBN_KEY,
ES_SEGMNT1_KEY,
ES_SEGMNT2_KEY,
ES_SEGMNT3_KEY,
ES_SEGMNT4_KEY,
ES_SEGMNT5_KEY,
ES_SEGMNT6_KEY,
ES_SEGMNT7_KEY,
ES_SEGMNT8_KEY,
ES_SEGMNT9_KEY,
ES_SEGMNT10_KEY,
ES_SEGMNT11_KEY,
LEDGR_CATGRY_CD,
SET_OF_BOK_KEY,
LOCL_CURR_MAIN_KEY,
SOURCE_NAME,
TRANS_CURR_MAIN_KEY,
ATRBT_1,
PERD_ID,
BALNC_TYP_KEY,
FC_YTD_BALNC_DR_AMT,
FC_YTD_BALNC_CR_AMT
)
SELECT  
CD_COMBN_KEY,
ES_SEGMNT1_KEY,
ES_SEGMNT2_KEY,
ES_SEGMNT3_KEY,
ES_SEGMNT4_KEY,
ES_SEGMNT5_KEY,
ES_SEGMNT6_KEY,
ES_SEGMNT7_KEY,
ES_SEGMNT8_KEY,
ES_SEGMNT9_KEY,
ES_SEGMNT10_KEY,
ES_SEGMNT11_KEY,
LEDGR_CATGRY_CD,
SET_OF_BOK_KEY,
LOCL_CURR_MAIN_KEY,
SOURCE_NAME,
TRANS_CURR_MAIN_KEY,
ATRBT_1,
PERD_ID,
BALNC_TYP_KEY,
SUM(FC_YTD_BALNC_DR_AMT),
SUM(FC_YTD_BALNC_CR_AMT)
FROM $TGTDB.GL_COA_BALNC_F
WHERE PERD_ID 
IN 
(
SELECT PERD_ID FROM $CFD_DB.TIM_MAIN_PERD_D TMPD
WHERE PERD_ID<=(SELECT PERD_ID FROM $CFD_DB.GL_COA_PERD_D)
AND PERD_ID/100 > (SELECT PERD_ID/100-3 FROM $CFD_DB.GL_COA_PERD_D)  
AND SOURCE_NAME = 'GLPROD'
)
AND  BALNC_TYP_KEY IN ('5')
AND  BALNC_DAT_TYP NOT in ('ADJ')
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 9
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 9 Executed Successfully **** \n'
\endif

CREATE TEMPORARY TABLE BALNC_FLTR
(
BALNC_FLTR_KEY1 CHARACTER VARYING(300) COLLATE CASE_INSENSITIVE,
BALNC_FLTR_KEY2 CHARACTER VARYING(300) COLLATE CASE_INSENSITIVE,
SOURCE_NAME CHARACTER VARYING(100) COLLATE CASE_INSENSITIVE
)
DISTSTYLE ALL;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 10
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 10 Executed Successfully **** \n'
\endif

INSERT INTO BALNC_FLTR 
(
BALNC_FLTR_KEY1,
BALNC_FLTR_KEY2,
SOURCE_NAME
)
SELECT 
FLTR.BALNC_FLTR_KEY1,
FLTR.BALNC_FLTR_KEY2,
FLTR.SOURCE_NAME AS SOURCE_NAME
FROM 
$STGDB.GL_BALNC_FLTR_S FLTR
WHERE FLTR.BALNC_FLTR_TYP='ENTITY-LEDGR'
GROUP BY 1,2,3;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 11
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 11 Executed Successfully **** \n'
\endif

INSERT INTO $STGDB.GL_GLP_ALL_BALNC_S 
             (LOCL_SEGMNT1_KEY 
             ,LOCL_SEGMNT2_KEY 
             ,LOCL_SEGMNT3_KEY 
             ,LOCL_SEGMNT4_KEY 
             ,LOCL_SEGMNT5_KEY 
             ,LOCL_SEGMNT6_KEY 
             ,LOCL_SEGMNT7_KEY 
             ,LOCL_SEGMNT8_KEY 
             ,LOCL_SEGMNT9_KEY 
             ,LOCL_SEGMNT10_KEY 
             ,LOCL_SEGMNT11_KEY  
             ,LOCL_SEGMNT_KEY_DESC 
             ,SET_OF_BOK_KEY 
             ,CD_COMBN_KEY 
             ,BALNC_TYP_KEY 
             ,CURR_MAIN_KEY 
             ,TIM_MAIN_PERD_KEY 
             ,PERIOD_NET_DR_AMT 
             ,PERIOD_NET_CR_AMT 
             ,BEGIN_BALANCE_DR_AMT 
             ,BEGIN_BALANCE_CR_AMT 
             ,PERIOD_NET_DR_BEQ_AMT 
             ,PERIOD_NET_CR_BEQ_AMT 
             ,BEGIN_BALANCE_DR_BEQ_AMT 
             ,BEGIN_BALANCE_CR_BEQ_AMT 
             ,YTD_BALNC_DR_AMT 
             ,YTD_BALNC_CR_AMT 
             ,OP_RT 
             ,OP_PERD_NET_DR_AMT 
             ,OP_PERD_NET_CR_AMT 
             ,OP_YTD_BALNC_DR_AMT 
             ,OP_YTD_BALNC_CR_AMT 
             ,ENTITY_STATS_FLAG 
             ,TRANSLTD_FLAG 
			 ,LEDGR_CATGRY_CD
             ,ESB_FLAG 
             ,STAT_FLAG 
             ,ATRBT_1 
             ,ATRBT_2 
             ,ATRBT_3 
             ,ATRBT_4 
             ,ATRBT_5 
             ,PERD_ID 
             ,LOAD_ID 
             ,SRC_SYS_ID 
             ,SRC_CRETN_ID 
             ,SRC_CRETN_TS 
             ,SRC_UPD_ID 
             ,SRC_UPD_TS 
             ,DAT_ORGN 
             ,POSTNG_AGNT 
             ,SRC_NAM 
             ,TGT_POSTNG_TS 
             ,TGT_UPD_TS
			 ,ES_SEGMNT1_KEY 
             ,ES_SEGMNT2_KEY 
             ,ES_SEGMNT3_KEY 
             ,ES_SEGMNT4_KEY 
             ,ES_SEGMNT5_KEY 
             ,ES_SEGMNT6_KEY 
             ,ES_SEGMNT7_KEY 
             ,ES_SEGMNT8_KEY 
             ,ES_SEGMNT9_KEY 
             ,ES_SEGMNT10_KEY 
             ,ES_SEGMNT11_KEY 
             ,SOURCE_NAME
             ) 
SELECT 
GLP.LOCL_SEGMNT1_KEY         AS LOCL_SEGMNT1_KEY_FINAL 
,GLP.LOCL_SEGMNT2_KEY         AS LOCL_SEGMNT2_KEY 
,GLP.LOCL_SEGMNT3_KEY         AS LOCL_SEGMNT3_KEY 
,GLP.LOCL_SEGMNT4_KEY         AS LOCL_SEGMNT4_KEY 
,GLP.LOCL_SEGMNT5_KEY         AS LOCL_SEGMNT5_KEY 
,GLP.LOCL_SEGMNT6_KEY         AS LOCL_SEGMNT6_KEY 
,GLP.LOCL_SEGMNT7_KEY         AS LOCL_SEGMNT7_KEY 
,GLP.LOCL_SEGMNT8_KEY         AS LOCL_SEGMNT8_KEY 
,GLP.LOCL_SEGMNT9_KEY         AS LOCL_SEGMNT9_KEY 
,GLP.LOCL_SEGMNT10_KEY        AS LOCL_SEGMNT10_KEY 
,GLP.LOCL_SEGMNT11_KEY        AS LOCL_SEGMNT11_KEY 
,GLP.LOCL_SEGMNT1_KEY||'.'||GLP.LOCL_SEGMNT2_KEY||'.'||GLP.LOCL_SEGMNT3_KEY||'.'||GLP.LOCL_SEGMNT4_KEY||'.'||GLP.LOCL_SEGMNT5_KEY||'.'||GLP.LOCL_SEGMNT6_KEY||'.'||GLP.LOCL_SEGMNT7_KEY||'.'||GLP.LOCL_SEGMNT8_KEY||'.'||GLP.LOCL_SEGMNT9_KEY||'.'||GLP.LOCL_SEGMNT10_KEY||'.'||GLP.LOCL_SEGMNT11_KEY||'.'||GLP.SET_OF_BOK_KEY||'.'||GLP.CURR_MAIN_KEY||'.'||GLP.TIM_MAIN_PERD_KEY||'.'||'1' AS LOCL_SEGMNT_KEY_DESC 
,GLP.SET_OF_BOK_KEY           AS SET_OF_BOK_KEY 
,GLP.CD_COMBN_KEY             AS CD_COMBN_KEY 
,'5'		 	              AS BALNC_TYP_KEY_FINAL 
,GLP.CURR_MAIN_KEY            AS CURR_MAIN_KEY 
,GLP.TIM_MAIN_PERD_KEY        AS TIM_MAIN_PERD_KEY 
,GLP.PERIOD_NET_DR_AMT        AS PERIOD_NET_DR_AMT 
,GLP.PERIOD_NET_CR_AMT        AS PERIOD_NET_CR_AMT 
,GLP.BEGIN_BALANCE_DR_AMT     AS BEGIN_BALANCE_DR_AMT 
,GLP.BEGIN_BALANCE_CR_AMT     AS BEGIN_BALANCE_CR_AMT 
,GLP.PERIOD_NET_DR_BEQ_AMT    AS PERIOD_NET_DR_BEQ_AMT 
,GLP.PERIOD_NET_CR_BEQ_AMT    AS PERIOD_NET_CR_BEQ_AMT 
,GLP.BEGIN_BALANCE_DR_BEQ_AMT AS BEGIN_BALANCE_DR_BEQ_AMT 
,GLP.BEGIN_BALANCE_CR_BEQ_AMT AS BEGIN_BALANCE_CR_BEQ_AMT 
,GLP.YTD_BALNC_DR_AMT         AS YTD_BALNC_DR_AMT 
,GLP.YTD_BALNC_CR_AMT         AS YTD_BALNC_CR_AMT 
,0.00                         AS OP_RT 
,0.00                         AS OP_PERD_NET_DR_AMT 
,0.00                         AS OP_PERD_NET_CR_AMT 
,0.00                         AS OP_YTD_BALNC_DR_AMT 
,0.00                         AS OP_YTD_BALNC_CR_AMT 
,GLP.ENTITY_STATS_FLAG        AS ENTITY_STATS_FLAG 
,GLP.TRANSLTD_FLAG            AS TRANSLTD_FLAG 
,CASE WHEN gl_ledgers.ledger_id IS NOT NULL THEN gl_ledgers.ledger_category_code ELSE 'PRIMARY' END AS LEDGR_CATGRY_CD_FINAL
,CASE 
     WHEN GLP.SET_OF_BOK_KEY IN ( '670', '3057' ) THEN 'M'
     WHEN sub.BALNC_FLTR_KEY2 IS NOT NULL AND sub.BALNC_FLTR_KEY1 IS NOT NULL AND LEDGR_CATGRY_CD_FINAL in ('PRIMARY','ALC','LOCAL') THEN 'Y'
	 WHEN LEDGR_CATGRY_CD_FINAL  = 'SECONDARY' OR SUBSTRING(LOCL_SEGMNT1_KEY_FINAL,5,6)='80' THEN 'N' 
	 ELSE 'N' 
	 END AS ESB_FLAG 
,CASE 
     WHEN (GLP.LOCL_SEGMNT1_KEY LIKE '%80' OR LOCL_SEGMNT1_KEY ='9081') THEN 'S' 
	 WHEN LEDGR_CATGRY_CD_FINAL  = 'SECONDARY' OR SUBSTRING(LOCL_SEGMNT1_KEY_FINAL,5,6)='80' THEN 'S'
	 ELSE 'N' 
	 END AS STAT_FLAG  
--,'N'		                  AS ESB_FLAG 
--,'N'		                  AS STAT_FLAG 
,NULL		                  AS ATRBT_1 
,NULL                         AS ATRBT_2 
,NULL                         AS ATRBT_3 
,NULL                         AS ATRBT_4 
,NULL                         AS ATRBT_5 
,GLP.PERD_ID                  AS PERD_ID 
,1	                          AS LOAD_ID_FINAL 
,GLP.CD_COMBN_KEY||'~'||GLP.SET_OF_BOK_KEY||'~'||GLP.CURR_MAIN_KEY||'~'||BALNC_TYP_KEY_FINAL||'~'||GLP.PERD_ID||'~'||LOAD_ID_FINAL||'~'||'GLPROD'||'~'||
        CASE 
  		WHEN GLP.TRANSLTD_FLAG='R' THEN 'TRANS-OTHERS'
  		WHEN GLP.TRANSLTD_FLAG IS NULL THEN 'STAT-COMP'
		ELSE 'OTHERS' END AS SRC_SYS_ID 
,GLP.SRC_CRETN_ID             AS SRC_CRETN_ID 
,GLP.SRC_CRETN_TS             AS SRC_CRETN_TS 
,GLP.SRC_UPD_ID               AS SRC_UPD_ID 
,GLP.SRC_UPD_TS               AS SRC_UPD_TS 
,GLP.DAT_ORGN                 AS DAT_ORGN 
,GLP.POSTNG_AGNT              AS POSTNG_AGNT 
,GLP.SRC_NAM                  AS SRC_NAM 
,GLP.TGT_POSTNG_TS            AS TGT_POSTNG_TS 
,GLP.TGT_UPD_TS               AS TGT_UPD_TS
,'LB_'||GLP.LOCL_SEGMNT1_KEY AS ES_SEGMNT1_KEY
,'AC_'||GLP.LOCL_SEGMNT2_KEY AS ES_SEGMNT2_KEY
,'TP_'||GLP.LOCL_SEGMNT3_KEY AS ES_SEGMNT3_KEY
,'CC_'||GLP.LOCL_SEGMNT4_KEY AS ES_SEGMNT4_KEY
,'GO_'||GLP.LOCL_SEGMNT5_KEY AS ES_SEGMNT5_KEY
,'PR_'||GLP.LOCL_SEGMNT6_KEY AS ES_SEGMNT6_KEY
,'RF_'||GLP.LOCL_SEGMNT7_KEY AS ES_SEGMNT7_KEY
,'PL_'||GLP.LOCL_SEGMNT8_KEY AS ES_SEGMNT8_KEY
,'BT_'||GLP.LOCL_SEGMNT9_KEY AS ES_SEGMNT9_KEY
,'FU_'||GLP.LOCL_SEGMNT10_KEY AS ES_SEGMNT10_KEY
,'FU_'||GLP.LOCL_SEGMNT11_KEY AS ES_SEGMNT11_KEY
,'GLPROD'                     AS SOURCE_NAME
--,'PRIMARY'                    AS LEDGR_CATGRY_CD
FROM   GL_GLP_STAT_TEMP GLP
LEFT JOIN $GLPROD_EXT_DB.gl_ledgers  gl_ledgers
ON GLP.SET_OF_BOK_KEY = gl_ledgers.ledger_id
LEFT JOIN BALNC_FLTR sub
ON GLP.SET_OF_BOK_KEY=sub.BALNC_FLTR_KEY2
AND GLP.LOCL_SEGMNT1_KEY=sub.BALNC_FLTR_KEY1
--AND GLP.LEDGR_CATGRY_CD in ('PRIMARY','ALC','LOCAL')
WHERE (GLP.TRANSLTD_FLAG IS NULL OR GLP.TRANSLTD_FLAG ='R');

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 12
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 12 Executed Successfully **** \n'
\endif

INSERT INTO $STGDB.GL_GLP_STAT_COA_BALNC_S 
            (
              LOCL_SEGMNT1_KEY 
             ,LOCL_SEGMNT2_KEY 
             ,LOCL_SEGMNT3_KEY 
             ,LOCL_SEGMNT4_KEY 
             ,LOCL_SEGMNT5_KEY 
             ,LOCL_SEGMNT6_KEY 
             ,LOCL_SEGMNT7_KEY 
             ,LOCL_SEGMNT8_KEY 
             ,LOCL_SEGMNT9_KEY 
             ,LOCL_SEGMNT10_KEY 
             ,LOCL_SEGMNT11_KEY 
             ,LOCL_SEGMNT_KEY 
             ,LOCL_SEGMNT_KEY_DESC 
             ,ICP_KEY 
             ,ICP_MAP_KEY 
             ,ICP_ALT_MAP_KEY 
             ,SET_OF_BOK_KEY 
             ,CD_COMBN_KEY 
             ,BALNC_TYP_KEY 
             ,LOCL_CURR_MAIN_KEY 
             ,TRANS_CURR_MAIN_KEY 
             ,TIM_MAIN_PERD_KEY 
             ,PART_NAM 
             ,FC_PERD_NET_DR_AMT 
             ,FC_PERD_NET_CR_AMT 
             ,FC_PERD_NET_SRC_DR_AMT 
             ,FC_PERD_NET_SRC_CR_AMT 
             ,FC_YTD_BALNC_DR_AMT 
             ,FC_YTD_BALNC_CR_AMT 
             ,FC_YTD_BALNC_NET_AMT 
             ,MOR_RT 
             ,PREV_YR_MOR_RT 
             ,MOR_PERD_NET_DR_AMT 
             ,MOR_PERD_NET_CR_AMT 
             ,MOR_YTD_BALNC_DR_AMT 
             ,MOR_YTD_BALNC_CR_AMT 
             ,GAP_RT 
             ,PREV_YR_GAP_RT 
             ,GAP_PERD_NET_DR_AMT 
             ,GAP_PERD_NET_CR_AMT 
             ,GAP_YTD_BALNC_DR_AMT 
             ,GAP_YTD_BALNC_CR_AMT 
             ,HIST_RT 
             ,PREV_YR_HIST_RT 
             ,HIST_AMT 
             ,FCTA_PERD_NET_DR_AMT 
             ,FCTA_PERD_NET_CR_AMT 
             ,FCTA_YTD_BALNC_DR_AMT 
             ,FCTA_YTD_BALNC_CR_AMT 
             ,APPLD_RT 
             ,PREV_YR_APPLD_RT 
             ,APPLD_PERD_NET_DR_AMT 
             ,APPLD_PERD_NET_CR_AMT 
             ,APPLD_YTD_BALNC_DR_AMT 
             ,APPLD_YTD_BALNC_CR_AMT 
             ,APPLD_FLAG 
             ,OP_RT 
             ,PREV_YR_OP_RT 
             ,OP_PERD_NET_DR_AMT 
             ,OP_PERD_NET_CR_AMT 
             ,OP_YTD_BALNC_DR_AMT 
             ,OP_YTD_BALNC_CR_AMT
             ,BEGIN_BALANCE_DR_AMT
             ,BEGIN_BALANCE_CR_AMT 
             ,TRANSLTD_FLAG 
             ,PERD_ID 
             ,FISCL_YEAR 
             ,FISCL_MONTH 
             ,LOAD_ID 
             ,CHANGE_SIGN 
             ,BALNC_DAT_TYP 
             ,ATRBT_1 
             ,ATRBT_2 
             ,ATRBT_3 
             ,ATRBT_4 
             ,ATRBT_5 
             ,SRC_SYS_ID 
             ,DATA_ORIGIN 
             ,POSTING_AGENT 
             ,SOURCE_NAME 
             ,SOURCE_CREATION_ID 
             ,SOURCE_CREATION_DTM 
             ,SOURCE_UPDATE_ID 
             ,SOURCE_UPDATE_DTM 
             ,LOAD_DTM 
             ,UPDATE_DTM
             ,ES_SEGMNT1_KEY 
             ,ES_SEGMNT2_KEY 
             ,ES_SEGMNT3_KEY 
             ,ES_SEGMNT4_KEY 
             ,ES_SEGMNT5_KEY 
             ,ES_SEGMNT6_KEY 
             ,ES_SEGMNT7_KEY 
             ,ES_SEGMNT8_KEY 
             ,ES_SEGMNT9_KEY 
             ,ES_SEGMNT10_KEY 
             ,ES_SEGMNT11_KEY 
             ,LEDGR_CATGRY_CD
			 ,LOCL_SEGMNT1_SYS_KEY
             ,LOCL_SEGMNT2_SYS_KEY
             ,LOCL_SEGMNT3_SYS_KEY
             ,LOCL_SEGMNT4_SYS_KEY
             ,LOCL_SEGMNT5_SYS_KEY
             ,LOCL_SEGMNT6_SYS_KEY
             ,LOCL_SEGMNT7_SYS_KEY
             ,LOCL_SEGMNT8_SYS_KEY
             ,LOCL_SEGMNT9_SYS_KEY
             ,LOCL_SEGMNT10_SYS_KEY
             ,LOCL_SEGMNT11_SYS_KEY
			 ,ES_SEGMNT1_SYS_KEY
             ,ES_SEGMNT2_SYS_KEY
             ,ES_SEGMNT3_SYS_KEY
             ,ES_SEGMNT4_SYS_KEY
             ,ES_SEGMNT5_SYS_KEY
             ,ES_SEGMNT6_SYS_KEY
             ,ES_SEGMNT7_SYS_KEY
             ,ES_SEGMNT8_SYS_KEY
             ,ES_SEGMNT9_SYS_KEY
             ,ES_SEGMNT10_SYS_KEY
             ,ES_SEGMNT11_SYS_KEY
             ,SET_OF_BOK_SYS_KEY
             ,LOCL_CURR_MAIN_SYS_KEY
             ,TRANS_CURR_MAIN_SYS_KEY
             ,TIM_MAIN_PERD_SYS_KEY
			 ,BALNC_TYP_DESC
			 ) 
SELECT 
        A.LOCL_SEGMNT1_KEY                        AS LOCL_SEGMNT1_KEY 
       ,A.LOCL_SEGMNT2_KEY                        AS LOCL_SEGMNT2_KEY 
       ,A.LOCL_SEGMNT3_KEY                        AS LOCL_SEGMNT3_KEY 
       ,A.LOCL_SEGMNT4_KEY                        AS LOCL_SEGMNT4_KEY 
       ,A.LOCL_SEGMNT5_KEY                        AS LOCL_SEGMNT5_KEY 
       ,A.LOCL_SEGMNT6_KEY                        AS LOCL_SEGMNT6_KEY 
       ,A.LOCL_SEGMNT7_KEY                        AS LOCL_SEGMNT7_KEY 
       ,A.LOCL_SEGMNT8_KEY                        AS LOCL_SEGMNT8_KEY 
       ,A.LOCL_SEGMNT9_KEY                        AS LOCL_SEGMNT9_KEY 
       ,A.LOCL_SEGMNT10_KEY                       AS LOCL_SEGMNT10_KEY 
       ,A.LOCL_SEGMNT11_KEY                       AS LOCL_SEGMNT11_KEY 
       ,A.LOCL_SEGMNT1_KEY||'.'||A.LOCL_SEGMNT2_KEY||'.'||A.LOCL_SEGMNT3_KEY||'.'||A.LOCL_SEGMNT4_KEY||'.'||A.LOCL_SEGMNT5_KEY||'.'||A.LOCL_SEGMNT6_KEY||'.'||A.LOCL_SEGMNT7_KEY||'.'||A.LOCL_SEGMNT8_KEY||'.'||A.LOCL_SEGMNT9_KEY ||'.'||A.LOCL_SEGMNT10_KEY||'.'||A.LOCL_SEGMNT11_KEY AS LOCL_SEGMNT_KEY 
       ,A.LOCL_SEGMNT_KEY_DESC                    AS LOCL_SEGMNT_KEY_DESC 
       ,'N/A'                                     AS ICP_KEY     
       ,'N/A'                                     AS ICP_MAP_KEY     
       ,'N/A'                                     AS ICP_ALT_MAP_KEY 
       ,A.SET_OF_BOK_KEY                          AS SET_OF_BOK_KEY 
       ,A.CD_COMBN_KEY                            AS CD_COMBN_KEY 
       ,A.BALNC_TYP_KEY	                          AS BALNC_TYP_KEY 
       ,A.CURR_MAIN_KEY                           AS LOCL_CURR_MAIN_KEY 
       ,A.CURR_MAIN_KEY                           AS TRANS_CURR_MAIN_KEY 
       ,A.TIM_MAIN_PERD_KEY                       AS TIM_MAIN_PERD_KEY 
       ,'N/A'                                     AS PART_NAM 
       ,A.PERIOD_NET_DR_AMT                       AS FC_PERD_NET_DR_AMT 
       ,A.PERIOD_NET_CR_AMT                       AS FC_PERD_NET_CR_AMT 
       ,A.PERIOD_NET_DR_AMT                       AS FC_PERD_NET_SRC_DR_AMT 
       ,A.PERIOD_NET_CR_AMT                       AS FC_PERD_NET_SRC_CR_AMT 
       ,A.YTD_BALNC_DR_AMT                        AS FC_YTD_BALNC_DR_AMT 
       ,A.YTD_BALNC_CR_AMT                        AS FC_YTD_BALNC_CR_AMT 
       ,(A.YTD_BALNC_DR_AMT - A.YTD_BALNC_CR_AMT) AS FC_YTD_BALNC_NET_AMT 
       ,CASE 
	         WHEN A.CURR_MAIN_KEY='USD' THEN 1
			 WHEN TEMP_2.TIM_MAIN_PERD_KEY IS NOT NULL AND TEMP_2.FROM_CURR_KEY IS NOT NULL THEN TEMP_2.CURR_CONV_RT 
			 ELSE 0.00 
	    END AS MOR_RT
	   --,0.00                                    AS MOR_RT 
       ,0.00                                    AS PREV_YR_MOR_RT 
       ,0.00                                    AS MOR_PERD_NET_DR_AMT 
       ,0.00                                    AS MOR_PERD_NET_CR_AMT 
       ,0.00                                    AS MOR_YTD_BALNC_DR_AMT 
       ,0.00                                    AS MOR_YTD_BALNC_CR_AMT 
       ,CASE 
	         WHEN A.CURR_MAIN_KEY='USD' THEN 1
			 WHEN TEMP_2.TIM_MAIN_PERD_KEY IS NOT NULL AND TEMP_3.FROM_CURR_KEY IS NOT NULL THEN TEMP_3.CURR_CONV_RT 
			 ELSE 0.00 
		END AS GAP_RT
	   --,0.00                                    AS GAP_RT 
       ,0.00                                    AS PREV_YR_GAP_RT 
       ,0.00                                    AS GAP_PERD_NET_DR_AMT 
       ,0.00                                    AS GAP_PERD_NET_CR_AMT 
       ,0.00                                    AS GAP_YTD_BALNC_DR_AMT 
       ,0.00                                    AS GAP_YTD_BALNC_CR_AMT 
       ,0.00                                    AS HIST_RT 
       ,0.00                                    AS PREV_YR_HIST_RT 
       ,0.00                                    AS HIST_AMT 
       ,0.00                                    AS FCTA_PERD_NET_DR_AMT 
       ,0.00                                    AS FCTA_PERD_NET_CR_AMT 
       ,0.00                                    AS FCTA_YTD_BALNC_DR_AMT 
       ,0.00                                    AS FCTA_YTD_BALNC_CR_AMT 
       ,0.00                                    AS APPLD_RT 
       ,0.00                                    AS PREV_YR_APPLD_RT 
       ,0.00                                    AS APPLD_PERD_NET_DR_AMT 
       ,0.00                                    AS APPLD_PERD_NET_CR_AMT 
       ,0.00                                    AS APPLD_YTD_BALNC_DR_AMT 
       ,0.00                                    AS APPLD_YTD_BALNC_CR_AMT 
       ,'N'                                     AS APPLD_FLAG 
       ,0.00                                    AS OP_RT 
       ,0.00                                    AS PREV_YR_OP_RT 
       ,0.00		                            AS OP_PERD_NET_DR_AMT 
       ,0.00		                            AS OP_PERD_NET_CR_AMT 
       ,0.00		                            AS OP_YTD_BALNC_DR_AMT 
       ,0.00		                            AS OP_YTD_BALNC_CR_AMT 
       ,0.00		                            AS BEGIN_BALANCE_DR_AMT
       ,0.00		                            AS BEGIN_BALANCE_CR_AMT
       ,A.TRANSLTD_FLAG                         AS TRANSLTD_FLAG 
       ,A.PERD_ID                               AS PERD_ID 
	   ,cast(SUBSTRING(TRIM(A.PERD_ID), 1, 4) as INTEGER) AS FISCL_YEAR
       ,cast(SUBSTRING(TRIM(A.PERD_ID), 5, 2) as INTEGER) AS FISCL_MONTH
       ,A.LOAD_ID                               AS LOAD_ID 
       ,1                                       AS CHANGE_SIGN 
       ,CASE 
  		WHEN A.TRANSLTD_FLAG='R' THEN 'TRANS-OTHERS'
  		WHEN A.TRANSLTD_FLAG IS NULL THEN 'STAT-COMP'
		ELSE 'OTHERS' END 	                    AS BALNC_DAT_TYP
       ,A.ATRBT_1                               AS ATRBT_1 
       ,A.ATRBT_2                               AS ATRBT_2 
       ,A.ATRBT_3                               AS ATRBT_3 
       ,A.ATRBT_4                               AS ATRBT_4 
       ,A.ATRBT_5                               AS ATRBT_5 
       ,A.SRC_SYS_ID                            AS SRC_SYS_ID 
       ,A.DAT_ORGN                              AS DAT_ORGN 
       ,'rsql_ctb_gl_glp_stat_coa_balnc_s.sh' AS POSTNG_AGNT 
       ,A.SOURCE_NAME                           AS SOURCE_NAME 
       ,-99999                                  AS SRC_CRETN_IDN 
       ,A.SRC_CRETN_TS                          AS SRC_CRETN_TS 
       ,-99999                                  AS SRC_UPD_IDN 
       ,A.SRC_UPD_TS                            AS SRC_UPD_TS 
       ,CURRENT_TIMESTAMP(0)                    AS TGT_POSTNG_TS 
       ,CURRENT_TIMESTAMP(0)                    AS TGT_UPD_TS 
       ,A.ES_SEGMNT1_KEY                        AS ES_SEGMNT1_KEY 
       ,A.ES_SEGMNT2_KEY                        AS ES_SEGMNT2_KEY 
       ,A.ES_SEGMNT3_KEY                        AS ES_SEGMNT3_KEY 
       ,A.ES_SEGMNT4_KEY                        AS ES_SEGMNT4_KEY 
       ,A.ES_SEGMNT5_KEY                        AS ES_SEGMNT5_KEY 
       ,A.ES_SEGMNT6_KEY                        AS ES_SEGMNT6_KEY 
       ,A.ES_SEGMNT7_KEY                        AS ES_SEGMNT7_KEY 
       ,A.ES_SEGMNT8_KEY                        AS ES_SEGMNT8_KEY 
       ,A.ES_SEGMNT9_KEY                        AS ES_SEGMNT9_KEY 
       ,A.ES_SEGMNT10_KEY                       AS ES_SEGMNT10_KEY 
       ,A.ES_SEGMNT11_KEY                       AS ES_SEGMNT11_KEY  
       ,COALESCE(LEDGR_CATGRY_CD,'PRIMARY')     AS LEDGR_CATGRY_CD
	    ,A.LOCL_SEGMNT1_KEY || '~' ||'GLPROD'|| '~' ||'ECA_CO' AS LOCL_SEGMNT1_SYS_KEY
        ,A.LOCL_SEGMNT2_KEY || '~' ||'GLPROD'|| '~' ||'ECA_AC' as LOCL_SEGMNT2_SYS_KEY
        ,A.LOCL_SEGMNT3_KEY || '~' ||'GLPROD'|| '~' ||'ECA_TP' AS LOCL_SEGMNT3_SYS_KEY
		,A.LOCL_SEGMNT4_KEY || '~' ||'GLPROD'|| '~' ||'ECA_CC' as LOCL_SEGMNT4_SYS_KEY
		,A.LOCL_SEGMNT5_KEY || '~' ||'GLPROD'|| '~' ||'ECA_GO' as LOCL_SEGMNT5_SYS_KEY
		,A.LOCL_SEGMNT6_KEY || '~' ||'GLPROD'|| '~' ||'ECA_PR' as LOCL_SEGMNT6_SYS_KEY
		,A.LOCL_SEGMNT7_KEY || '~' ||'GLPROD'|| '~' ||'ECA_RF' as LOCL_SEGMNT7_SYS_KEY
		,A.LOCL_SEGMNT8_KEY || '~' ||'GLPROD'|| '~' ||'ECA_PL' as LOCL_SEGMNT8_SYS_KEY
		,A.LOCL_SEGMNT9_KEY || '~' ||'GLPROD'|| '~' ||'ECA_BT' as LOCL_SEGMNT9_SYS_KEY
		,A.LOCL_SEGMNT10_KEY || '~' ||'GLPROD'|| '~' ||'ECA_FU1' as LOCL_SEGMNT10_SYS_KEY
		,A.LOCL_SEGMNT11_KEY || '~' ||'GLPROD'|| '~' ||'ECA_FU2' as LOCL_SEGMNT11_SYS_KEY
		,A.ES_SEGMNT1_KEY||'~'||'ECA'||'~'||'ECA_CO' as ES_SEGMNT1_SYS_KEY
        ,A.ES_SEGMNT2_KEY||'~'||'ECA'||'~'||'ECA_AC' as ES_SEGMNT2_SYS_KEY
        ,A.ES_SEGMNT3_KEY||'~'||'ECA'||'~'||'ECA_TP' as ES_SEGMNT3_SYS_KEY
        ,A.ES_SEGMNT4_KEY||'~'||'ECA'||'~'||'ECA_CC' as ES_SEGMNT4_SYS_KEY
        ,A.ES_SEGMNT5_KEY||'~'||'ECA'||'~'||'ECA_GO' as ES_SEGMNT5_SYS_KEY
        ,A.ES_SEGMNT6_KEY||'~'||'ECA'||'~'||'ECA_PR' as ES_SEGMNT6_SYS_KEY
        ,A.ES_SEGMNT7_KEY||'~'||'ECA'||'~'||'ECA_RF' as ES_SEGMNT7_SYS_KEY
        ,A.ES_SEGMNT8_KEY||'~'||'ECA'||'~'||'ECA_PL' as ES_SEGMNT8_SYS_KEY
        ,A.ES_SEGMNT9_KEY||'~'||'ECA'||'~'||'ECA_BT' as ES_SEGMNT9_SYS_KEY
        ,A.ES_SEGMNT10_KEY||'~'||'ECA'||'~'||'ECA_FU1' as ES_SEGMNT10_SYS_KEY
        ,A.ES_SEGMNT11_KEY||'~'||'ECA'||'~'||'ECA_FU2' as ES_SEGMNT11_SYS_KEY
        ,Case when A.SET_OF_BOK_KEY='-1' then '-99999'   else  A.SET_OF_BOK_KEY||'~'||'GLPROD' end AS SET_OF_BOK_SYS_KEY
		,Case when A.CURR_MAIN_KEY is Null then '-99999' else A.CURR_MAIN_KEY||'~'||A.source_name  end AS LOCL_CURR_MAIN_SYS_KEY
		,Case when A.CURR_MAIN_KEY is Null then '-99999' else A.CURR_MAIN_KEY||'~'||A.source_name  end AS TRANS_CURR_MAIN_SYS_KEY
		,A.PERD_ID ||'~'||'GEMS_CALENDAR'||'~'||'1'||'~'||'GLPROD' AS TIM_MAIN_PERD_SYS_KEY
		,'STAT' AS BALNC_TYP_DESC
		
FROM $STGDB.GL_GLP_ALL_BALNC_S  A

LEFT JOIN $CFD_DB.GCD_CURR_RT_HIST_F TEMP_2
ON A.TIM_MAIN_PERD_KEY=TEMP_2.TIM_MAIN_PERD_KEY
AND A.CURR_MAIN_KEY=TEMP_2.from_curr_key
AND TEMP_2.to_curr_key='USD'
AND TEMP_2.CURR_RT_TYP='Monthly'
AND TEMP_2.source_name = 'GLPROD'

LEFT JOIN $CFD_DB.GCD_CURR_RT_HIST_F TEMP_3
ON A.TIM_MAIN_PERD_KEY=TEMP_3.TIM_MAIN_PERD_KEY
AND A.CURR_MAIN_KEY=TEMP_3.from_curr_key
AND TEMP_3.to_curr_key='USD'
AND TEMP_3.CURR_RT_TYP='GAP'
AND TEMP_3.source_name = 'GLPROD'

WHERE A.ESB_FLAG='N'
AND (A.TRANSLTD_FLAG IS NULL OR A.TRANSLTD_FLAG ='R');


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 13
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 13 Executed Successfully **** \n'
\endif

UPDATE	$STGDB.GL_GLP_STAT_COA_BALNC_S
SET	
BEGIN_BALANCE_DR_AMT = HYP_PREV_END_BAL_DR,
BEGIN_BALANCE_CR_AMT = HYP_PREV_END_BAL_CR
FROM(
SELECT CURR.SRC_SYS_ID AS SRC_SYS_ID,
CURR.SOURCE_NAME AS SOURCE_NAME,
CURR.PERD_ID AS CURR_PERD_ID,
PREV.FC_YTD_BALNC_DR_AMT AS HYP_PREV_END_BAL_DR,
PREV.FC_YTD_BALNC_CR_AMT AS HYP_PREV_END_BAL_CR
FROM GL_COA_BALNC_F_VT PREV
JOIN (
SELECT SRC_SYS_ID,
CD_COMBN_KEY,
ES_SEGMNT1_KEY,
ES_SEGMNT2_KEY,
ES_SEGMNT3_KEY,
ES_SEGMNT4_KEY,
ES_SEGMNT5_KEY,
ES_SEGMNT6_KEY,
ES_SEGMNT7_KEY,
ES_SEGMNT8_KEY,
ES_SEGMNT9_KEY,
ES_SEGMNT10_KEY,
ES_SEGMNT11_KEY,
LEDGR_CATGRY_CD,
SET_OF_BOK_KEY,
FC_YTD_BALNC_DR_AMT,
FC_YTD_BALNC_CR_AMT,
FC_PERD_NET_SRC_DR_AMT,
FC_PERD_NET_SRC_CR_AMT,
LOCL_CURR_MAIN_KEY,
SOURCE_NAME,
PERD_ID,
TRANS_CURR_MAIN_KEY,
ATRBT_1,
TIM_MAIN_PERD_KEY,
BALNC_TYP_KEY
FROM $STGDB.GL_GLP_STAT_COA_BALNC_S
WHERE PERD_ID 
IN 
(
SELECT PERD_ID FROM $CFD_DB.TIM_MAIN_PERD_D TMPD
WHERE PERD_ID<=(SELECT PERD_ID FROM $CFD_DB.GL_COA_PERD_D)
AND PERD_ID/100 > (SELECT PERD_ID/100-3 FROM $CFD_DB.GL_COA_PERD_D)  
AND SOURCE_NAME = 'GLPROD'
)
AND  BALNC_TYP_KEY IN ('5')
AND  BALNC_DAT_TYP NOT IN ('ADJ' )) CURR 
ON PREV.CD_COMBN_KEY = CURR.CD_COMBN_KEY 
AND PREV.ES_SEGMNT1_KEY = CURR.ES_SEGMNT1_KEY 
AND PREV.ES_SEGMNT2_KEY = CURR.ES_SEGMNT2_KEY 
AND PREV.ES_SEGMNT3_KEY = CURR.ES_SEGMNT3_KEY 
AND PREV.ES_SEGMNT4_KEY = CURR.ES_SEGMNT4_KEY 
AND PREV.ES_SEGMNT5_KEY = CURR.ES_SEGMNT5_KEY 
AND PREV.ES_SEGMNT6_KEY = CURR.ES_SEGMNT6_KEY 
AND PREV.ES_SEGMNT7_KEY = CURR.ES_SEGMNT7_KEY 
AND PREV.ES_SEGMNT9_KEY = CURR.ES_SEGMNT9_KEY 
AND PREV.ES_SEGMNT10_KEY = CURR.ES_SEGMNT10_KEY 
AND PREV.ES_SEGMNT11_KEY = CURR.ES_SEGMNT11_KEY
--AND PREV.PERD_ID = CURR.PERD_ID-1
AND PREV.PERD_ID = CURR.PERD_ID - (CASE WHEN SUBSTRING(TRIM(CURR.PERD_ID),5,2)='01' THEN 89 ELSE 1 END)
AND PREV.SET_OF_BOK_KEY = CURR.SET_OF_BOK_KEY 
AND PREV.BALNC_TYP_KEY  = CURR.BALNC_TYP_KEY 
AND PREV.LOCL_CURR_MAIN_KEY = CURR.LOCL_CURR_MAIN_KEY 
AND PREV.SOURCE_NAME = CURR.SOURCE_NAME 
AND COALESCE(PREV.ATRBT_1, 'NA') = COALESCE(CURR.ATRBT_1,'NA') 
AND COALESCE(PREV.ES_SEGMNT8_KEY, 'NA') = COALESCE(CURR.ES_SEGMNT8_KEY, 'NA') 
AND COALESCE(PREV.TRANS_CURR_MAIN_KEY, 'N/A') = COALESCE(CURR.TRANS_CURR_MAIN_KEY, 'N/A') ) SUB
WHERE $STGDB.GL_GLP_STAT_COA_BALNC_S.SRC_SYS_ID = sub.SRC_SYS_ID
AND  $STGDB.GL_GLP_STAT_COA_BALNC_S.PERD_ID   = sub.CURR_PERD_ID
;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 14
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 14 Executed Successfully **** \n'
\endif

UPDATE $STGDB.GL_GLP_STAT_COA_BALNC_S
SET 
BEGIN_BALANCE_DR_AMT = FC_YTD_BALNC_DR_AMT - FC_PERD_NET_SRC_DR_AMT,
BEGIN_BALANCE_CR_AMT = FC_YTD_BALNC_CR_AMT - FC_PERD_NET_SRC_CR_AMT  
WHERE
TIM_MAIN_PERD_KEY LIKE '%JAN%'
AND PERD_ID
IN 
(
SELECT PERD_ID FROM $CFD_DB.TIM_MAIN_PERD_D TMPD
WHERE PERD_ID<=(SELECT PERD_ID FROM $CFD_DB.GL_COA_PERD_D)
AND PERD_ID/100 > (SELECT PERD_ID/100-3 FROM $CFD_DB.GL_COA_PERD_D)  
AND SOURCE_NAME = 'GLPROD'
)
;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 15
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement 15 Executed Successfully **** \n'
\endif

COMMIT;

END;

EOF

rsqlexitcode=$?

echo "Insertion Completed for STAT Balance"

echo "Exited with error code $rsqlexitcode"
echo "---------------------------------"

script_ended=$(date "+%F-%H-%M-%S")
echo "Script ended at --> $script_ended"

end=`date +%s`
exec=`expr $end - $start`
time_taken=`date -d@$exec -u +%H:%M:%S`

echo "Time Taken --> $time_taken"

python3 /ops/finance/common/scripts/send_sfn_token.py $token $script_name $rsqlexitcode $log_file_name

exit $rsqlexitcode