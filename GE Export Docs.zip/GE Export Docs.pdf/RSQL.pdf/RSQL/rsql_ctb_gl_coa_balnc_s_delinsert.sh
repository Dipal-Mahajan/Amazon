#-GE CONFIDENTIAL- or -GE HIGHLY CONFIDENTIAL-
#Type: Source Code
#Copyright (c) 2022, GE Healthcare
#All Rights Reserved
#This unpublished material is proprietary to GE Healthcare. The methods and
#techniques described herein are considered trade secrets and/or
#confidential. Reproduction or distribution, in whole or in part, is
#forbidden except by express written permission of GE Healthcare.


# <RSQL> SCRIPT NAME - rsql_ctb_gl_coa_balnc_s_delinsert.sh  </RSQL>
# <RSQL> SCRIPT DESCRIPTION - "Current RSQL is merging data to $TGTDB.GL_COA_BALNC_F from $STGDB.GL_COA_BALNC_S table as a part of Global Balance Flow "  </RSQL>
# <RSQL> PARAMETER FILE NAME - ctb_parameter.sh.sh </RSQL>
# <RSQL>  SOURCE SCHEMA - $STGDB  </RSQL>
# <RSQL>  SOURCE TABLE  - GL_COA_BALNC_S  </RSQL>
# <RSQL>  TARGET SCHEMA - $TGTDB  </RSQL>
# <RSQL>  TARGET TABLE  - GL_COA_BALNC_F </RSQL>
# <RSQL>  STMT TYPES    - DELETE , INSERT  </RSQL>
# <RSQL>  CREATED ON    - 16-OCT-2022  </RSQL>
# <RSQL>  CREATED BY    - healthfinance.odpctb@ge.com  </RSQL>
# <RSQL>  LAST MODIFIED ON    - 22-NOV-2022  </RSQL>
# <RSQL>  LAST MODIFIED BY    - healthfinance.odpctb@ge.com  </RSQL>


echo "Calling the CTB Parameter file --> ctb_parameter.sh"
source /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "Printing Content of Parameter File"
cat /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

if [ $# -eq 0 ]
  then
    echo "No arguments supplied , Please pass the parameter value in 0 and 1 , 0 for open_period , 1 for future_period"
    exit 1
fi

if [ $5 -gt 1 ]
  then
    echo "Please pass argument between 0 and 1, 0 for open_period , 1 for future_period"
    exit 1
fi


period_param=$5

echo "period_param from param --> " $period_param

echo "--------------------------------------------------------"

echo "                              "
echo "Current RSQL is merging data to $TGTDB.GL_COA_BALNC_F from $STGDB.GL_COA_BALNC_S table as a part of Global Balance Flow  "
echo "                              "

script_started=$(date "+%F-%H-%M-%S")
echo "Script Started at --> $script_started"

start=`date +%s`

#source /ops/finance/common/scripts/get_redshift_creds.sh 'odp-fin-nprod-ctb-fsso' 'us-east-1'
source /ops/finance/common/scripts/aws_run_profile.sh $1 $2 $3 $4

rsql -h $HOST -U $USER -d $DB << EOF
\timing true
BEGIN ;

/* Set the Query Band for the session */

\echo '\n ----Setting Query Band to $QBSTR--------- \n'
SET query_group to '$QBSTR';

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 1
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\echo '\n ----Setting Search Path to $STGDB--------- \n'

/* ******************************Setting Database************************************************* */
SET SEARCH_PATH TO $STGDB, pg_catalog;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 2
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\set period_param $period_param

\echo "period_param --> " :period_param

/* ******************************Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;************************************ */

\echo '\n ----Pulling value of Period from table $CFD_DB.GL_COA_PERD_D;--------- \n'

\if :period_param = 0
    \echo 'select perd_id  as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;'
      select perd_id as perd_id , curr_perd_key as open_period_final from $CFD_DB.GL_COA_PERD_D;
      \gset
    \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final

\elif :period_param = 1
    \echo 'SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;'
    SELECT future_perd_id as perd_id , future_period_key as open_period_final from $CFD_DB.GL_COA_PERD_D where future_perd_id is not null or future_perd_id != Null;
    \gset
    \echo "period_id --> " :perd_id
    \echo "open_period_final --> " :open_period_final
        \if :ACTIVITYCOUNT = 0
           \echo 'future period id future_perd_id is null so exiting gracefully'
           \exit 0
        \endif

\else
    \echo 'Period parameter not in 0 and 1 so exiting the statement'
    \echo 'Error Code -'
    \remark :LAST_ERROR_MESSAGE
    \exit 1

\endif


\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 3
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\set open_period '''':open_period_final''''

\echo "perd_id --> " :perd_id
\echo "open_period --> " :open_period

/* ******************************BTQ_FGL_120_DI_DWH_COA_BALNC_F.sh************************************ */

\echo '\n ----Migrating Bteq BTQ_FGL_120_DI_DWH_COA_BALNC_F.sh--------- \n'

/*

UPDATE $STGDB.GL_COA_BALNC_S
   SET FISCL_YEAR  = cast(SUBSTR(TRIM(:perd_id), 1, 4) as INTEGER),
       FISCL_MONTH = cast(SUBSTR(TRIM(:perd_id), 5, 2) as INTEGER);

*/

\echo '\n ----Deleting data from $TGTDB.GL_COA_BALNC_F on the basis of BALNC_TYP_KEY = 6 and current_period and data coming from stage table $STGDB.GL_COA_BALNC_S   \n'

DELETE FROM $TGTDB.GL_COA_BALNC_F
WHERE BALNC_DAT_TYP <> 'PLAN'  AND  PERD_ID = :perd_id AND BALNC_TYP_KEY = '6' and
(PERD_ID,SOURCE_NAME) IN
(SELECT PERD_ID, SOURCE_NAME FROM  $STGDB.GL_COA_BALNC_S  where BALNC_TYP_KEY = '6' AND PERD_ID = :perd_id GROUP BY 1,2);

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 4
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

\echo '\n ----Inserting data to $TGTDB.GL_COA_BALNC_F from stage table $STGDB.GL_COA_BALNC_S   \n'


INSERT INTO $TGTDB.GL_COA_BALNC_F
(
LOCL_SEGMNT1_SYS_KEY
,LOCL_SEGMNT2_SYS_KEY
,LOCL_SEGMNT3_SYS_KEY
,LOCL_SEGMNT4_SYS_KEY
,LOCL_SEGMNT5_SYS_KEY
,LOCL_SEGMNT6_SYS_KEY
,LOCL_SEGMNT7_SYS_KEY
,LOCL_SEGMNT8_SYS_KEY
,LOCL_SEGMNT9_SYS_KEY
,LOCL_SEGMNT10_SYS_KEY
,LOCL_SEGMNT11_SYS_KEY
,LOCL_SEGMNT1_KEY
,LOCL_SEGMNT2_KEY
,LOCL_SEGMNT3_KEY
,LOCL_SEGMNT4_KEY
,LOCL_SEGMNT5_KEY
,LOCL_SEGMNT6_KEY
,LOCL_SEGMNT7_KEY
,LOCL_SEGMNT8_KEY
,LOCL_SEGMNT9_KEY
,LOCL_SEGMNT10_KEY
,LOCL_SEGMNT11_KEY
,LOCL_SEGMNT_KEY
,LOCL_SEGMNT_KEY_DESC
,ES_SEGMNT1_SYS_KEY
,ES_SEGMNT2_SYS_KEY
,ES_SEGMNT3_SYS_KEY
,ES_SEGMNT4_SYS_KEY
,ES_SEGMNT5_SYS_KEY
,ES_SEGMNT6_SYS_KEY
,ES_SEGMNT7_SYS_KEY
,ES_SEGMNT8_SYS_KEY
,ES_SEGMNT9_SYS_KEY
,ES_SEGMNT10_SYS_KEY
,ES_SEGMNT11_SYS_KEY
,ES_SEGMNT1_KEY
,ES_SEGMNT2_KEY
,ES_SEGMNT3_KEY
,ES_SEGMNT4_KEY
,ES_SEGMNT5_KEY
,ES_SEGMNT6_KEY
,ES_SEGMNT7_KEY
,ES_SEGMNT8_KEY
,ES_SEGMNT9_KEY
,ES_SEGMNT10_KEY
,ES_SEGMNT11_KEY
,SET_OF_BOK_SYS_KEY
,LOCL_CURR_MAIN_SYS_KEY
,TRANS_CURR_MAIN_SYS_KEY
,TIM_MAIN_PERD_SYS_KEY
,SET_OF_BOK_KEY
,CD_COMBN_KEY
,BALNC_TYP_KEY
,LOCL_CURR_MAIN_KEY
,TRANS_CURR_MAIN_KEY
,TIM_MAIN_PERD_KEY
,FC_PERD_NET_DR_AMT
,FC_PERD_NET_CR_AMT
,FC_PERD_NET_SRC_DR_AMT
,FC_PERD_NET_SRC_CR_AMT
,FC_YTD_BALNC_DR_AMT
,FC_YTD_BALNC_CR_AMT
,FC_YTD_BALNC_NET_AMT
,MOR_RT
,MOR_PERD_NET_DR_AMT
,MOR_PERD_NET_CR_AMT
,MOR_YTD_BALNC_DR_AMT
,MOR_YTD_BALNC_CR_AMT
,MORFX_RT
,MORFX_PERD_NET_DR_AMT
,MORFX_PERD_NET_CR_AMT
,MORFX_YTD_BALNC_DR_AMT
,MORFX_YTD_BALNC_CR_AMT
,GAP_RT
,GAP_PERD_NET_DR_AMT
,GAP_PERD_NET_CR_AMT
,GAP_YTD_BALNC_DR_AMT
,GAP_YTD_BALNC_CR_AMT
,HIST_RT
,HIST_AMT
,FCTA_PERD_NET_DR_AMT
,FCTA_PERD_NET_CR_AMT
,FCTA_YTD_BALNC_DR_AMT
,FCTA_YTD_BALNC_CR_AMT
,APPLD_RT
,APPLD_PERD_NET_DR_AMT
,APPLD_PERD_NET_CR_AMT
,APPLD_YTD_BALNC_DR_AMT
,APPLD_YTD_BALNC_CR_AMT
,APPLD_FLAG
,OP_RT
,OP_PERD_NET_DR_AMT
,OP_PERD_NET_CR_AMT
,OP_YTD_BALNC_DR_AMT
,OP_YTD_BALNC_CR_AMT
,OPFX_CY_RT
,OPFX_CY_PERD_NET_DR_AMT
,OPFX_CY_PERD_NET_CR_AMT
,OPFX_CY_YTD_BALNC_DR_AMT
,OPFX_CY_YTD_BALNC_CR_AMT
,OPFX_FY_RT
,OPFX_FY_PERD_NET_DR_AMT
,OPFX_FY_PERD_NET_CR_AMT
,OPFX_FY_YTD_BALNC_DR_AMT
,OPFX_FY_YTD_BALNC_CR_AMT
,BEGIN_BALANCE_DR_AMT
,BEGIN_BALANCE_CR_AMT
,PREV_YR_MOR_RT
,PREV_YR_GAP_RT
,PREV_YR_HIST_RT
,PREV_YR_OP_RT
,PREV_YR_APPLD_RT
,TRANSLTD_FLAG
,PERD_ID
,FISCL_YEAR
,FISCL_MONTH
,LOAD_ID
,BALNC_DAT_TYP
,CHANGE_SIGN
,ATRBT_1
,ATRBT_2
,ATRBT_3
,ATRBT_4
,ATRBT_5
,ATRBT_6
,ATRBT_7
,ATRBT_8
,ATRBT_9
,ATRBT_10
,LEDGR_CATGRY_CD
,MEMO_FLD1
,MEMO_FLD2
,ICP_KEY
,ICP_MAP_KEY
,ICP_ALT_MAP_KEY
,PART_NAM
,BALNC_TYP_DESC
,SRC_SYS_ID
,SOURCE_NAME
,SOURCE_CREATION_ID
,SOURCE_CREATION_DTM
,SOURCE_UPDATE_ID
,SOURCE_UPDATE_DTM
,DATA_ORIGIN
,POSTING_AGENT
,LOAD_DTM
,UPDATE_DTM
,RECORD_FLAG )
select
LOCL_SEGMNT1_SYS_KEY
,LOCL_SEGMNT2_SYS_KEY
,LOCL_SEGMNT3_SYS_KEY
,LOCL_SEGMNT4_SYS_KEY
,LOCL_SEGMNT5_SYS_KEY
,LOCL_SEGMNT6_SYS_KEY
,LOCL_SEGMNT7_SYS_KEY
,LOCL_SEGMNT8_SYS_KEY
,LOCL_SEGMNT9_SYS_KEY
,LOCL_SEGMNT10_SYS_KEY
,LOCL_SEGMNT11_SYS_KEY
,LOCL_SEGMNT1_KEY
,LOCL_SEGMNT2_KEY
,LOCL_SEGMNT3_KEY
,LOCL_SEGMNT4_KEY
,LOCL_SEGMNT5_KEY
,LOCL_SEGMNT6_KEY
,LOCL_SEGMNT7_KEY
,LOCL_SEGMNT8_KEY
,LOCL_SEGMNT9_KEY
,LOCL_SEGMNT10_KEY
,LOCL_SEGMNT11_KEY
,LOCL_SEGMNT_KEY
,LOCL_SEGMNT_KEY_DESC
,ES_SEGMNT1_SYS_KEY
,ES_SEGMNT2_SYS_KEY
,ES_SEGMNT3_SYS_KEY
,ES_SEGMNT4_SYS_KEY
,ES_SEGMNT5_SYS_KEY
,ES_SEGMNT6_SYS_KEY
,ES_SEGMNT7_SYS_KEY
,ES_SEGMNT8_SYS_KEY
,ES_SEGMNT9_SYS_KEY
,ES_SEGMNT10_SYS_KEY
,ES_SEGMNT11_SYS_KEY
,ES_SEGMNT1_KEY
,ES_SEGMNT2_KEY
,ES_SEGMNT3_KEY
,ES_SEGMNT4_KEY
,ES_SEGMNT5_KEY
,ES_SEGMNT6_KEY
,ES_SEGMNT7_KEY
,ES_SEGMNT8_KEY
,ES_SEGMNT9_KEY
,ES_SEGMNT10_KEY
,ES_SEGMNT11_KEY
,SET_OF_BOK_SYS_KEY
,LOCL_CURR_MAIN_SYS_KEY
,TRANS_CURR_MAIN_SYS_KEY
,TIM_MAIN_PERD_SYS_KEY
,SET_OF_BOK_KEY
,CD_COMBN_KEY
,BALNC_TYP_KEY
,LOCL_CURR_MAIN_KEY
,TRANS_CURR_MAIN_KEY
,TIM_MAIN_PERD_KEY
,FC_PERD_NET_DR_AMT
,FC_PERD_NET_CR_AMT
,FC_PERD_NET_SRC_DR_AMT
,FC_PERD_NET_SRC_CR_AMT
,FC_YTD_BALNC_DR_AMT
,FC_YTD_BALNC_CR_AMT
,FC_YTD_BALNC_NET_AMT
,MOR_RT
,MOR_PERD_NET_DR_AMT
,MOR_PERD_NET_CR_AMT
,MOR_YTD_BALNC_DR_AMT
,MOR_YTD_BALNC_CR_AMT
,MORFX_RT
,MORFX_PERD_NET_DR_AMT
,MORFX_PERD_NET_CR_AMT
,MORFX_YTD_BALNC_DR_AMT
,MORFX_YTD_BALNC_CR_AMT
,GAP_RT
,GAP_PERD_NET_DR_AMT
,GAP_PERD_NET_CR_AMT
,GAP_YTD_BALNC_DR_AMT
,GAP_YTD_BALNC_CR_AMT
,HIST_RT
,HIST_AMT
,FCTA_PERD_NET_DR_AMT
,FCTA_PERD_NET_CR_AMT
,FCTA_YTD_BALNC_DR_AMT
,FCTA_YTD_BALNC_CR_AMT
,APPLD_RT
,APPLD_PERD_NET_DR_AMT
,APPLD_PERD_NET_CR_AMT
,APPLD_YTD_BALNC_DR_AMT
,APPLD_YTD_BALNC_CR_AMT
,APPLD_FLAG
,OP_RT
,OP_PERD_NET_DR_AMT
,OP_PERD_NET_CR_AMT
,OP_YTD_BALNC_DR_AMT
,OP_YTD_BALNC_CR_AMT
,OPFX_CY_RT
,OPFX_CY_PERD_NET_DR_AMT
,OPFX_CY_PERD_NET_CR_AMT
,OPFX_CY_YTD_BALNC_DR_AMT
,OPFX_CY_YTD_BALNC_CR_AMT
,OPFX_FY_RT
,OPFX_FY_PERD_NET_DR_AMT
,OPFX_FY_PERD_NET_CR_AMT
,OPFX_FY_YTD_BALNC_DR_AMT
,OPFX_FY_YTD_BALNC_CR_AMT
,BEGIN_BALANCE_DR_AMT
,BEGIN_BALANCE_CR_AMT
,PREV_YR_MOR_RT
,PREV_YR_GAP_RT
,PREV_YR_HIST_RT
,PREV_YR_OP_RT
,PREV_YR_APPLD_RT
,TRANSLTD_FLAG
,PERD_ID
,FISCL_YEAR
,FISCL_MONTH
,LOAD_ID
,BALNC_DAT_TYP
,CHANGE_SIGN
,ATRBT_1
,ATRBT_2
,ATRBT_3
,ATRBT_4
,ATRBT_5
,ATRBT_6
,ATRBT_7
,ATRBT_8
,ATRBT_9
,ATRBT_10
,LEDGR_CATGRY_CD
,MEMO_FLD1
,MEMO_FLD2
,ICP_KEY
,ICP_MAP_KEY
,ICP_ALT_MAP_KEY
,PART_NAM
,BALNC_TYP_DESC
,SRC_SYS_ID
,SOURCE_NAME
,SOURCE_CREATION_ID
,SOURCE_CREATION_DTM
,SOURCE_UPDATE_ID
,SOURCE_UPDATE_DTM
,DATA_ORIGIN
,'rsql_ctb_gl_coa_balnc_s_delinsert.sh' as POSTING_AGENT
,LOAD_DTM
,UPDATE_DTM
,RECORD_FLAG
FROM $STGDB.GL_COA_BALNC_S;

\if :ERROR <> 0
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 5
\else
 \echo :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

COMMIT;

END;

EOF

rsqlexitcode=$?

echo "Final Merge is completed for Global Balance"

echo "Exited with error code $rsqlexitcode"
echo "---------------------------------"

script_ended=$(date "+%F-%H-%M-%S")
echo "Script ended at --> $script_ended"

end=`date +%s`
exec=`expr $end - $start`
time_taken=`date -d@$exec -u +%H:%M:%S`

echo "Time Taken --> $time_taken"

python3 /ops/finance/common/scripts/send_sfn_token.py $token $script_name $rsqlexitcode $log_file_name

exit $rsqlexitcode