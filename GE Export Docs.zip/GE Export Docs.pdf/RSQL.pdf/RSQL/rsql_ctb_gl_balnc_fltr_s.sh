#-GE CONFIDENTIAL- or -GE HIGHLY CONFIDENTIAL-
#Type: Source Code
#Copyright (c) 2022, GE Healthcare
#All Rights Reserved
#This unpublished material is proprietary to GE Healthcare. The methods and
#techniques described herein are considered trade secrets and/or
#confidential. Reproduction or distribution, in whole or in part, is
#forbidden except by express written permission of GE Healthcare.


# <RSQL> SCRIPT NAME - rsql_ctb_gl_balnc_fltr_s.sh  </RSQL>
# <RSQL> SCRIPT DESCRIPTION - "Current RSQL is inserting data to $STGDB.gl_balnc_fltr_s from $CFD_DB.gl_coa_segmnt1_d table as a part of Balance Filter Flow"  </RSQL>
# <RSQL> PARAMETER FILE NAME - ctb_parameter.sh.sh </RSQL>
# <RSQL>  SOURCE SCHEMA - $CFD_DB  </RSQL>
# <RSQL>  SOURCE TABLE  - gl_coa_segmnt1_d  </RSQL>
# <RSQL>  TARGET SCHEMA - $STGDB  </RSQL>
# <RSQL>  TARGET TABLE  - gl_balnc_fltr_s </RSQL>
# <RSQL>  STMT TYPES    - DELETE , INSERT</RSQL>
# <RSQL>  CREATED ON    - 16-OCT-2022  </RSQL>
# <RSQL>  CREATED BY    - healthfinance.odpctb@ge.com  </RSQL>
# <RSQL>  LAST MODIFIED ON    - 22-NOV-2022  </RSQL>
# <RSQL>  LAST MODIFIED BY    - healthfinance.odpctb@ge.com  </RSQL>


echo "Calling the CTB Parameter file --> ctb_parameter.sh"
source /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "Printing Content of Parameter File"
cat /ops/finance/applications/ctb/rsql/scripts/ctb_parameter.sh

echo "--------------------------------------------------------"


echo "                              "
echo "Current RSQL is inserting data to $STGDB.gl_balnc_fltr_s from $CFD_DB.gl_coa_segmnt1_d table as a part of Balance Filter Flow" 
echo "                              "

script_started=$(date "+%F-%H-%M-%S")
echo "Script Started at --> $script_started"

start=`date +%s`

#source /ops/finance/common/scripts/get_redshift_creds.sh 'odp-fin-nprod-ctb-fsso' 'us-east-1'
source /ops/finance/common/scripts/aws_run_profile.sh $1 $2 $3 $4

rsql -h $HOST -U $USER -d $DB << EOF
\timing true

BEGIN ;

/* Set the Query Band for the session */

\echo '\n ----Setting Query Band to $QBSTR--------- \n'
SET query_group to '$QBSTR';


\if :ERROR <> 0
 \echo 'Setting Query Group to $OBSTR failed '
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 1
\else
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


\echo '\n ----Setting Search Path to $STGDB--------- \n'


/* ******************************Setting Database************************************************* */
SET SEARCH_PATH TO $STGDB, pg_catalog;



\if :ERROR <> 0
 \echo 'Setting Search Path to $STGDB failed '
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 2
\else
 \remark '\n **** Statement Executed Successfully **** \n'
\endif


/* ------------------------------ Deleting Data for ECA Source----------------------------------------------------------- */

\echo '\n ----Deleting data from table $STGDB.gl_balnc_fltr_s for ECA source--------- \n'
DELETE FROM $STGDB.gl_balnc_fltr_s
    WHERE source_name = 'ECA';

\if :ERROR <> 0
 \echo 'Deletion of data failed '
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 3
\else
 \echo Rows Affected --> :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

commit ;


/* ------------------------------ INSERT INTO $STGDB.GL_BALNC_FLTR_S----------------------------------------------------------- */

\echo '\n --- Inserting data to $STGDB.gl_balnc_fltr_s table --------- \n'

INSERT into $STGDB.gl_balnc_fltr_s (
  balnc_fltr_key1
, balnc_fltr_key2
, balnc_fltr_key3
, balnc_fltr_key4
, balnc_fltr_key5
, balnc_fltr_typ
, atrbt_1
, atrbt_2
, atrbt_3
, atrbt_4
, atrbt_5
, src_sys_id
, SOURCE_CREATION_ID
, SOURCE_CREATION_DTM
, SOURCE_UPDATE_ID
, SOURCE_UPDATE_DTM
, DATA_ORIGIN
, POSTING_AGENT
, SOURCE_NAME
, LOAD_DTM
, UPDATE_DTM
, RECORD_FLAG)
with recursive parse_list (locl_segmnt1_key, delim_pos, item_num, element, remainder , source_name )
as (
select
  SUBSTRING(segmnt_k1_key, 4) as locl_segmnt1_key
  , 0
  , 0
  , cast ('' as character varying(100))
  , primry_ledgr_id
  , source_name
from $CFD_DB.gl_coa_segmnt1_d
where UPPER(SOURCE_NAME) = 'ECA'
group by locl_segmnt1_key, primry_ledgr_id , source_name

union all

select
    locl_segmnt1_key
        , case
        when position('|' in remainder) > 0 then position('|' in remainder)
            else CHARACTER_LENGTH(remainder)
        end as dpos
        , item_num + 1
        , BTRIM(SUBSTRING(remainder, 0, dpos + 1), '|')
        , BTRIM(SUBSTRING(remainder, dpos + 1))
        , source_name
from parse_list
where dpos > 0)
select
    locl_segmnt1_key
        , element
        , null
        , null
        , null
        , 'ENTITY-LEDGR'
        , 'ES-HFM'
        , null
        , null
        , null
        , null
        , BTRIM(locl_segmnt1_key, ' ') || '~' || BTRIM(element, ' ') || '~' || source_name
        , '-99999'
        , current_timestamp(0)
        , '-99999'
        , current_timestamp(0)
        , 'GL_COA_SEGMNT1_D'
        , 'rsql_ctb_gl_balnc_fltr_s.sh'
        , 'ECA'
        , current_timestamp(0)
        , current_timestamp(0)
        , '0'
from parse_list as p
where item_num > 0;


\if :ERROR <> 0
 \echo 'Insertion in table $STGDB.gl_balnc_fltr_s failed'
 \echo 'Error Code -'
 \echo :ERRORCODE
 \remark :LAST_ERROR_MESSAGE
 \exit 4
\else
 \echo Rows Affected --> :ACTIVITYCOUNT
 \remark '\n **** Statement Executed Successfully **** \n'
\endif

commit;

end;

EOF

rsqlexitcode=$?

echo "Insertion Completed for Balance Filter"

echo "Exited with error code $rsqlexitcode"
echo "---------------------------------"

script_ended=$(date "+%F-%H-%M-%S")
echo "Script ended at --> $script_ended"

end=`date +%s`
exec=`expr $end - $start`
time_taken=`date -d@$exec -u +%H:%M:%S`

echo "Time Taken --> $time_taken"

python3 /ops/finance/common/scripts/send_sfn_token.py $token $script_name $rsqlexitcode $log_file_name

exit $rsqlexitcode

