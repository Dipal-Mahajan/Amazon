import redshift_connector
import os

with open('Credentials','r') as fp10:
    print("\n----------------------------------------------\n")
    credentials_input=fp10.read()
    print(credentials_input)

    input_file=credentials_input.split(',')
    host=input_file[0]
    print("host -->" + host)

    port=input_file[1]
    print("port -->" + port)

    database=input_file[2]
    print("database -->" + database)

    user=input_file[3]
    print("user -->" + user)

    password=input_file[4]
    print("password -->" + password)

    print("\n----------------------------------------------\n")

# Connect to Redshift
conn = redshift_connector.connect(host=host, database=database, user=user, password=password)
cursor = conn.cursor()

# Create a cursor
cursor = conn.cursor()

with open("table_list","r") as fp:
    for line in fp:
        line_input=line.split(".")
        print("\n----------------------------------------------\n")
        print("-----------------------------")
        print("line-->"+ line)
        print("-----------------------------")
        line_input=line.split(',')
        print("\n----------------------------------------------\n")
        orig_schema_name=line_input[0].strip().lower()
        print("orig_schema_name --> " + orig_schema_name)
        orig_table_name=line_input[1].strip().lower()
        print("orig_table_name --> " + orig_table_name)
        new_schema_name=line_input[2].strip().lower()
        print("new_schema_name --> " + new_schema_name)
        new_table_name=line_input[3].strip().lower()
        print("new_table_name --> " + new_table_name)


        p_etl_from_timestamp = '2020-01-01 17:49:29'
        p_etl_to_timestamp = '2030-01-01 17:49:29'

        # SQL query to execute
        query = "call udprdsftorchestration.execute_sql_from_table('" + f'{new_schema_name}'+ "','" + f'{new_table_name}'+ "','" +  f'{p_etl_from_timestamp}' + "','" +   f'{p_etl_to_timestamp}'  +   "');"


        # Execute the query
        try:
            cursor.execute(query)
            print("Query --> " + query )
        except Exception as e:
	        print("Error running the query -->  " + f'{query}' )
	        print(e)
	        print("---------------------------")
        finally:
	        conn.commit()

        view_schema='udprdsftvrtl'
        filename=new_schema_name + "." + f'{new_table_name}' +".sql"

        if os.path.exists('.//SP_File//' + filename):
            os.remove('.//SP_File//' + filename)
            print("The file " +  filename + " has been deleted successfully")
        else:
            print("The file " + filename + " does not exist!")

        # Print the results
        with open(".//SP_File//" + filename,"w") as file:

            file.write(str(query) )


 # Close the cursor and connection
cursor.close()
conn.close()