import redshift_connector

with open('Credentials','r') as fp10:
    print("\n----------------------------------------------\n")
    credentials_input=fp10.read()
    print(credentials_input)

    input_file=credentials_input.split(',')
    host=input_file[0]
    print("host -->" + host)

    port=input_file[1]
    print("port -->" + port)

    database=input_file[2]
    print("database -->" + database)

    user=input_file[3]
    print("user -->" + user)

    password=input_file[4]
    print("password -->" + password)

    print("\n----------------------------------------------\n")

# Connect to Redshift
conn = redshift_connector.connect(host=host, database=database, user=user, password=password)
cursor = conn.cursor()

# Create a cursor
cursor = conn.cursor()

with open("table_list","r") as fp:
    for line in fp:
        line_input=line.split(",")
        print("\n----------------------------------------------\n")
        orig_schema_name=line_input[0].strip().lower()
        print("orig_schema_name --> " + orig_schema_name)
        orig_table_name=line_input[1].strip().lower()
        print("orig_table_name --> " + orig_table_name)
        new_schema_name=line_input[2].strip().lower()
        print("new_schema_name --> " + new_schema_name)
        new_table_name=line_input[3].strip().lower()
        print("new_table_name --> " + new_table_name)
        table_primary_key=line_input[4].strip().lower()
        print("table_primary_key --> " + table_primary_key)
        #sql_string=line_input[4].strip().lower()

        # SQL query to execute
        query = "SELECT column_name FROM information_schema.columns WHERE table_name = '" + f'{orig_table_name}'+ "' AND table_schema = '" + f'{orig_schema_name}'+ "';"
        #drop_statement="drop table if exists " + f'{orig_table_name}' + "_staging;"
        #print("Drop temporary table --> " + drop_statement )
        create_statement="Create temporary table " + "tmp_" + f'{orig_table_name}' + " as select * from " + f'{orig_schema_name}' + '.' + f'{orig_table_name}' + " where (dml_operation_type is null or dml_operation_type in (''INSERT'',''UPDATE'')) and ((target_transaction_timestamp >= ''p_etl_from_timestamp'' and target_transaction_timestamp <= ''p_etl_to_timestamp'') or  (etl_update_timestamp >= ''p_etl_from_timestamp'' and etl_update_timestamp <= ''p_etl_to_timestamp''));"
        print("Create temporary table --> " + create_statement )
        # Execute the query
        try:
            cursor.execute(query)
        except Exception as e:
	        print("Error running the query -->  " + f'{query}' )
	        print(e)
	        print("---------------------------")
        finally:
	        conn.commit()

        # Fetch all the results
        results = cursor.fetchall()

        filename=f'{new_schema_name}' + "." + f'{new_table_name}' +"_transformation.sql"
        # Print the results
        with open('.//MERGE_SQLS//' + filename ,'w') as file:
            column_list=''
            update_column_list=''
            insert_column_list=''

            for row in results:
                print("row --> "+row[0])

                if row[0] in ('target_transaction_timestamp','source_transaction_timestamp','dml_operation_type','etl_update_timestamp'):
                    print("Column name is target_transaction_timestamp need not to add  ")
                else:
                    column_list=row[0]+','+column_list
                    if  row[0] == table_primary_key :
                        print("Columns is primary key , need not to add in primary key --> " + row[0])
                    else:
                        update_column_list=row[0] + " = src." + row[0] + ',' +update_column_list


                    insert_column_list="src." + row[0] + ',' + insert_column_list

            print("row_updated --> "+column_list[:-1])
            print("update_column_list --> " + update_column_list[:-1])
            print("insert_column_list --> " + insert_column_list[:-1])

            #row_updated=str(row_updated)+","+str(row_updated)
            #print(str(row_updated))
            merge_transformation="Merge into " + f'{new_schema_name}' + '.' + f'{new_table_name}' + " USING " + "tmp_" + f'{orig_table_name}' + " src ON " + f'{new_schema_name}' + '.' + f'{new_table_name}' + "." + f'{table_primary_key}' + "= src." + f'{table_primary_key}' + " WHEN MATCHED THEN UPDATE SET " + update_column_list[:-1] + ",target_processing_timestamp = CURRENT_TIMESTAMP  WHEN NOT MATCHED THEN INSERT (" + column_list[:-1] + ",target_processing_timestamp) VALUES (" +  insert_column_list[:-1] + ",CURRENT_TIMESTAMP);"
            print("Merge Transformation --> " + merge_transformation)

            #drop_query = "Insert into udprdsftetl.udp_job_config_sqls values('" + f'{new_schema_name}' + "','" + f'{new_table_name}' + "'," + "1,'" +  f'{drop_statement}' + "');"
            insert_query = "Insert into udprdsftorchestration.udp_job_config_sqls values('" + f'{new_schema_name}' + "','" + f'{new_table_name}' + "'," + "1,'" +  f'{create_statement}' + "');"
            merge_query = "Insert into udprdsftorchestration.udp_job_config_sqls values('" + f'{new_schema_name}' + "','" + f'{new_table_name}' + "'," + "2,'" +  f'{merge_transformation}' + "');"
            #print("drop_query ---> " + drop_query)
            print("insert_query ---> " + insert_query)
            print("merge_query ---> " + merge_query)

            try:
                #cursor.execute(drop_query)
                cursor.execute(insert_query)
                cursor.execute(merge_query)
                #print("Nothing to execute")
            except Exception as e:
	            print("Error running the query -->  " + f'{new_schema_name}' + "." + f'{new_table_name}')
	            print(e)
	            print("---------------------------")
            finally:
	            conn.commit()

            #final_output = drop_statement + "\n" + create_statement + "\n" + merge_transformation
            final_output = create_statement + "\n" + merge_transformation
            #view_def="Create or replace view " + f'{view_schema}'  + "." + f'{table_name}'  + " as select " + row_updated[:-1] + " from " + f'{schema_name}'  + "." + f'{table_name}'";"
            file.write(final_output)

 # Close the cursor and connection
cursor.close()
conn.close()