import redshift_connector
import os

with open('Credentials','r') as fp10:
    print("\n----------------------------------------------\n")
    credentials_input=fp10.read()
    print(credentials_input)

    input_file=credentials_input.split(',')
    host=input_file[0]
    print("host -->" + host)

    port=input_file[1]
    print("port -->" + port)

    database=input_file[2]
    print("database -->" + database)

    user=input_file[3]
    print("user -->" + user)

    password=input_file[4]
    print("password -->" + password)

    print("\n----------------------------------------------\n")

# Connect to Redshift
conn = redshift_connector.connect(host=host, database=database, user=user, password=password)
cursor = conn.cursor()

# Create a cursor
cursor = conn.cursor()

with open("table_list","r") as fp:
    for line in fp:
        line_input=line.split(".")
        print("\n----------------------------------------------\n")
        print("-----------------------------")
        print("line-->"+ line)
        print("-----------------------------")
        line_input=line.split(',')
        print("\n----------------------------------------------\n")
        orig_schema_name=line_input[0].strip().lower()
        print("orig_schema_name --> " + orig_schema_name)
        orig_table_name=line_input[1].strip().lower()
        print("orig_table_name --> " + orig_table_name)
        new_schema_name=line_input[2].strip().lower()
        print("new_schema_name --> " + new_schema_name)
        new_table_name=line_input[3].strip().lower()
        print("new_table_name --> " + new_table_name)


        # SQL query to execute
        query = "SELECT column_name FROM information_schema.columns WHERE table_name = '" + f'{new_table_name}'+ "' AND table_schema = '" + f'{new_schema_name}'+ "';"

        print(query)

        # Execute the query
        try:
            cursor.execute(query)
        except Exception as e:
	        print("Error running the query -->  " + f'{query}' )
	        print(e)
	        print("---------------------------")
        finally:
	        conn.commit()

        # Fetch all the results
        results = cursor.fetchall()

        view_schema='udprdsftvrtl'
        filename=view_schema + "." + f'{new_table_name}' +".sql"

        if os.path.exists('.//VIEWS//' + filename):
            os.remove('.//VIEWS//' + filename)
            print("The file " +  filename + " has been deleted successfully")
        else:
            print("The file " + filename + " does not exist!")

        # Print the results
        with open(".//VIEWS//" + filename,"w") as file:
            row_updated=''
            for row in results:
                #print("row --> "+row[0])

                row_updated=row[0]+','+row_updated
            #print("row_updated --> "+row_updated[:-1])

            #row_updated=str(row_updated)+","+str(row_updated)
            #print(str(row_updated))

            #drop_view = "drop view " + f'{view_schema}' + "." + f'{new_table_name}' + ";"
            view_def=" Create or replace view " + f'{view_schema}'  + "." + f'{new_table_name}'  + " as select " + row_updated[:-1] + " from " + f'{new_schema_name}'  + "." + f'{new_table_name}'" with no schema binding ;"
            print("View defination for table " + f'{view_schema}'  + "." + f'{new_table_name}' + str(view_def) )

            file.write(str(view_def) )

            try:
                cursor.execute(view_def)
            except Exception as e:
	            print("Error running the query -->  " + f'{view_def}' )
	            print(e)
	            print("---------------------------")
            finally:
	            conn.commit()

 # Close the cursor and connection
cursor.close()
conn.close()
