import redshift_connector
import os
import re

redshift_connector.paramstyle = 'qmark'

with open('Credentials','r') as fp10:
    credentials_input=fp10.read()
    print(credentials_input)

    input_file=credentials_input.split(',')
    hostname=input_file[0]
    print("hostname -->" + hostname)

    database=input_file[1]
    print("database -->" + database)

    user=input_file[2]
    print("user -->" + user)

    password=input_file[3]
    print("password -->" + password)

    audit_table=input_file[4].replace("\n","")
    print("audit_table -->" + audit_table)


#conn = redshift_connector.connect(host='us-innovation-redshift.c8ziwm1qxh67.us-east-1.redshift.amazonaws.com', database='usinnovationredshift', user='502855676', password='&cRWB?+K?X9Da8g')
conn = redshift_connector.connect(host=hostname, database=database, user=user, password=password)
cursor = conn.cursor()

with open("table_names.txt","r") as fp:
    for line in fp:
        #print(line)
        table_name=line.rstrip()
        #print(table_name)
        table_name_file=line.rstrip() +".sql"
        #print(table_name_file)
        
        if os.path.exists('.//Redshift_DDLS//' + table_name_file):
            os.remove('.//Redshift_DDLS//' + table_name_file)
            print("The file " +  table_name_file + " has been deleted successfully")
        else:
            print("The file " + table_name_file + " does not exist!")
        
        with open(".//Redshift_DDLS//" + table_name_file,"w") as fp2:

            error_query = "show  table " + table_name + ";"

            try:
                cursor.execute(error_query)
            except Exception as e:
                print("Error executing the SELECT sql")
                print(e)
                print('')
                #cursor.execute(error_query)
                #print(err)
            finally: 
                #output_final = ''
                output=cursor.fetchall()
                analyzing_table = "\n \nANALYZE " + table_name + " ;\n\n"
                output_recovery_backup = " \n \nInsert into " + table_name + " select * from " + table_name + "_collation_backup ; \n \n "
                output_drop_backup = "Drop table if exists " + table_name +"_collation_backup ; \n\n"
                output_backup = "Create table " + table_name +"_collation_backup as Select * from "+ table_name + " ; \n \n"
                output_final = output_drop_backup + output_backup +"Drop table " + table_name + "; \n \n" + str(output) + output_recovery_backup + analyzing_table
                #print(output_final)
                #for item in output:
                #    output_final+=' ' + item

                    #output_final=convertTuple(output[item])
                print('\n--------Done---------\n')
                    
       
            fp2.write(str(output_final).replace("(['","").replace("'],)","").replace("\\n","\n"))
    cursor.close()   
    conn.close() 


from Collation import check_collation 