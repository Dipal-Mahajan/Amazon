Drop table if exists HDL_CMN_DATA.CFD_PSI_D_COLLATION_TESTING_collation_backup ; 

Create table HDL_CMN_DATA.CFD_PSI_D_COLLATION_TESTING_collation_backup as Select * from HDL_CMN_DATA.CFD_PSI_D_COLLATION_TESTING ; 
 
Drop table HDL_CMN_DATA.CFD_PSI_D_COLLATION_TESTING; 
 
CREATE TABLE hdl_cmn_data.cfd_psi_d_collation_testing (
    psi_code character varying(300) ENCODE lzo collate case_insensitive ,
    psi_short_name character varying(50) ENCODE lzo collate case_insensitive ,
    psi_long_name character varying(50) ENCODE lzo collate case_insensitive ,
    modality character varying(300) ENCODE lzo collate case_insensitive ,
    modality_desc character varying(300) ENCODE lzo collate case_insensitive ,
    parent_modality1 character varying(300) ENCODE lzo collate case_insensitive ,
    parent_modality1_desc character varying(300) ENCODE lzo collate case_insensitive ,
    parent_modality2 character varying(300) ENCODE lzo collate case_insensitive ,
    parent_modality2_desc character varying(300) ENCODE lzo collate case_insensitive ,
    parent_modality3 character varying(300) ENCODE lzo collate case_insensitive ,
    parent_modality3_desc character varying(300) ENCODE lzo collate case_insensitive ,
    psi_group character varying(300) ENCODE lzo collate case_insensitive ,
    psi_family_group character varying(100) ENCODE lzo collate case_insensitive ,
    psi_family character varying(100) ENCODE lzo collate case_insensitive ,
    es_segmnt8_sys_key character varying(250) ENCODE lzo collate case_insensitive ,
    es_segmnt8_key character varying(50) ENCODE lzo collate case_insensitive ,
    op_psi_nam character varying(250) ENCODE lzo collate case_insensitive ,
    op_segmnt character varying(250) ENCODE lzo collate case_insensitive ,
    src_sys_id character varying(750) ENCODE lzo collate case_insensitive ,
    data_origin character varying(750) ENCODE lzo collate case_insensitive ,
    posting_agent character varying(250) ENCODE lzo collate case_insensitive ,
    source_name character varying(300) ENCODE lzo collate case_insensitive ,
    source_creation_id character varying(250) ENCODE lzo collate case_insensitive ,
    source_creation_dtm timestamp without time zone ENCODE az64,
    source_update_id character varying(250) ENCODE lzo collate case_insensitive ,
    source_update_dtm timestamp without time zone ENCODE az64,
    load_dtm timestamp without time zone ENCODE az64,
    update_dtm timestamp without time zone ENCODE az64,
    source_creation_sys_key character varying(250) ENCODE lzo collate case_insensitive ,
    source_update_sys_key character varying(250) ENCODE lzo collate case_insensitive ,
    record_flag character varying(100) ENCODE lzo collate case_insensitive 
)
DISTSTYLE AUTO; 
 
Insert into HDL_CMN_DATA.CFD_PSI_D_COLLATION_TESTING select * from HDL_CMN_DATA.CFD_PSI_D_COLLATION_TESTING_collation_backup ; 
 
ANALYZE HDL_CMN_DATA.CFD_PSI_D_COLLATION_TESTING ;

