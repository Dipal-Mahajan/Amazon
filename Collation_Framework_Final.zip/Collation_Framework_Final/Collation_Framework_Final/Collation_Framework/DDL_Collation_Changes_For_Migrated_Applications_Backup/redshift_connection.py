import redshift_connector
import os
import re
import datetime
import pytz

start_time = datetime.datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")
start_time_testing = datetime.datetime.now(pytz.utc)

print ("\n-----Initial Process Started at --> " + start_time + "-----\n")

redshift_connector.paramstyle = 'qmark'

with open('Credentials','r') as fp10:
    credentials_input=fp10.read()

    print("----------------------------------------------")
    print("credentials_input --> " + credentials_input)

    input_file=credentials_input.split(',')
    hostname=input_file[0]
    print("hostname -->" + hostname)

    database=input_file[1]
    print("database -->" + database)

    user=input_file[2]
    print("user -->" + user)

    password=input_file[3]
    print("password -->" + password)

    audit_table=input_file[4].replace("\n","")
    print("audit_table -->" + audit_table)

    print("----------------------------------------------")

if os.path.exists("table_backup.txt"):
    os.remove("table_backup.txt")
    print("The file table_backup.txt has been deleted successfully")
else:
    print("The file table_backup.txt does not exist!")

with open("table_backup.txt","w") as fp2:

    with open("table_names.txt","r") as fp:
        for line in fp:
            
            print("-----------------------------------")

            print("line --> " + line)
            line_split=line.split(",")
            application_name = line_split[1]
            print("application_name -->" + application_name)
            table_name=line_split[0].rstrip().upper()
            print("table_name --> " + table_name)
            table_name_file=line.rstrip() +".sql"
            print("table_name_file --> " + table_name_file)

            print("-----------------------------------")
            
            table_backup="table_backup.txt"
            
            drop_table = "Drop table if exists "+ f'{table_name}'  + "_initial_backup_collation  Cascade;"
            output_table = "Create table " + f'{table_name}'  + "_initial_backup_collation as select * from " + f'{table_name}'  + " ;"
            #count_table = "Insert into " + f'{audit_table}' + "_BACKUP( application_name , table_name , row_count , CREATE_DTM) select '"+ f'{application_name}'  +"' as application_name , table_name , row_count , CURRENT_TIMESTAMP(0) as CREATE_DTM from (select '" + f'{table_name}'  + "_initial_backup_collation' as table_name , count(*) as row_count from " + f'{table_name}'  + "_initial_backup_collation) a ;"
            #count_table = "Insert into " + f'{audit_table}' + "_BACKUP( application_name , table_name , row_count , start_time , end_time ) select '"+ f'{application_name}'  +"' as application_name , table_name , row_count , '" + f'{start_time}'  + "' as start_time , CURRENT_TIMESTAMP(0) as end_time from (select '" + f'{table_name}'  + "_initial_backup_collation' as table_name , count(*) as row_count from " + f'{table_name}'  + "_initial_backup_collation) a ;"
            
            #count_table = "Insert into " + f'{audit_table}' + "_BACKUP( application_name , source_table_name , backup_table_name, source_row_count , backup_row_count , count_difference,  start_time , end_time ) SELECT '" + f'{application_name}'  + "' as application_name ,'" + f'{table_name}'  + "' as source_table_name , '" + f'{table_name}'  + "_initial_backup_collation' as backup_table_name, MAX(ROW_COUNT) AS SOURCE_ROW_COUNT ,MIN(ROW_COUNT) AS BACKUP_ROW_COUNT ,(MAX(ROW_COUNT) - MIN(ROW_COUNT)) AS count_difference ,'" + f'{start_time}' + "' as start_time ,  CURRENT_TIMESTAMP(0) AS end_time FROM ( SELECT '" + f'{table_name}' +  "' , ROW_COUNT FROM (select COUNT(*) AS ROW_COUNT FROM " + table_name + " UNION ALL SELECT COUNT(*) AS ROW_COUNT FROM " + table_name  + "_initial_backup_collation) ) GROUP BY 1; \n "
            count_table = "Insert into " + f'{audit_table}' + "_BACKUP( application_name , source_table_name , backup_table_name, source_row_count , backup_row_count , count_difference,  start_time , end_time ) SELECT '" + f'{application_name}'  + "' as application_name ,'" + f'{table_name}'  + "' as source_table_name , '" + f'{table_name}'  + "_initial_backup_collation' as backup_table_name, MAX(ROW_COUNT) AS SOURCE_ROW_COUNT ,MIN(ROW_COUNT) AS BACKUP_ROW_COUNT ,(MAX(ROW_COUNT) - MIN(ROW_COUNT)) AS count_difference ,filler_replacement_collation as start_time ,  CURRENT_TIMESTAMP(0) AS end_time FROM ( SELECT '" + f'{table_name}' +  "' , ROW_COUNT FROM (select COUNT(*) AS ROW_COUNT FROM " + table_name + " UNION ALL SELECT COUNT(*) AS ROW_COUNT FROM " + table_name  + "_initial_backup_collation) ) GROUP BY 1; \n "
            

            output_final = drop_table + "\n " + output_table + "\n" + count_table + "\n"

            print("Created record -->" + output_final)
            print('\n--------------------Done-----------------------------\n')
            
            fp2.write(output_final)