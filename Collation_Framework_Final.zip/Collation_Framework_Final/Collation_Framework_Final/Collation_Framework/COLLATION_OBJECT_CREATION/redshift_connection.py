import redshift_connector
import os
import re
import datetime 
import time
import pytz

now = datetime.datetime.now(pytz.utc)
print ("\n-----Processing Started at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "-----\n")

redshift_connector.paramstyle = 'qmark'

with open('Credentials','r') as fp10:
    print("\n----------------------------------------------\n")
    credentials_input=fp10.read()
    print(credentials_input)

    input_file=credentials_input.split(',')
    hostname=input_file[0]
    print("hostname -->" + hostname)

    database=input_file[1]
    print("database -->" + database)

    user=input_file[2]
    print("user -->" + user)

    password=input_file[3]
    print("password -->" + password)

    audit_table=input_file[4].replace("\n","")
    print("audit_table -->" + audit_table)

    print("\n----------------------------------------------\n")


#conn = redshift_connector.connect(host='us-innovation-redshift.c8ziwm1qxh67.us-east-1.redshift.amazonaws.com', database='usinnovationredshift', user='502855676', password='&cRWB?+K?X9Da8g')
conn = redshift_connector.connect(host=hostname, database=database, user=user, password=password)
cursor = conn.cursor()

print("-------------------------------------------------")

print("Starting deleting the files inside VIEWS folder")

mydir="VIEWS/"
filelist = [ f for f in os.listdir(mydir) if f.endswith(".sql") ]
for f in filelist:
    print("filename --> " + f)
    os.remove(os.path.join(mydir, f))

print("Deletion completed for VIEW folder")

print("Starting deleting the files inside VIEWS folder")

mydir="VIEWS_UPDATED/"
filelist = [ f for f in os.listdir(mydir) if f.endswith(".sql") ]
for f in filelist:
    print("filename --> " + f)
    os.remove(os.path.join(mydir, f))

print("Deletion completed for VIEWS_UPDATED folder")

print("-------------------------------------------------")


with open("table_names.txt","r") as fp:
    for line in fp:
        #print(line)
        line_input=line.split(",")
        print("\n----------------------------------------------\n")
        application_name=line_input[1].strip().upper()
        print("application_name --> " + application_name)
        table_name=line_input[0].rstrip().upper()
        print("table_name --> " + table_name)
        table_name_file=line_input[0].rstrip() +".sql"
        print("table_name_file --> " + table_name_file)
        print("\n----------------------------------------------\n")
        
        if os.path.exists('.//VIEWS//' + table_name_file):
            os.remove('.//VIEWS//' + table_name_file)
            print("The file " +  table_name_file + " has been deleted successfully")
        else:
            print("The file " + table_name_file + " does not exist!")
        
        with open(".//VIEWS//" + table_name_file,"w") as fp2:

            #error_query = "select * from HDL_CMN_STAGE.OBJECT_DEPENDENCY where UPPER(definition) like '%"+ f'{table_name}'  + "%' and UPPER(schemaname) in ('HDL_CMN_VIEW');"
            #error_query = "select * from pg_views where UPPER(definition) like '%"+ f'{table_name}'  + "%';"
            error_query = "select application_name , base_table_name , view_definition from " + f'{audit_table}' + "_DEPENDENT_VIEWS where UPPER(base_table_name) = '"+ f'{table_name}'  + "';"
            print(error_query)
            try:
                cursor.execute(error_query)
            except Exception as e:
                print("Error executing the SELECT sql")
                print(e)
                print('')
                #cursor.execute(error_query)
                #print(err)
            finally: 
                output=cursor.fetchall()
                output_final=str(output).replace("]","\n    ").replace("([","").replace(", [","").replace("'","").replace("    )","").replace("    ,)","").replace('"','').replace("()","")
                fp2.write(str(output_final))
                    
       

    cursor.close()   
    conn.close() 


from view_creation import view_creation 
