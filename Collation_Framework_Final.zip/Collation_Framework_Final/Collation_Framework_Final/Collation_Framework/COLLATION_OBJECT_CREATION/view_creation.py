def view_creation():

    file_list = fnmatch.filter(os.listdir('.//VIEWS'), '*.sql')
    #Below is the the string to add at column level if it's not present
    #string_to_add = ' collate case_insensitive '
    #print("String to add -->" + string_to_add)
    print("\n")
    print("---------------Processing Started---------------")
    for sql_file in file_list:
        print("\n")
        print("Processing file : ", sql_file)
        sql_file_name = sql_file.split('.')
        sql_file_new_name = sql_file_name[0]  + '.' + sql_file_name[1] + '_converted_view.' + sql_file_name[2]
        with open('.//VIEWS_UPDATED//' + sql_file_new_name ,'w') as fp2:
            with open('.//VIEWS//' + sql_file) as fp:
                for line in fp:
                    print("-----------------------------")
                    print("line-->"+ line)
                    print("-----------------------------")
                    line_input=line.split(",")
                    print("\n----------------------------------------------\n")
                    application_name=line_input[0].strip().upper()
                    print("application_name --> "+ application_name)
                    original_table_name = line_input[1].strip().upper()
                    print("original_table_name --> "+ original_table_name)
                    sql_stmt_full=line_input[2:]
                    sql_stmt = str(sql_stmt_full)
                    print ("sql_stmt --> " + sql_stmt )
                    print("\n----------------------------------------------\n")
                    sql_final=str(sql_stmt).replace("'","").replace("\\n"," ").replace("[","").replace("]","").replace("\\r"," ").replace("\\"," ")

                    print("sql_final-->" + sql_final)
                    print("\n----------------------------------------------\n")

                    output_final = application_name + "," + original_table_name + "," + sql_final
                    print("output_final -->" + output_final)
                    print("\n----------------------------------------------\n")

                    #Writing output to new file to have original file safe
                    fp2.write(output_final.rstrip('\n') + "\n")

                fp2.close()
                #print("Conversion for file  --> " + sql_file + " is completed and converted filename is --> " + sql_file_new_name)

import os,fnmatch
import re
import datetime 

now = datetime.datetime.now()
print ("\n-----Processing Started at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "-----\n")

view_creation()