import redshift_connector
import os,fnmatch
import sqlparse
import pytz
import datetime 

initial_time = datetime.datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")

print ("\n-----Initial Process Started at --> " + initial_time + "-----\n")

import redshift_connection

now = datetime.datetime.now(pytz.utc)
print ("\n-----Processing Started at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "-----\n")

redshift_connector.paramstyle = 'qmark'

with open('Credentials','r') as fp10:
	print("----------------------------------------------")
	credentials_input=fp10.read()
	print(credentials_input)

	input_file=credentials_input.split(',')
	hostname=input_file[0]
	print("hostname -->" + hostname)

	database=input_file[1]
	print("database -->" + database)

	user=input_file[2]
	print("user -->" + user)

	password=input_file[3]
	print("password -->" + password)

	audit_table=input_file[4].replace("\n","")
	print("audit_table -->" + audit_table)

	print("----------------------------------------------")


#conn = redshift_connector.connect(host='us-innovation-redshift.c8ziwm1qxh67.us-east-1.redshift.amazonaws.com', database='usinnovationredshift', user='502855676', password='&cRWB?+K?X9Da8g')
conn = redshift_connector.connect(host=hostname, database=database, user=user, password=password)
cursor = conn.cursor()

truncate_table = "truncate table " + f'{audit_table}' + "_VIEW_SUCCESS_LOG;"

try:
	#cursor.execute(truncate_table)
	print("We are not truncating the table to save history of logs")
	#print("Execution completed for --> " + truncate_table)
except Exception as e:
	print("Error Executing the truncate table " + f'{audit_table}' + "_VIEW_SUCCESS_LOG")
	print(e)
	print("---------------------------")
finally:
	conn.commit()

print("----------------------------------------------")

truncate_table = "truncate table " + f'{audit_table}' + "_VIEW_ERROR_LOG;"

try:
	#cursor.execute(truncate_table)
	print("We are not truncating the table to save history of logs")
	#print("Execution completed for --> " + truncate_table)
except Exception as e:
	print("Error Executing the truncate table " + f'{audit_table}' + "_VIEW_ERROR_LOG")
	print(e)
	print("---------------------------")
finally:
	conn.commit()

print("----------------------------------------------")

file_list = fnmatch.filter(os.listdir('.//VIEWS_UPDATED'), '*.sql')

for sql_file in file_list:
	with open('.//VIEWS_UPDATED//' + sql_file ,'r') as fp:
		raw_sql_file = fp.read()
		sql_stmts = sqlparse.split(raw_sql_file)
		#print(sql_stmts)
		table_name=sql_file.split('.')
		table_name_value=table_name[0] + '.' + table_name[1]
		table_name_value=table_name_value.replace('_converted_view','')

		for stmt_final in sql_stmts:
			start_time = datetime.datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")
			start_time_testing = datetime.datetime.now(pytz.utc)

			stmt_output = stmt_final.split(",")

			application_name = stmt_output[0].strip().upper()
			original_base_table = stmt_output[1].strip().upper()
			print("original_base_table -->" + original_base_table)

			sql_stmt = stmt_output[2:]
			stmt = str(sql_stmt)\
			.replace("['","")\
			.replace("']","")\
			.replace("'","")\
			.replace("N::character varying","'N'::character varying")\
			.replace("N::bpchar","'N'::bpchar")\
			.replace("ORDER DATA-GLP","'ORDER DATA-GLP'")\
			.replace("INVOICE DATA -GLP","'INVOICE DATA -GLP'")\
			.replace("IB/ASSET DATA","'IB/ASSET DATA'")\
			.replace("AGREEMENT DATA","'AGREEMENT DATA'")
			stmt_insertion = str(sql_stmt).replace("['","").replace("']","").replace("'","")
			print("sql_stmt -->" + stmt)

			print("-------------------------------------------")
			print("\n---------Processing Started------------\n")
			now = datetime.datetime.now(pytz.utc)
			print ("\n----Processing Started for step at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "----\n")
			print("-------------------------------------------")
			print("Running Sql statement --> " + stmt)
			print("\n----------------------------------------------\n")
			try:
				end_time = datetime.datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")
				end_time_testing = datetime.datetime.now(pytz.utc)
				time_taken = end_time_testing - start_time_testing
				time_taken = str(time_taken).split('.')[0]
				print("time_taken -->" + time_taken)
				cursor.execute(stmt)
				#success_insertion = "Insert into " + f'{audit_table}' + "_VIEW_SUCCESS_LOG values('" + f'{application_name}' + "','" + f'{original_base_table}' + "','" + f'{stmt_insertion}' + "', CURRENT_TIMESTAMP(0));"
				success_insertion = "Insert into " + f'{audit_table}' + "_VIEW_SUCCESS_LOG values('" + f'{application_name}' + "','" + f'{original_base_table}' + "','" + f'{stmt_insertion}' + "','" + f'{start_time}' + "'  ,  CURRENT_TIMESTAMP(0) );"
				print("success_insertion --> " + success_insertion)
				print("\n----------------------------------------------\n")
				cursor.execute(success_insertion)			
			#except redshift_connector.error.ProgrammingError as e:
			except Exception as e:
				print("Error executing the SELECT sql")
				print(e)
				print('')
				conn.commit()
				#conn = redshift_connector.connect(host='us-innovation-redshift.c8ziwm1qxh67.us-east-1.redshift.amazonaws.com', database='usinnovationredshift', user='502855676', password='&cRWB?+K?X9Da8g')
				conn = redshift_connector.connect(host=hostname, database=database, user=user, password=password)

				cursor = conn.cursor()
				#with open("error_log.txt" ,'w') as fp3:
				#	fp3.write(stmt + "\n")
				#failure_insertion = "Insert into " + f'{audit_table}' + "_VIEW_ERROR_LOG values('" + f'{application_name}' + "','" + f'{original_base_table}' + "','" + f'{stmt_insertion}' + "' , CURRENT_TIMESTAMP(0));"
				failure_insertion = "Insert into " + f'{audit_table}' + "_VIEW_ERROR_LOG values('" + f'{application_name}' + "','" + f'{original_base_table}' + "','" + f'{stmt_insertion}' + "' , '" + f'{start_time}' + "' , CURRENT_TIMESTAMP(0) );"
				print("failure_insertion --> " + failure_insertion)
				print("\n----------------------------------------------\n")
				cursor.execute(failure_insertion)
				#cursor.execute(error_query)
				#print(err)
			finally: 
                #output_final = ''
				#print(cursor.fetchall())
				conn.commit()
				print("-------------------------------------------")
				print("Job Completed for --> " + stmt)
				print("-------------------------------------------")
				now = datetime.datetime.now(pytz.utc)
				print ("\n---Processing Completed for Step at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "-----\n")
		print('\n-----------Processing of ' + table_name_value + ' is Completed------------------\n')
cursor.close()
conn.close()

now = datetime.datetime.now(pytz.utc)
print ("\n-----Processing Completed at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "------\n")