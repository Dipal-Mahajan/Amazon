def check_collation():

    file_list = fnmatch.filter(os.listdir('.//Redshift_DDLS'), '*.sql')
    #Below is the the string to add at column level if it's not present
    string_to_add = ' collate case_insensitive '
    print("String to add -->" + string_to_add)
    print("\n")
    print("---------------Processing Started---------------")
    for sql_file in file_list:
        print("\n")
        print("Processing file : ", sql_file)
        sql_file_name = sql_file.split('.')
        sql_file_new_name = sql_file_name[0]  + '.' + sql_file_name[1] + '_converted.' + sql_file_name[2]
        print("sql_file_new_name --> " + sql_file_new_name)
        with open('.//Redshift_Updated_Files//' + sql_file_new_name ,'w') as fp2:
            with open('.//Redshift_DDLS//' + sql_file) as fp:
                for line in fp:
                    line=line.replace(' distkey','').replace('DISTSTYLE KEY','DISTSTYLE AUTO').replace('\\','')
                    if ("CHARACTER") in line.upper():
                        line=line.rstrip()
                        if not ("COLLATE") in line.upper():
                            text_to_find = line[-1:]
                            matching_pattern = ",;"
                            #print("text_to_find --> "+ text_to_find)
                            #print("matching_pattern --> "+ matching_pattern)
                            if text_to_find in matching_pattern:
                                #print("if condition --> " + line)
                                line = line[:-1] + string_to_add + line[-1:]
                                #print(line)
                            else:
                                #print("else condition -->" + line)
                                line = line + string_to_add

                    #Writing output to new file to have original file safe
                    fp2.write(line.rstrip('\n') + "\n")

                fp2.close()
                print("Conversion for file  --> " + sql_file + " is completed and converted filename is --> " + sql_file_new_name)

import os,fnmatch
import re

check_collation()