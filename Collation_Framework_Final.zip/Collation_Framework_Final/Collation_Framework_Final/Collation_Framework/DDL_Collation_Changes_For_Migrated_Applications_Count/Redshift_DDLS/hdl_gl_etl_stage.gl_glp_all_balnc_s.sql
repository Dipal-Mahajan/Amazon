Drop table if exists hdl_gl_etl_stage.gl_glp_all_balnc_s_collation_backup CASCADE; 

 ALTER TABLE hdl_gl_etl_stage.gl_glp_all_balnc_s rename to gl_glp_all_balnc_s_collation_backup ; 
 
 CREATE TABLE hdl_gl_etl_stage.gl_glp_all_balnc_s (
    locl_segmnt1_key character varying(100) ENCODE lzo,
    locl_segmnt2_key character varying(100) ENCODE lzo,
    locl_segmnt3_key character varying(100) ENCODE lzo,
    locl_segmnt4_key character varying(100) ENCODE lzo,
    locl_segmnt5_key character varying(100) ENCODE lzo,
    locl_segmnt6_key character varying(100) ENCODE lzo,
    locl_segmnt7_key character varying(100) ENCODE lzo,
    locl_segmnt8_key character varying(100) ENCODE lzo,
    locl_segmnt9_key character varying(100) ENCODE lzo,
    locl_segmnt10_key character varying(100) ENCODE lzo,
    locl_segmnt11_key character varying(100) ENCODE lzo,
    locl_segmnt_key_desc character varying(500) ENCODE lzo,
    set_of_bok_key character varying(50) ENCODE lzo,
    cd_combn_key character varying(250) ENCODE lzo,
    balnc_typ_key character varying(50) ENCODE lzo,
    curr_main_key character varying(50) ENCODE lzo,
    tim_main_perd_key character varying(10) ENCODE lzo,
    period_net_dr_amt numeric(38,10) ENCODE az64,
    period_net_cr_amt numeric(38,10) ENCODE az64,
    begin_balance_dr_amt numeric(38,10) ENCODE az64,
    begin_balance_cr_amt numeric(38,10) ENCODE az64,
    period_net_dr_beq_amt numeric(38,10) ENCODE az64,
    period_net_cr_beq_amt numeric(38,10) ENCODE az64,
    begin_balance_dr_beq_amt numeric(38,10) ENCODE az64,
    begin_balance_cr_beq_amt numeric(38,10) ENCODE az64,
    ytd_balnc_dr_amt numeric(38,10) ENCODE az64,
    ytd_balnc_cr_amt numeric(38,10) ENCODE az64,
    op_rt numeric(38,20) ENCODE az64,
    op_perd_net_dr_amt numeric(38,10) ENCODE az64,
    op_perd_net_cr_amt numeric(38,10) ENCODE az64,
    op_ytd_balnc_dr_amt numeric(38,10) ENCODE az64,
    op_ytd_balnc_cr_amt numeric(38,10) ENCODE az64,
    entity_stats_flag character varying(10) ENCODE lzo,
    transltd_flag character varying(10) ENCODE lzo,
    esb_flag character varying(10) ENCODE lzo,
    stat_flag character varying(10) ENCODE lzo,
    atrbt_1 character varying(100) ENCODE lzo,
    atrbt_2 character varying(100) ENCODE lzo,
    atrbt_3 character varying(100) ENCODE lzo,
    atrbt_4 character varying(100) ENCODE lzo,
    atrbt_5 character varying(100) ENCODE lzo,
    perd_id integer NOT NULL ENCODE az64,
    load_id integer ENCODE az64,
    src_sys_id character varying(250) NOT NULL ENCODE lzo,
    src_cretn_id character varying(50) ENCODE lzo,
    src_cretn_ts timestamp without time zone ENCODE az64,
    src_upd_id character varying(50) ENCODE lzo,
    src_upd_ts timestamp without time zone ENCODE az64,
    dat_orgn character varying(50) ENCODE lzo,
    postng_agnt character varying(50) ENCODE lzo,
    src_nam character varying(50) ENCODE lzo,
    tgt_postng_ts timestamp without time zone ENCODE az64,
    tgt_upd_ts timestamp without time zone ENCODE az64,
    es_segmnt1_key character varying(30) ENCODE lzo,
    es_segmnt2_key character varying(30) ENCODE lzo,
    es_segmnt3_key character varying(30) ENCODE lzo,
    es_segmnt4_key character varying(30) ENCODE lzo,
    es_segmnt5_key character varying(30) ENCODE lzo,
    es_segmnt6_key character varying(30) ENCODE lzo,
    es_segmnt7_key character varying(30) ENCODE lzo,
    es_segmnt8_key character varying(30) ENCODE lzo,
    es_segmnt9_key character varying(30) ENCODE lzo,
    es_segmnt10_key character varying(30) ENCODE lzo,
    es_segmnt11_key character varying(30) ENCODE lzo,
    ledgr_catgry_cd character varying(50) ENCODE lzo,
    source_name character varying(30) ENCODE lzo
)
DISTSTYLE EVEN;
  
Insert into hdl_gl_etl_stage.gl_glp_all_balnc_s select * from hdl_gl_etl_stage.gl_glp_all_balnc_s_collation_backup ; 
 
ANALYZE hdl_gl_etl_stage.gl_glp_all_balnc_s ;
 

Insert into HDL_GL_ETL_STAGE.CTB_AUDIT (application_name , source_table_name , target_table_name , SOURCE_ROW_COUNT , TARGET_ROW_COUNT , count_difference , start_time , end_time) SELECT 'CTB' as application_name ,'hdl_gl_etl_stage.gl_glp_all_balnc_s' as source_table_name , 'hdl_gl_etl_stage.gl_glp_all_balnc_s_collation_backup' as target_table_name, MAX(ROW_COUNT) AS SOURCE_ROW_COUNT ,MIN(ROW_COUNT) AS TARGET_ROW_COUNT ,(MAX(ROW_COUNT) - MIN(ROW_COUNT)) AS count_difference ,filler_replacement_collation as start_time ,  CURRENT_TIMESTAMP(0) AS end_time FROM ( SELECT 'hdl_gl_etl_stage.gl_glp_all_balnc_s' , ROW_COUNT FROM (select COUNT(*) AS ROW_COUNT FROM hdl_gl_etl_stage.gl_glp_all_balnc_s UNION ALL SELECT COUNT(*) AS ROW_COUNT FROM hdl_gl_etl_stage.gl_glp_all_balnc_s_collation_backup) ) GROUP BY 1; 
 