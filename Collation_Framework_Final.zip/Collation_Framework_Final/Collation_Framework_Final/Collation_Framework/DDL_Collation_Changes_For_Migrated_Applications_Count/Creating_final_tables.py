import redshift_connector
import os,fnmatch
import sqlparse
import redshift_connection
import datetime 
import pytz



now = datetime.datetime.now(pytz.utc)
print ("\n-----Processing Started at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "-----\n")

redshift_connector.paramstyle = 'qmark'

with open('Credentials','r') as fp10:
	credentials_input=fp10.read()
	print(credentials_input)

	input_file=credentials_input.split(',')
	hostname=input_file[0]
	print("hostname -->" + hostname)

	database=input_file[1]
	print("database -->" + database)

	user=input_file[2]
	print("user -->" + user)

	password=input_file[3]
	print("password -->" + password)

	audit_table=input_file[4].replace("\n","")
	print("audit_table -->" + audit_table)


#conn = redshift_connector.connect(host='us-innovation-redshift.c8ziwm1qxh67.us-east-1.redshift.amazonaws.com', database='usinnovationredshift', user='502855676', password='&cRWB?+K?X9Da8g')
conn = redshift_connector.connect(host=hostname, database=database, user=user, password=password)
cursor = conn.cursor()

truncate_table = "truncate table " + f'{audit_table}' + "_AUDIT;"

try:
	#cursor.execute(truncate_table)
	print("We are not truncating the table to save history of logs")
except Exception as e:
	print("Error Executing the truncate table " + f'{audit_table}' + "_AUDIT")
	print(e)
	print("---------------------------")
finally:
	conn.commit()

file_list = fnmatch.filter(os.listdir('.//Redshift_Updated_Files'), '*.sql')

for sql_file in file_list:
	with open('.//Redshift_Updated_Files//' + sql_file ,'r') as fp:
		start_time = datetime.datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")
		start_time_testing = datetime.datetime.now(pytz.utc)
		raw_sql_file = fp.read()
		sql_stmts = sqlparse.split(raw_sql_file)
		#print(sql_stmts)
		table_name=sql_file.split('.')
		table_name_value=table_name[0] + '.' + table_name[1]
		table_name_value=table_name_value.replace('_converted','')

		for stmt in sql_stmts:
			print("\n---------Processing Started------------\n")
			now = datetime.datetime.now(pytz.utc)
			print ("\n----Processing Started for step at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "----\n")
			print("Running Sql statement --> " + stmt)
			try:
				stmt=stmt.replace("filler_replacement_collation","'" + f'{start_time}' + "'")
				print("stmt_after_replacement_filler --> " + stmt)
				cursor.execute(stmt)			
			#except redshift_connector.error.ProgrammingError as e:
			except Exception as e:
				print("Error executing the SELECT sql")
				print(e)
				print('')
				#cursor.execute(error_query)
				#print(err)
			finally: 
                #output_final = ''
				#print(cursor.fetchall())
				conn.commit()
				
				print("Job Completed for --> " + stmt)
				now = datetime.datetime.now(pytz.utc)
				print ("\n---Processing Completed for Step at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "-----\n")
		print('\n-----------Processing of ' + table_name_value + ' is Completed------------------\n')
cursor.close()
conn.close()

now = datetime.datetime.now(pytz.utc)
print ("\n-----Processing Completed at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "------\n")