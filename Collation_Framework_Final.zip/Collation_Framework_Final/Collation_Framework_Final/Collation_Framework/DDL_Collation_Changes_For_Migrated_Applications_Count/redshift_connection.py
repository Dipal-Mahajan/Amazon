import redshift_connector
import os
import re
import pytz
import datetime

start_time = datetime.datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")
start_time_testing = datetime.datetime.now(pytz.utc)

print ("\n-----Initial Process Started at --> " + start_time + "-----\n")

redshift_connector.paramstyle = 'qmark'

with open('Credentials','r') as fp10:
    credentials_input=fp10.read()
    print(credentials_input)

    input_file=credentials_input.split(',')
    hostname=input_file[0]
    print("hostname -->" + hostname)

    database=input_file[1]
    print("database -->" + database)

    user=input_file[2]
    print("user -->" + user)

    password=input_file[3]
    print("password -->" + password)

    audit_table=input_file[4].replace("\n","")
    print("audit_table -->" + audit_table)


#conn = redshift_connector.connect(host='us-innovation-redshift.c8ziwm1qxh67.us-east-1.redshift.amazonaws.com', database='usinnovationredshift', user='502855676', password='&cRWB?+K?X9Da8g')
conn = redshift_connector.connect(host=hostname, database=database, user=user, password=password)
cursor = conn.cursor()

print("-------------------------------------------------")

print("Starting deleting the files inside Redshift_DDLS folder")

mydir="Redshift_DDLS/"
filelist = [ f for f in os.listdir(mydir) if f.endswith(".sql") ]
for f in filelist:
    print("filename --> " + f)
    os.remove(os.path.join(mydir, f))

print("Deletion completed for Redshift_DDLS folder")

print("Starting deleting the files inside VIEWS folder")

mydir="Redshift_Updated_Files/"
filelist = [ f for f in os.listdir(mydir) if f.endswith(".sql") ]
for f in filelist:
    print("filename --> " + f)
    os.remove(os.path.join(mydir, f))

print("Deletion completed for Redshift_Updated_Files folder")

print("-------------------------------------------------")


with open("table_names.txt","r") as fp:
    for line in fp:
        #print(line)
        line_input = line.split(",")
        application_name = line_input[1].strip().upper()
        table_name=line_input[0].rstrip()
        schema_name = table_name.split('.')[0]
        table_name_part = table_name.split('.')[1]
        #print(table_name)
        table_name_file=line_input[0].rstrip() +".sql"
        #print(table_name_file)
        
        if os.path.exists('.//Redshift_DDLS//' + table_name_file):
            os.remove('.//Redshift_DDLS//' + table_name_file)
            print("The file " +  table_name_file + " has been deleted successfully")
        else:
            print("The file " + table_name_file + " does not exist!")
        
        with open(".//Redshift_DDLS//" + table_name_file,"w") as fp2:

            error_query = "show  table " + table_name + ";"
            print("error_query --> " + error_query)

            try:
                cursor.execute(error_query)
            except Exception as e:
                print("Error executing the SELECT sql")
                print(e)
                print('')
                #cursor.execute(error_query)
                #print(err)
            finally: 
                #output_final = ''
                output=cursor.fetchall()
                search_path = " set search_path to " + schema_name  + "; \n"
                
                output_rename = "\n ALTER TABLE " + table_name + " rename to " + table_name_part + "_collation_backup ; \n \n "

                analyzing_table = "\nANALYZE " + table_name + " ;\n \n"
                
                output_recovery_backup = "  \nInsert into " + table_name + " select * from " + table_name + "_collation_backup ; \n "

                output_drop_backup = "Drop table if exists " + table_name +"_collation_backup CASCADE; \n"

                output_backup = "Create table " + table_name +"_collation_backup as Select * from "+ table_name + " ; \n \n"
                
                #output_validation = "\nInsert into " + f'{audit_table}' + "_AUDIT (application_name , source_table_name , target_table_name , SOURCE_ROW_COUNT , TARGET_ROW_COUNT , count_difference , CREATE_DTM) SELECT '" + f'{application_name}'  + "' as application_name ,'" + f'{table_name}'  + "' as source_table_name , '" + f'{table_name}'  + "_collation_backup' as target_table_name, MAX(ROW_COUNT) AS SOURCE_ROW_COUNT ,MIN(ROW_COUNT) AS TARGET_ROW_COUNT ,(MAX(ROW_COUNT) - MIN(ROW_COUNT)) AS count_difference ,  CURRENT_TIMESTAMP(0) AS CREATE_DTM FROM ( SELECT '" + f'{table_name}' +  "' , ROW_COUNT FROM (select COUNT(*) AS ROW_COUNT FROM " + table_name + " UNION ALL SELECT COUNT(*) AS ROW_COUNT FROM " + table_name  + "_collation_backup) ) GROUP BY 1; \n "
                output_validation = "\nInsert into " + f'{audit_table}' + "_AUDIT (application_name , source_table_name , target_table_name , SOURCE_ROW_COUNT , TARGET_ROW_COUNT , count_difference , start_time , end_time) SELECT '" + f'{application_name}'  + "' as application_name ,'" + f'{table_name}'  + "' as source_table_name , '" + f'{table_name}'  + "_collation_backup' as target_table_name, MAX(ROW_COUNT) AS SOURCE_ROW_COUNT ,MIN(ROW_COUNT) AS TARGET_ROW_COUNT ,(MAX(ROW_COUNT) - MIN(ROW_COUNT)) AS count_difference ,filler_replacement_collation as start_time ,  CURRENT_TIMESTAMP(0) AS end_time FROM ( SELECT '" + f'{table_name}' +  "' , ROW_COUNT FROM (select COUNT(*) AS ROW_COUNT FROM " + table_name + " UNION ALL SELECT COUNT(*) AS ROW_COUNT FROM " + table_name  + "_collation_backup) ) GROUP BY 1; \n "

                #output_final = output_drop_backup + output_backup +"Drop table " + table_name + " CASCADE ; \n \n" + str(output) + output_recovery_backup + analyzing_table + output_validation
                output_final = output_drop_backup +  output_rename + str(output).replace('_collation_backup','') + "\n" + output_recovery_backup + analyzing_table + output_validation
                


                #print(output_final)
                #for item in output:
                #    output_final+=' ' + item

                    #output_final=convertTuple(output[item])
                print('\n--------Done---------\n')
                    
       
            fp2.write(str(output_final).replace("(['","").replace("'],)","").replace("\\n","\n").replace('(["','').replace('"],)',''))
    cursor.close()   
    conn.close() 


from Collation import check_collation 