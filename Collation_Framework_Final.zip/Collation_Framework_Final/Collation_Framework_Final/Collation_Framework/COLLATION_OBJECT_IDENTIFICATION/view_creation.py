def view_creation():

    file_list = fnmatch.filter(os.listdir('.//VIEWS'), '*.sql')
    #Below is the the string to add at column level if it's not present
    #string_to_add = ' collate case_insensitive '
    #print("String to add -->" + string_to_add)
    print("\n")
    print("---------------Processing Started---------------")
    for sql_file in file_list:
        print("\n")
        print("Processing file : ", sql_file)
        sql_file_name = sql_file.split('.')
        sql_file_new_name = sql_file_name[0]  + '.' + sql_file_name[1] + '_converted_view.' + sql_file_name[2]
        with open('.//VIEWS_UPDATED//' + sql_file_new_name ,'w') as fp2:
            with open('.//VIEWS//' + sql_file) as fp:
                for line in fp:
                    print("-----------------------------")
                    print("line-->"+ line)
                    print("-----------------------------")
                    line=line.split(",")
                    application_name = line[0].strip().upper()
                    original_table=line[1].strip()
                    schema=line[2]
                    schema_name = schema.strip()
                    table=line[3]
                    table_name = table.strip()
                    sql_stmt=line[5:]
                    sql_final=str(sql_stmt).replace("'","").replace("\\n"," ").replace("[","").replace("]","").replace("\\r"," ").replace("\\"," ")
                    print("schema name -->" + schema_name)
                    print("-----------------------------")
                    print("table name -->" + table_name)
                    print("-----------------------------")
                    print("sql_final-->" + sql_final)
                    print("-----------------------------")

                    #output_final = "Create or replace view " + schema_name + "." + table_name + " as " + sql_final
                    output_final = application_name + "," + original_table + ",Create or replace view " + schema_name + "." + table_name + " as " + sql_final
                    print("output_final -->" + output_final)
                    print("-----------------------------")

                    #Writing output to new file to have original file safe
                    fp2.write(output_final.rstrip('\n') + "\n")

                fp2.close()
                #print("Conversion for file  --> " + sql_file + " is completed and converted filename is --> " + sql_file_new_name)

import os,fnmatch
import re
import datetime 

now = datetime.datetime.now()
print ("\n-----Processing Started at --> " + now.strftime("%Y-%m-%d %H:%M:%S") + "-----\n")

view_creation()